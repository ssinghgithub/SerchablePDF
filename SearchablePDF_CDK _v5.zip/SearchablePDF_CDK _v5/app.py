#!/usr/bin/env python3

import aws_cdk as cdk

from stacks.searchable_pdf_cdk_stack import SearchablePdfCdkStack


app = cdk.App()
SearchablePdfCdkStack(app, "searchable-pdf-cdk")

app.synth()
