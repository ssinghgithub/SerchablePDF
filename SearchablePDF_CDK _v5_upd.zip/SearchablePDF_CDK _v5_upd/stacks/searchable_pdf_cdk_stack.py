from constructs import Construct
import aws_cdk as cdk
from aws_cdk import (
    Duration,
    Stack,
    aws_iam as iam,
    aws_sqs as sqs,
    aws_sns as sns,
    aws_s3 as _s3,
    aws_s3_notifications as _s3n,
    aws_iam as _iam,
    aws_lambda as _lambda,
    aws_stepfunctions as _sfn,
    aws_stepfunctions_tasks as _tasks,
    aws_dynamodb as _dynamodb,
    aws_sns_subscriptions as subs
)


class SearchablePdfCdkStack(Stack):

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # Define IAM role for Textract
        textractServiceRole = _iam.Role(self, 'TextractServiceRole', assumed_by=_iam.ServicePrincipal('textract'
                                                                                                      '.amazonaws.com'))
        # Create S3 buckets for input pdf
        # input_bucket = _s3.Bucket(self, 'input_pdf_bucket',
        #                           bucket_name='searchable-pdf-bucket-007',
        #                           auto_delete_objects=True,
        #                           removal_policy=cdk.RemovalPolicy.DESTROY,
        #                           lifecycle_rules=[_s3.LifecycleRule(
        #                               transitions=[_s3.Transition(
        #                                   storage_class=_s3.StorageClass.GLACIER,
        #                                   transition_after=cdk.Duration.days(7))]
        #                           )])

        input_bucket =_s3.Bucket.from_bucket_name(self,"Bucket",'nlp-dev1')

        # Dynamo DB table for tracking partially searchable pdfs
        ddb_table = _dynamodb.Table(
            self, "partiallySearchablePDF",
            partition_key=_dynamodb.Attribute(
                name="originalPDF",
                type=_dynamodb.AttributeType.STRING
            ),
            sort_key=_dynamodb.Attribute(
                name="partiallySearchablePage",
                type=_dynamodb.AttributeType.STRING
            ),
            billing_mode=_dynamodb.BillingMode.PROVISIONED,
            read_capacity=5,
            write_capacity=5
        )
        # Lambda Definitions

        

        CreateSearchablePDFLambda = _lambda.Function(self, 'CreateSearchablePDFambda',
                                                     function_name='create_searchablePDF_lambda',
                                                     description="Main lambda Function used to for SearchablePDF solution",
                                                     runtime=_lambda.Runtime.JAVA_11,
                                                     handler='GenerateSearchablePDF::handleRequest',
                                                     code=_lambda.Code.from_asset(
                                                         'assets/searchablePDF_jar/searchable-pdf-1.0-v5.jar'),
                                                     timeout=cdk.Duration.seconds(900),
                                                     memory_size=10240,
                                                     ephemeral_storage_size=cdk.Size.gibibytes(10),
                                                     retry_attempts=0,
                                                     environment={
                                                         'OUTPUT_LOC': 'cdkdeployment/searchablePDFTestcdk/output_pdf',
                                                         'DPI': '200',
                                                         'DDB_TABLE': ddb_table.table_name,
                                                         'batchPDF_LOC': 'cdkdeployment/searchablePDFTestcdk/batch_pdf'
                                                     }
                                                     )

        # Permissions
        input_bucket.grant_read_write(CreateSearchablePDFLambda)
        CreateSearchablePDFLambda.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                          resources=[textractServiceRole.role_arn]))
        CreateSearchablePDFLambda.add_to_role_policy(_iam.PolicyStatement(actions=["textract:*"],
                                                                          resources=["*"]))
        CreateSearchablePDFLambda.add_to_role_policy(_iam.PolicyStatement(actions=["s3:*", "s3-object-lambda:*"],
                                                                          resources=["*"]))

        # Invoke Textract Lambda
        InvokeTextractLambda = _lambda.Function(self, 'InvokeTextractLambda',
                                                function_name='invoke_textract_lambda',
                                                description="lambda Function to invoke Textract",
                                                runtime=_lambda.Runtime.JAVA_11,
                                                handler='TextractResultDelivery::handleRequest',
                                                code=_lambda.Code.from_asset(
                                                    'assets/searchablePDF_jar/searchable-pdf-1.0-v5.jar'),
                                                timeout=cdk.Duration.seconds(900),
                                                memory_size=10240,
                                                ephemeral_storage_size=cdk.Size.gibibytes(10),
                                                retry_attempts=0,
                                                environment={
                                                    'EXTRACT_LINES_PREFIX': 'cdkdeployment/searchablePDFTestcdk/readlines'
                                                }
                                                )

        # Permissions
        input_bucket.grant_read_write(InvokeTextractLambda)
        InvokeTextractLambda.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                     resources=[textractServiceRole.role_arn]))
        InvokeTextractLambda.add_to_role_policy(_iam.PolicyStatement(actions=["textract:*"],
                                                                     resources=["*"]))
        InvokeTextractLambda.add_to_role_policy(_iam.PolicyStatement(actions=["s3:*", "s3-object-lambda:*"],
                                                                     resources=["*"]))

        # Json Splitter Lambda
        JsonSplitterLambda = _lambda.Function(self, 'JsonSplitterLambda',
                                              function_name='json_splitter_lambda',
                                              description="lambda Function to split the JSON",
                                              runtime=_lambda.Runtime.JAVA_11,
                                              handler='SplitJsonLambda::handleRequest',
                                              code=_lambda.Code.from_asset(
                                                  'assets/searchablePDF_jar/searchable-pdf-1.0-v5.jar'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                              ephemeral_storage_size=cdk.Size.gibibytes(10),
                                              retry_attempts=0,
                                              environment={
                                                  'MAX_FILE_SIZE': '500',
                                                  'SPLITTED_LOC': 'cdkdeployment/searchablePDFTestcdk/splittedjson'
                                              }
                                              )

        # Permissions
        input_bucket.grant_read_write(JsonSplitterLambda)
        JsonSplitterLambda.add_to_role_policy(_iam.PolicyStatement(actions=["s3:*", "s3-object-lambda:*"],
                                                                   resources=["*"]))

        # Pdf Splitter Lambda
        PdfSplitterLambda = _lambda.Function(self, 'PdfSplitterLambda',
                                             function_name='pdf_splitter_lambda',
                                             description="lambda Function to split the PDF",
                                             runtime=_lambda.Runtime.JAVA_11,
                                             handler='SplitPdfLambda::handleRequest',
                                             code=_lambda.Code.from_asset(
                                                 'assets/searchablePDF_jar/searchable-pdf-1.0-v5.jar'),
                                             timeout=cdk.Duration.seconds(900),
                                             memory_size=10240,
                                             ephemeral_storage_size=cdk.Size.gibibytes(10),
                                             retry_attempts=0,
                                             environment={
                                                 'MAX_FILE_SIZE_MB': '500',
                                                 'MAX_FILE_PAGE': '3000',
                                                 'SPLITTED_LOC': 'cdkdeployment/searchablePDFTestcdk/splittedfiles'
                                             }
                                             )

        # Permissions
        input_bucket.grant_read_write(PdfSplitterLambda)
        PdfSplitterLambda.add_to_role_policy(_iam.PolicyStatement(actions=["s3:*", "s3-object-lambda:*"],
                                                                  resources=["*"]))
        # Pdf Splitter Lambda
        CombinerLambda = _lambda.Function(self, 'CombinerLambda',
                                          function_name='combiner_lambda',
                                          description="lambda Function to combine the PDFs",
                                          runtime=_lambda.Runtime.JAVA_11,
                                          handler='Combiner::handleRequest',
                                          code=_lambda.Code.from_asset(
                                              'assets/searchablePDF_jar/searchable-pdf-1.0-v5.jar'),
                                          timeout=cdk.Duration.seconds(900),
                                          memory_size=10240,
                                          ephemeral_storage_size=cdk.Size.gibibytes(10),
                                          retry_attempts=0,
                                          environment={
                                              'COMBINE_LOC': 'cdkdeployment/searchablePDFTestcdk/output_pdf'
                                          }
                                          )

        # Permissions
        input_bucket.grant_read_write(PdfSplitterLambda)
        CombinerLambda.add_to_role_policy(_iam.PolicyStatement(actions=["s3:*", "s3-object-lambda:*"],
                                                               resources=["*"]))
        # Step functions Definition
        pdf_to_json = _tasks.LambdaInvoke(
            self, "PDF to Json",
            lambda_function=CreateSearchablePDFLambda,
            output_path="$.Payload",
        )

        invoke_textract = _tasks.LambdaInvoke(
            self, "Textract Result Deliver",
            lambda_function=InvokeTextractLambda,
            output_path="$.Payload",
        )

        json_splitter = _tasks.LambdaInvoke(
            self, "Json Splitter",
            lambda_function=JsonSplitterLambda,
            output_path="$.Payload",
        )

        combine = _tasks.LambdaInvoke(
            self, "Combine",
            lambda_function=CombinerLambda,
            output_path="$.Payload",
        )

        # map = _sfn.Map(self, "Map State",
        #               max_concurrency=1,
        #
        #               items_path=_sfn.JsonPath.string_at("$.inputForMap")
        #               )
        # map.iterator(_sfn.Pass(self, "Pass State"))

        json_to_pdf_map = _sfn.Map(self, "Child SM Map State", items_path="$.splitted",
                                   result_path="$.pdfPendingCombine")
        json_to_pdf_map.iterator(_tasks.LambdaInvoke(
            self, "Splitted Json to Searchable PDF",
            lambda_function=CreateSearchablePDFLambda,
            output_path="$.Payload"
        ))

        json_to_searchable_pdf = _tasks.LambdaInvoke(
            self, "Json to Searchable PDF",
            lambda_function=CreateSearchablePDFLambda,
            output_path="$.Payload",
        )

        wait = _sfn.Wait(
            self, "Wait 30 Seconds",
            time=_sfn.WaitTime.duration(
                cdk.Duration.seconds(30))
        )

        choice_job_status = _sfn.Choice(self, 'Check job Status')

        choice_smaller_json = _sfn.Choice(self, 'Check if splitted to smaller Json')

        choice_pdf_or_json = _sfn.Choice(self, 'PDF or Json')

        # Create Chain

        # definition = pdf_to_json.next(json_splitter) \
        #     .next(_sfn.Choice(self, 'Choice')
        #           .when(_sfn.Condition.is_present('$.splitted'), map)
        #           .otherwise(json_to_searchable_pdf))

        sm_child_definition = choice_pdf_or_json.when(_sfn.Condition.is_present('$.originalKey'),
                                                      json_splitter).otherwise(pdf_to_json.next(choice_job_status
        .when(
            _sfn.Condition.string_equals('$.jobStatus', 'IN_PROGRESS'),
            wait.next(invoke_textract.next(choice_job_status)))
        .otherwise(
            json_splitter.next(choice_smaller_json
                               .when(
                _sfn.Condition.is_present('$.splitted'),
                json_to_pdf_map.next(combine))
                               .otherwise(json_to_searchable_pdf)
                               ))))

       
        # Create state machine
        sm_child = _sfn.StateMachine(
            self, "SearchablePDFChild",
            definition=sm_child_definition,
            timeout=cdk.Duration.minutes(15)
        )

        # Parent State Machine

        split_pdf = _tasks.LambdaInvoke(
            self, "Split PDF",
            lambda_function=PdfSplitterLambda,
            output_path="$.Payload",
        )
        createSearchablePdf_sm = _tasks.StepFunctionsStartExecution(
            self, "CreateSearchablePDF SM",
            state_machine=sm_child,
            input=_sfn.TaskInput.from_text("$.originalDoc"),
            output_path="$.Output"
        )

        split_searchable_pdf_map = _sfn.Map(self, "Parent SM Map State", items_path="$.splitted",
                                            result_path="$.pdfPendingCombine")
        # sm_child.grant_start_sync_execution()
        split_searchable_pdf_map.iterator(_tasks.StepFunctionsStartExecution(
            self, "Create Splited searchable Pdf",
            state_machine=sm_child,
            output_path="$.Output",
            # integration_pattern=_sfn.IntegrationPattern.RUN_JOB
        ))

        combiner = _tasks.LambdaInvoke(
            self, "Combiner",
            lambda_function=CombinerLambda,
            output_path="$.Payload",
        )

        sm_parent_definition = split_pdf.next(_sfn.Choice(self, 'Choice')
                                              .when(_sfn.Condition.is_present('$.splitted'),
                                                    split_searchable_pdf_map.next(combiner))
                                              .otherwise(createSearchablePdf_sm))

        # Create state machine
        sm_parent = _sfn.StateMachine(
            self, "SearchablePDFParent",
            definition=sm_parent_definition,
            timeout=cdk.Duration.minutes(15)
        )

        sm_parent.add_to_role_policy(iam.PolicyStatement(actions=["states:*", "events:*"],
                                                         resources=["*"]))
        sm_parent.add_to_role_policy(iam.PolicyStatement(actions=["iam:PassRole"],
                                                         resources=["arn:aws:iam::*:role/AWS_Events_Invoke_Targets"]))

        TriggerSearchablePDFLambda = _lambda.Function(self, "TriggerSearchablePDFLambda",
                                                      function_name='trigger_searchablePDF_lambda',
                                                     description="Lambda function to trigger SearchablePDF SM on S3 upload",
                                  code=_lambda.Code.from_asset('assets/searchablePDFTriggerLambda/'),
                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                  handler="searchablePDFTriggerLambda.lambda_handler",
                                  timeout=Duration.seconds(300),
                                  environment={
                                    "STATE_MACHINE_ARN" : sm_parent.state_machine_arn
                                  })

        TriggerSearchablePDFLambda.add_to_role_policy(_iam.PolicyStatement(actions=["states:*"],
                                                                   resources=[sm_parent.state_machine_arn]))

        #-------------Event Notification from S3 input pdfs folder->Lambda-----------------------
        input_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(TriggerSearchablePDFLambda), _s3.NotificationKeyFilter(prefix="cdkdeployment/searchablePDFTestcdk/input_pdf/", suffix=".pdf", ))

        