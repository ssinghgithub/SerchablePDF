import com.amazon.textract.pdf.ImageType;
import com.amazon.textract.pdf.PDFDocument;
import com.amazon.textract.pdf.TextLine;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.textract.AmazonTextract;
import com.amazonaws.services.textract.AmazonTextractClientBuilder;
import com.amazonaws.services.textract.model.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.Type;
import java.lang.IllegalStateException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class CreatePdfFromS3Pdf {
    public void run(String bucketName, String documentName)
            throws IOException, InterruptedException {

        System.out.println("Generating searchable pdf from: " + bucketName + "/" + documentName);

        String operationMode = System.getenv("OPERATION_MODE");


        // Extract text using Amazon Textract
        // List<ArrayList<TextLine>> linesInPages = extractText(bucketName,
        // documentName);
        if (operationMode.equals("EXTRACT_LINES")) {
            String targetPrefix = extractTextToS3(bucketName, documentName);
            System.out.println("Interim Json File Path is " + targetPrefix);
        } else if (operationMode.equals("PROCESS_LINES")) {
            String targetPrefix = documentName;
            
            List<ArrayList<TextLine>> linesInPages = GetExtractedLines(bucketName, targetPrefix);
            String inputJsonFileName = "";
            String[] inputDocumentAsArray = documentName.split("/");
            if (!Objects.isNull(inputDocumentAsArray) && inputDocumentAsArray.length > 0) {
                inputJsonFileName = inputDocumentAsArray[inputDocumentAsArray.length - 1];
            }
            String originalDocumentName = getOriginalDocumentPrefix(inputJsonFileName);
            String[] outputPrefixArray = originalDocumentName.split("/");

            String outputDocumentName = "";
            if (!Objects.isNull(outputPrefixArray) && outputPrefixArray.length > 0) {

                // read output location from env variable
                String ouputLoc = Objects.isNull(System.getenv("OUTPUT_LOC")) ? "searchablepdf"
                : System.getenv("OUTPUT_LOC");
                outputDocumentName = String.format("%s/%s", ouputLoc,
                        outputPrefixArray[outputPrefixArray.length - 1]);
            }
            // Get input pdf document from Amazon S3
            InputStream inputPdf = getPdfFromS3(bucketName, originalDocumentName);

            // Create new PDF document
            PDFDocument pdfDocument = new PDFDocument();

            // For each page add text layer and image in the pdf document
            PDDocument inputDocument = PDDocument.load(inputPdf);
            PDFRenderer pdfRenderer = new PDFRenderer(inputDocument);
            BufferedImage image = null;

            System.out.println("No of Pages to process: " + inputDocument.getNumberOfPages());

            for (int page = 0; page < inputDocument.getNumberOfPages(); ++page) {
                image = pdfRenderer.renderImageWithDPI(page, 300, org.apache.pdfbox.rendering.ImageType.RGB);

                pdfDocument.addPage(image, ImageType.JPEG, linesInPages.get(page));

                System.out.println("Processed page index: " + page);
            }

            // Save PDF to stream
            ByteArrayOutputStream os = new ByteArrayOutputStream();
            pdfDocument.save(os);
            pdfDocument.close();
            inputDocument.close();

            // Upload PDF to S3
            // String outputDocumentLoc =
            // documentName.substring(0,documentName.lastIndexOf("/"));

            UploadToS3(bucketName, outputDocumentName, "application/pdf", os.toByteArray());

            // System.out.println("Generated searchable pdf: " + bucketName +
            // outputDocumentLoc + outputDocumentName);
            System.out.println("Generated searchable pdf saved to: " + bucketName + "/" + outputDocumentName);

        }
    }

    public List<ArrayList<TextLine>> extractText(String bucketName, String documentName) throws InterruptedException {

        AmazonTextract client = AmazonTextractClientBuilder.defaultClient();

        StartDocumentTextDetectionRequest req = new StartDocumentTextDetectionRequest()
                .withDocumentLocation(new DocumentLocation()
                        .withS3Object(new S3Object()
                                .withBucket(bucketName)
                                .withName(documentName)))
                .withJobTag("DetectingText");

        StartDocumentTextDetectionResult startDocumentTextDetectionResult = client.startDocumentTextDetection(req);
        String startJobId = startDocumentTextDetectionResult.getJobId();

        System.out.println("Text detection job started with Id: " + startJobId);

        GetDocumentTextDetectionRequest documentTextDetectionRequest = null;
        GetDocumentTextDetectionResult response = null;

        String jobStatus = "IN_PROGRESS";

        while (jobStatus.equals("IN_PROGRESS")) {
            System.out.println("Waiting for job to complete...");
            TimeUnit.SECONDS.sleep(10);
            documentTextDetectionRequest = new GetDocumentTextDetectionRequest()
                    .withJobId(startJobId)
                    .withMaxResults(1);

            response = client.getDocumentTextDetection(documentTextDetectionRequest);
            jobStatus = response.getJobStatus();
        }

        int maxResults = 1000;
        String paginationToken = null;
        Boolean finished = false;

        List<ArrayList<TextLine>> pages = new ArrayList<ArrayList<TextLine>>();
        ArrayList<TextLine> page = null; // reverting to test on 03/08/23
        BoundingBox boundingBox = null; // reverting to test on 03/08/23
        // ArrayList<TextLine> page = new ArrayList<TextLine>(); // Updated : Sandeep
        // Singh
        // BoundingBox boundingBox = new BoundingBox(); // Updated : Sandeep Singh

        while (finished == false) {
            documentTextDetectionRequest = new GetDocumentTextDetectionRequest()
                    .withJobId(startJobId)
                    .withMaxResults(maxResults)
                    .withNextToken(paginationToken);
            response = client.getDocumentTextDetection(documentTextDetectionRequest);
            System.out.println("Generated response: " + response);
            // Show blocks information
            List<Block> blocks = response.getBlocks();
            System.out.println("Generated blocks: " + blocks);
            for (Block block : blocks) {
                if (block.getBlockType().equals("PAGE")) {
                    page = new ArrayList<TextLine>();
                    pages.add(page);
                } else if (block.getBlockType().equals("LINE")) {
                    boundingBox = block.getGeometry().getBoundingBox();
                    page.add(new TextLine(boundingBox.getLeft(),
                            boundingBox.getTop(),
                            boundingBox.getWidth(),
                            boundingBox.getHeight(),
                            block.getText()));
                }
            }
            paginationToken = response.getNextToken();
            if (paginationToken == null)
                finished = true;
        }

        return pages;
    }

    private InputStream getPdfFromS3(String bucketName, String documentName) throws IOException {

        AmazonS3 s3client = AmazonS3ClientBuilder.defaultClient();
        com.amazonaws.services.s3.model.S3Object fullObject = s3client
                .getObject(new GetObjectRequest(bucketName, documentName));
        InputStream in = fullObject.getObjectContent();
        return in;
    }

    private void UploadToS3(String bucketName, String objectName, String contentType, byte[] bytes) {
        AmazonS3 s3client = AmazonS3ClientBuilder.defaultClient();
        ByteArrayInputStream baInputStream = new ByteArrayInputStream(bytes);
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(bytes.length);
        metadata.setContentType(contentType);
        // String key = outputDocumentLoc+"/"+objectName ;

        PutObjectRequest putRequest = new PutObjectRequest(bucketName, objectName, baInputStream, metadata);

        // PutObjectRequest putRequest = new PutObjectRequest(bucketName, objectName,
        // baInputStream, metadata);
        s3client.putObject(putRequest);
    }

    private String SaveLinesToS3(String bucketName, String documentName, String outputString) {
        AmazonS3 s3client = AmazonS3ClientBuilder.defaultClient();
        // String localFileName = String.format("%s.json",
        // UUID.randomUUID().toString());
        String localFileName = getFormattedDocumentName(documentName);
        String localFilePath = String.format("/tmp/%s", localFileName);
        BufferedWriter writer = null;
        try {
            writer = new BufferedWriter(new FileWriter(localFilePath));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        try {
            writer.write(outputString);
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        String extractLinesPrefix = Objects.isNull(System.getenv("EXTRACT_LINES_PREFIX")) ? "readlines"
                : System.getenv("EXTRACT_LINES_PREFIX");
        String targetPrefix = String.format("%s/%s", extractLinesPrefix, localFileName);

        File localFile = new File(localFilePath);
        if (localFile.exists()) {
            PutObjectRequest putRequest = new PutObjectRequest(bucketName, targetPrefix, localFile);
            PutObjectResult result = s3client.putObject(putRequest);
            if (!Objects.isNull(result.getETag())) {

            }
        }
        return targetPrefix;
    }

    public String extractTextToS3(String bucketName, String documentName) throws InterruptedException {

        AmazonTextract client = AmazonTextractClientBuilder.defaultClient();

        StartDocumentTextDetectionRequest req = new StartDocumentTextDetectionRequest()
                .withDocumentLocation(new DocumentLocation()
                        .withS3Object(new S3Object()
                                .withBucket(bucketName)
                                .withName(documentName)))
                .withJobTag("DetectingText");

        StartDocumentTextDetectionResult startDocumentTextDetectionResult = client.startDocumentTextDetection(req);
        String startJobId = startDocumentTextDetectionResult.getJobId();

        System.out.println("Text detection job started with Id: " + startJobId);

        GetDocumentTextDetectionRequest documentTextDetectionRequest = null;
        GetDocumentTextDetectionResult response = null;

        String jobStatus = "IN_PROGRESS";

        while (jobStatus.equals("IN_PROGRESS")) {
            System.out.println("Waiting for job to complete...");
            TimeUnit.SECONDS.sleep(10);
            documentTextDetectionRequest = new GetDocumentTextDetectionRequest()
                    .withJobId(startJobId)
                    .withMaxResults(1);

            response = client.getDocumentTextDetection(documentTextDetectionRequest);
            jobStatus = response.getJobStatus();
        }

        int maxResults = 1000;
        String paginationToken = null;
        Boolean finished = false;

        List<ArrayList<TextLine>> pages = new ArrayList<ArrayList<TextLine>>();
        ArrayList<TextLine> page = null; // reverting to test on 03/08/23
        BoundingBox boundingBox = null; // reverting to test on 03/08/23
        // ArrayList<TextLine> page = new ArrayList<TextLine>(); // Updated : Sandeep
        // Singh
        // BoundingBox boundingBox = new BoundingBox(); // Updated : Sandeep Singh

        while (finished == false) {
            documentTextDetectionRequest = new GetDocumentTextDetectionRequest()
                    .withJobId(startJobId)
                    .withMaxResults(maxResults)
                    .withNextToken(paginationToken);
            response = client.getDocumentTextDetection(documentTextDetectionRequest);
            
            // Removed println statement to not write PHI to CloudWatch Logs
            System.out.println("Generated response received");
            //System.out.println("Generated response: " + response);
            // Show blocks information
            List<Block> blocks = response.getBlocks();
            
            // Removed println statement to not write PHI to CloudWatch Logs
            System.out.println("Generated blocks parsed");
            //System.out.println("Generated blocks: " + blocks);
            for (Block block : blocks) {
                if (block.getBlockType().equals("PAGE")) {
                    page = new ArrayList<TextLine>();
                    pages.add(page);
                } else if (block.getBlockType().equals("LINE")) {
                    boundingBox = block.getGeometry().getBoundingBox();
                    page.add(new TextLine(boundingBox.getLeft(),
                            boundingBox.getTop(),
                            boundingBox.getWidth(),
                            boundingBox.getHeight(),
                            block.getText()));
                }
            }
            paginationToken = response.getNextToken();
            if (paginationToken == null)
                finished = true;
        }
        Gson gson = new GsonBuilder().create();

        String json = gson.toJson(pages);
        String targetPrefix = SaveLinesToS3(bucketName, documentName, json);

        return targetPrefix;
    }

    public List<ArrayList<TextLine>> GetExtractedLines(String bucket, String prefix) throws IOException {
        InputStream is = getPdfFromS3(bucket, prefix);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        System.out.println("Got reader");
        StringBuilder content = new StringBuilder();
        System.out.println("reading line");
        char[] theChars = new char[256];

        int charsRead = reader.read(theChars, 0, theChars.length);
        while (charsRead != -1) {
            content.append(new String(theChars, 0, charsRead));
            charsRead = reader.read(theChars, 0, theChars.length);
        }
        String line = content.toString();
        System.out.println("read line");
        ArrayList<TextLine> yourList = new ArrayList<>();
        List<ArrayList<TextLine>> returnList = new ArrayList<>();
        if (line != null) {
            JsonElement jElement =  JsonParser.parseString(line);
            if (jElement.isJsonArray() && jElement.getAsJsonArray().size() > 0) {
                Type listType = new TypeToken<List<TextLine>>() {
                }.getType();
                //yourList = new Gson().fromJson(jElement.getAsJsonArray().get(0), listType);

                // Added loop to include Textract results from all pages
                // Added exception handling to not print json data to stdout
                try {
                    for (int i = 0; i < jElement.getAsJsonArray().size(); i++) {
                        yourList = new Gson().fromJson(jElement.getAsJsonArray().get(i), listType);
                        returnList.add(yourList);
                    }
                } catch (IllegalStateException e) {
                    throw new IllegalStateException("Unable parse JSON Object");
                }

            }
        }
        return returnList;
    }

    private String getFormattedDocumentName(String inputDocumentName) {
        String returnValue = inputDocumentName.replace("/", "--").replace(".pdf", "");
        String localFileName = String.format("%s---%s.json", returnValue, UUID.randomUUID().toString());
        System.out.println(localFileName);
        System.out.println(returnValue);
        return localFileName;
    }

    private String getOriginalDocumentPrefix(String inputJsonFile) {
        String returnValue = "";
        String[] originalAsArray = inputJsonFile.split("---");
        if (!Objects.isNull(originalAsArray) && originalAsArray.length > 0) {
            returnValue = String.format("%s.pdf", originalAsArray[0].replace("--", "/"));
        }
        return returnValue;
    }
}