import com.amazon.textract.pdf.TextLine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SearchablePDF {
    public static void main(String args[]) {
        try {
            //Generate searchable PDF from pdf in Amazon S3 bucket
            CreatePdfFromS3Pdf s3Pdf = new CreatePdfFromS3Pdf();
            List<ArrayList<TextLine>> linesInPagesExisting = s3Pdf.extractText("ec2-textract", "documents/SampleInput.pdf");

            String targetPrefix = s3Pdf.extractTextToS3("ec2-textract", "documents/SampleInput.pdf");

            List<ArrayList<TextLine>> linesInPages = s3Pdf.GetExtractedLines("ec2-textract", targetPrefix);

            System.out.println(linesInPages.size());

            //s3Pdf.run("ki-textract-demo-docs", "SampleInput.pdf", "SampleOutput.pdf");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
