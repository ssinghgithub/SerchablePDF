import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.s3.event.S3EventNotification;

public class SearchablePDFLambda implements RequestHandler<S3Event, String> {

    @Override
    
    public String handleRequest(S3Event event, Context ctx) {

        S3EventNotification.S3EventNotificationRecord record = event.getRecords().get(0);
        System.out.println("record " + record);
        String bucketName = record.getS3().getBucket().getName();
        String keyName = record.getS3().getObject().getKey();
        String keyNameLower = record.getS3().getObject().getKey().toLowerCase();


        // String outputkeyName = "searchablepdf/"+keyName.substring(keyName.lastIndexOf("/")+1); // Updated : Sandeep Singh
        // String outputPdf = keyName.substring(keyName.lastIndexOf("/")+1);

        System.out.println("Bucket Name is " + bucketName);
        System.out.println("Input File Path is " + keyName);
        

        try {
            if (keyNameLower.endsWith("pdf")) {
                CreatePdfFromS3Pdf s3Pdf = new CreatePdfFromS3Pdf();
                // s3Pdf.run(bucketName, keyName, "Output.pdf");
                s3Pdf.run(bucketName, keyName); // Updated : Sandeep Singh

            } else if (keyNameLower.endsWith("json")) {
                CreatePdfFromS3Pdf s3Pdf = new CreatePdfFromS3Pdf();
                // s3Pdf.run(bucketName, keyName, "Output.pdf");
                s3Pdf.run(bucketName, keyName); // Updated : Sandeep Singh

            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return null;
    }
}