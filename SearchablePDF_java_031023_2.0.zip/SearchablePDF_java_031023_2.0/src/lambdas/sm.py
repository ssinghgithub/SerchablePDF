{
  "StartAt": "Start Textract Job",
  "States": {
    "Start Textract Job": {
      "Next": "Wait 1 Minute",
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException"
          ],
          "IntervalSeconds": 2,
          "MaxAttempts": 6,
          "BackoffRate": 2
        }
      ],
      "Type": "Task",
      "OutputPath": "$.Payload",
      "Resource": "arn:aws:states:::lambda:invoke",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-east-1:017444429555:function:submitAscyncTextractJob:$LATEST",
        "Payload.$": "$"
      }
    },
    "Wait 1 Minute": {
      "Type": "Wait",
      "Seconds": 20,
      "Next": "Get Textract Job Status"
    },
    "Get Textract Job Status": {
      "Next": "Job Complete?",
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException"
          ],
          "IntervalSeconds": 2,
          "MaxAttempts": 6,
          "BackoffRate": 2
        }
      ],
      "Type": "Task",
      "OutputPath": "$.Payload",
      "Resource": "arn:aws:states:::lambda:invoke",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-east-1:017444429555:function:getAsyncTextractJobStatus:$LATEST",
        "Payload.$": "$"
      }
    },
    "Job Complete?": {
      "Type": "Choice",
      "Choices": [
        {
          "Variable": "$.JobStatus",
          "StringEquals": "FAILED",
          "Next": "Fail"
        },
        {
          "Variable": "$.JobStatus",
          "StringEquals": "SUCCEEDED",
          "Next": "RenderPDF"
        }
      ],
      "Default": "Wait 1 Minute"
    },
    "Fail": {
      "Type": "Fail",
      "Error": "DescribeJob returned FAILED",
      "Cause": "AWS Batch Job Failed"
    },
    "RenderPDF": {
      "End": true,
      "Retry": [
        {
          "ErrorEquals": [
            "Lambda.ServiceException",
            "Lambda.AWSLambdaException",
            "Lambda.SdkClientException"
          ],
          "IntervalSeconds": 2,
          "MaxAttempts": 6,
          "BackoffRate": 2
        }
      ],
      "Type": "Task",
      "OutputPath": "$.Payload",
      "Resource": "arn:aws:states:::lambda:invoke",
      "Parameters": {
        "FunctionName": "arn:aws:lambda:us-east-1:017444429555:function:renderPDF:$LATEST",
        "Payload.$": "$"
      }
    }
  },
  "TimeoutSeconds": 300
}