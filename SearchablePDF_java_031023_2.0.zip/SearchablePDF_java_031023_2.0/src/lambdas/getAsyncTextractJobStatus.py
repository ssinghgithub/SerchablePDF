import json
import os
import time
import boto3
import uuid
from urllib.parse import unquote, unquote_plus


s3_client = boto3.client('s3')
s3 = boto3.resource('s3')
textract_client = boto3.client('textract')


def getJobResults(job_id,next_token=None):
    kwargs = {}
    if next_token:
        kwargs['NextToken'] = next_token
    response = textract_client.get_document_text_detection(JobId= job_id)
    print(response)
    
    return response
    
def extractTextLines(response): 
    pages =[]
    blocks= response['Blocks']
    
    # for each page - add a empty list, which will be polulated with Text later
    for block in blocks:
        if block['BlockType'] == 'PAGE':
            pages.append([])
    
    # populate line text and its geometric location aka bounding box
    for block in blocks:
        if block['BlockType'] == 'LINE':
            dictionary = block['Geometry']['BoundingBox']
            dictionary['text'] = block['Text']
            dictionary = {key.lower():value for key, value in dictionary.items()}
            pages[block['Page']-1].append(dictionary)
    # print(pages)
    
    return pages
    
def write_json_to_s3(pages, bucket, json_output_key):
    # write extracted textlines to s3
    s3.Object(bucket, json_output_key).put(Body=json.dumps(pages))
    

def lambda_handler(event, context):
    bucket = event['bucket_name']
    input_key= event['key']
    
    job_id = event['job_id']
    print("this job_id:",job_id)
    
    json_prefix = os.environ['JSON_PREFIX']
    id = uuid.uuid4().hex
    json_output_key = f'{json_prefix}/{event["key"][:event["key"].find("/")]}-{event["key"][event["key"].rfind("/")+1:-4]}-{id}.json'
    
    
    # json_output_key =f'readlines/{event["key"][:event["key"].find("/")]}-{event["key"][event["key"].rfind("/")+1:-4]}--{"a64b60d3-92b2-4ece-a5b4-6bea2d2d48bc"}.json'
    print("json_output_key:",json_output_key)
    
    response = textract_client.get_document_text_detection(JobId= job_id)

    
    if response['JobStatus'] == 'SUCCEEDED':
        response = getJobResults(job_id)
        
        pages = extractTextLines(response)
        
        write_json_to_s3(pages, bucket, json_output_key)
        
    # print(text)
    return {
          "JobStatus": response['JobStatus'],
          "bucket_name": bucket,
          "input_key": input_key,
          "json_output_key": json_output_key
        }





# def get_detected_text(job_id: str, keep_newlines: bool = False) -> str:
#     """
#     Giving job_id, return plain text extracted from input document.
#     :param job_id: Textract DetectDocumentText job Id
#     :param keep_newlines: if True, output will have same lines structure as the input document
#     :return: plain text as extracted by Textract
#     """
#     max_results = 1000
#     pagination_token = None
#     finished = False
#     text = ''
#     while not finished:
#         if pagination_token is None:
#             response = textract_client.get_document_text_detection(JobId=job_id,
#                                                                   MaxResults=max_results)
#         else:
#             response = textract_client.get_document_text_detection(JobId=job_id,
#                                                                   MaxResults=max_results,
#                                                                   NextToken=pagination_token)
#         sep = ' ' if not keep_newlines else '\n'
#         text += sep.join([x['Text'] for x in response['Blocks'] if x['BlockType'] == 'LINE'])
#         if 'NextToken' in response:
#             pagination_token = response['NextToken']
#         else:
#             finished = True
#     return text