import json
import time
import boto3

textract_client = boto3.client('textract')

def startJob(bucket_name, key):
    response = textract_client.start_document_text_detection(
        DocumentLocation={
            'S3Object': {
                'Bucket': bucket_name,
                'Name': key,
            }
        }
    )
    return response["JobId"]

def lambda_handler(event, context):
    print("event:",event)
    
    bucket_name = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3'][ 'object']['key']
    
    print(f"StartJob: s3://{bucket_name}/{key}")
    
    job_id = startJob(bucket_name, key)
    
    return {
        "bucket_name": bucket_name,
        "key": key,
        "job_id": job_id,
    }
