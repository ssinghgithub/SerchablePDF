import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.s3.event.S3EventNotification;

public class SearchablePDFEC2 {
    public static void main(String args[]) {
        handleRequest();
    }

    public static String handleRequest() {


        String bucketName = "ec2-textract";
        String keyName = "documents/SampleInput.pdf";
        String keyNameLower = "documents/sampleinput.pdf";
        System.out.println("Bucket Name is " + bucketName);
        System.out.println("File Path is " + keyName);


        String outputkeyName = "searchablepdf/" + keyName.substring(keyName.lastIndexOf("/") + 1); // Updated : Sandeep Singh
        // String outputPdf = keyName.substring(keyName.lastIndexOf("/")+1);

        System.out.println("Bucket Name is " + bucketName);
        System.out.println("Input File Path is " + keyName);
        System.out.println("Output File Path is " + outputkeyName);

        try {
            if (keyNameLower.endsWith("pdf")) {
                CreatePdfFromS3Pdf s3Pdf = new CreatePdfFromS3Pdf();
                // s3Pdf.run(bucketName, keyName, "Output.pdf");
                s3Pdf.run(bucketName, keyName, outputkeyName); // Updated : Sandeep Singh

            } else if (keyNameLower.endsWith("jpg") || keyNameLower.endsWith("jpeg") || keyNameLower.endsWith("png")) {
                CreatePdfFromS3Image s3Image = new CreatePdfFromS3Image();
                // s3Image.run(bucketName, keyName, "Output.pdf");
                s3Image.run(bucketName, keyName, outputkeyName); // Updated : Sandeep Singh
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return null;
    }
}