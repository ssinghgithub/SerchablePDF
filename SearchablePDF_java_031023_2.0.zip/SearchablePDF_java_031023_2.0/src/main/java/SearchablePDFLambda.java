import java.util.Map;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.LambdaLogger;
import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.events.S3Event;
import com.amazonaws.services.s3.event.S3EventNotification;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;

public class SearchablePDFLambda implements RequestHandler<Map<String, String>, String> {
    private static final Gson gson = new GsonBuilder().setPrettyPrinting().create();
    @Override
    
    public String handleRequest(Map<String, String> event, Context ctx) {
        LambdaLogger logger = ctx.getLogger();

        System.out.println("event " + event);
        logger.log("EVENT:" + gson.toJson(event));
        // logger.log("EVENT1:" + event.getClass().toString());
       

        // read output prefix from environment variable
        String outPrefix = System.getenv("OUTPUT_LOC");

        String bucketName = event.get("bucket_name");
        String inputkeyName = event.get("input_key");
        String jsonkeyName = event.get("json_output_key");
        String outputkeyName = outPrefix + "/" + inputkeyName.substring(inputkeyName.lastIndexOf("/")+1); // Updated : Sandeep Singh
       

        System.out.println("Bucket Name is " + bucketName);
        System.out.println("Input File Path is " + inputkeyName);
        System.out.println("Output File Path is " + outputkeyName);

        try {
             if (jsonkeyName.toLowerCase().endsWith("json")) {
                CreatePdfFromS3Pdf s3Pdf = new CreatePdfFromS3Pdf();
                // s3Pdf.run(bucketName, keyName, "Output.pdf");
                s3Pdf.run(bucketName, inputkeyName, jsonkeyName, outputkeyName); // Updated : Sandeep Singh

            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage());
        }
        return null;
    }
}