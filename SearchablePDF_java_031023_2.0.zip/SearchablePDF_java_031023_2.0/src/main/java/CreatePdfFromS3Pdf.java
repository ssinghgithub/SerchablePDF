import com.amazon.textract.pdf.ImageType;
import com.amazon.textract.pdf.PDFDocument;
import com.amazon.textract.pdf.TextLine;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.amazonaws.services.textract.AmazonTextract;
import com.amazonaws.services.textract.AmazonTextractClientBuilder;
import com.amazonaws.services.textract.model.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

import java.awt.image.BufferedImage;
import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

public class CreatePdfFromS3Pdf {
    public void run(String bucketName, String documentName, String jsonkeyName, String outputDocumentName) throws IOException, InterruptedException {
        
        System.out.println("Generating searchable pdf from: " + bucketName + "/" + documentName);

        // read json (converted from textrcat json) file location
        String txtLinesPrefix = jsonkeyName;

        // read lines and location
        List<ArrayList<TextLine>> linesInPages = GetExtractedLines(bucketName, txtLinesPrefix);
        
        //Get input pdf document from Amazon S3
        InputStream inputPdf = getPdfFromS3(bucketName, documentName);

        //Create new PDF document
        PDFDocument pdfDocument = new PDFDocument();

        //For each page add text layer and image in the pdf document
        PDDocument inputDocument = PDDocument.load(inputPdf);
        PDFRenderer pdfRenderer = new PDFRenderer(inputDocument);
        BufferedImage image = null;
        for (int page = 0; page < inputDocument.getNumberOfPages(); ++page) {
            image = pdfRenderer.renderImageWithDPI(page, 300, org.apache.pdfbox.rendering.ImageType.RGB);

            pdfDocument.addPage(image, ImageType.JPEG, linesInPages.get(page));

            System.out.println("Processed page index: " + page);
        }

        //Save PDF to stream
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        pdfDocument.save(os);
        pdfDocument.close();
        inputDocument.close();

        //Upload PDF to S3
        // String outputDocumentLoc = documentName.substring(0,documentName.lastIndexOf("/"));
        UploadToS3(bucketName, outputDocumentName, "application/pdf", os.toByteArray());

        // System.out.println("Generated searchable pdf: " + bucketName + outputDocumentLoc + outputDocumentName);
        System.out.println("Generated searchable pdf saved to: " + bucketName + "/" + outputDocumentName);
    }


    private InputStream getPdfFromS3(String bucketName, String documentName) throws IOException {

        AmazonS3 s3client = AmazonS3ClientBuilder.defaultClient();
        com.amazonaws.services.s3.model.S3Object fullObject = s3client.getObject(new GetObjectRequest(bucketName, documentName));
        InputStream in = fullObject.getObjectContent();
        return in;
    }

    private void UploadToS3(String bucketName, String objectName, String contentType, byte[] bytes) {
        AmazonS3 s3client = AmazonS3ClientBuilder.defaultClient();
        ByteArrayInputStream baInputStream = new ByteArrayInputStream(bytes);
        ObjectMetadata metadata = new ObjectMetadata();
        metadata.setContentLength(bytes.length);
        metadata.setContentType(contentType);

        PutObjectRequest putRequest = new PutObjectRequest(bucketName, objectName, baInputStream, metadata);
        s3client.putObject(putRequest);
    }


    public List<ArrayList<TextLine>> GetExtractedLines(String bucket, String prefix) throws IOException {
        InputStream is = getPdfFromS3(bucket, prefix);
        BufferedReader reader = new BufferedReader(new InputStreamReader(is));
        System.out.println("Got reader");
        Gson gson = new GsonBuilder().create();
        StringBuilder content = new StringBuilder();
        System.out.println("reading line");
        char[] theChars = new char[256];

        int charsRead = reader.read(theChars, 0, theChars.length);
        while (charsRead != -1) {
            content.append(new String(theChars, 0, charsRead));
            charsRead = reader.read(theChars, 0, theChars.length);
        }
        String line = content.toString();
        System.out.println("read line");
        ArrayList<TextLine> yourList = new ArrayList<>();
        if (line != null) {
            JsonElement jElement = new JsonParser().parse(line);
            if (jElement.isJsonArray() && jElement.getAsJsonArray().size() > 0) {
                Type listType = new TypeToken<List<TextLine>>() {
                }.getType();

                yourList = new Gson().fromJson(jElement.getAsJsonArray().get(0), listType);

            }
        }
        List<ArrayList<TextLine>> returnList = new ArrayList<>();
        returnList.add(yourList);
        return returnList;
    }

}