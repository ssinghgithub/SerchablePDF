from document_analysis import start_job, is_job_complete, get_job_results

import utils
import boto3
import logging
import json

# read configurable parameters
with open("../config.json", "rb") as fp:
    config = json.load(fp)
client = boto3.client("textract", region_name=config["region"])


def merge_textract_results(file_name, page_list, page_number, combined_response):

    job_id = start_job(client, utils.BUCKET, file_name)
    logging.info("Started job with id: {}".format(job_id))

    if is_job_complete(client, job_id):
        response = get_job_results(client, job_id)

    if len(combined_response) == 0:
        combined_response = response
    else:
        # update the page number in response
        for each in response[0]["Blocks"]:
            index = int(each["Page"])
            each["Page"] = page_list[(index - 1)]
        combined_response[0]["Blocks"].extend(response[0]["Blocks"])

    # update the total number of pages
    combined_response[0]["DocumentMetadata"]["Pages"] = page_number + 1

    return combined_response
