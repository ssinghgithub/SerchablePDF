from typing import Dict, List
from io import BytesIO
from merge import merge_textract_results

import utils
import logging
import math

import PyPDF2


def save_file_splits(file_name, page_number, writer) -> bool:
    prefix = f"tmp_split/{file_name.split('.')[0]}"
    page_file_name = f"{prefix}_page_{page_number+1}.pdf"
    s3_response = utils.write_file_to_s3(page_file_name, writer)

    return page_file_name


def split_merge(file_name, reader, page_limit=10, size_limit=1024) -> List:

    page_list = []
    writer = PyPDF2.PdfFileWriter()
    is_write_complete = False
    results = {}

    # iterate over each page
    for page_number in range(reader.getNumPages()):
        page_list.append(page_number + 1)
        writer.add_page(reader.getPage(page_number))

        # save split files to s3 bucket
        if writer.getNumPages() == page_limit:
            buffer = BytesIO()
            writer.write(buffer)

            # check if split exceeds size limit
            if buffer.getbuffer().nbytes > size_limit:
                logging.info(
                    f"File split at split_size={page_limit} exceeded Textract's size limitation"
                )
                if page_limit == 1:
                    raise ValueError(
                        "Document with a single page cannot be split further!"
                    )
                return (math.ceil(page_limit / 2), {})

            tmp_file_name = save_file_splits(file_name, page_number, writer)
            results = merge_textract_results(
                tmp_file_name, page_list, page_number, results
            )
            is_write_complete = True
            # delete intermediate splits from s3 after calling Textract
            utils.delete_file_from_s3(tmp_file_name)

        if is_write_complete:
            # clear the contents of the writer, to add pages from next split
            writer = PyPDF2.PdfFileWriter()
            page_list = []
            is_write_complete = False

    # write the last remaining pages
    if writer.getNumPages() > 0:
        buffer = BytesIO()
        writer.write(buffer)

        # check if split exceeds size limit
        if buffer.getbuffer().nbytes > size_limit:
            logging.info(
                f"File split at split_size={page_limit} exceeded Textract's size limitation"
            )
            if page_limit == 1:
                raise ValueError("Document with a single page cannot be split further!")
            return (math.ceil(page_limit / 2), {})

        tmp_file_name = save_file_splits(file_name, page_number, writer)
        results = merge_textract_results(tmp_file_name, page_list, page_number, results)
        is_write_complete = True
        utils.delete_file_from_s3(tmp_file_name)

    return page_limit, results
