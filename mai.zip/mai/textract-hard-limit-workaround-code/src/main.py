from split import split_merge

import utils
import merge
import document_analysis
import json
import logging
import os
import math
import io

import PyPDF2


# read configurable parameters
with open("../config.json", "rb") as fp:
    config = json.load(fp)

# Textract hard limits
current_async_page_limit = config["current_async_page_limit"]
current_async_size_limit = config["current_async_size_limit"]

# specify the file name as it appears in s3
file_name = config["file_name"]
input_file = io.BytesIO(utils.read_file_from_s3(file_name))

logging.getLogger().setLevel(logging.INFO)


def run_document_detection(file_name):
    job_id = document_analysis.start_job(merge.client, config["BUCKET"], file_name)
    logging.info("Started job with id: {}".format(job_id))

    if document_analysis.is_job_complete(merge.client, job_id):
        response = document_analysis.get_job_results(merge.client, job_id)

    return response


if __name__ == "__main__":
    textract_response = {}

    try:
        if file_name.split(".")[1] == "pdf":
            reader = PyPDF2.PdfFileReader(input_file)
            textract_response = {}
            if reader.getNumPages() > current_async_page_limit:
                logging.info(
                    "Page size exceeds textract hard limit. Starting workaround"
                )
                while True:
                    current_async_page_limit, textract_response = split_merge(
                        file_name,
                        reader,
                        current_async_page_limit,
                        current_async_size_limit,
                    )
                    if len(textract_response) > 0:
                        break

            elif input_file.getbuffer().nbytes > current_async_size_limit:
                page_limit = math.ceil(reader.getNumPages() / 2)
                logging.info(
                    "Document size exceeds textract hard limit. Starting workaround"
                )
                while True:
                    page_limit, textract_response = split_merge(
                        file_name,
                        reader,
                        page_limit,
                        current_async_size_limit,
                    )
                    if len(textract_response) > 0:
                        break
            else:
                logging.info(
                    "Document within textract hard limits. Workaround not required"
                )
                textract_response = run_document_detection(file_name)

            with open(
                f'{file_name.split(".")[0]}_data.json', "w", encoding="utf-8"
            ) as f:
                json.dump(textract_response, f, ensure_ascii=False, indent=4)

        else:
            raise ValueError("Expected a PDF file as input")
    except Exception as e:
        print(e)
