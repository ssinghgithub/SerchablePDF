from typing import Dict
from io import BytesIO
import boto3
import json

import PyPDF2

# read configurable parameters
with open("../config.json", "rb") as fp:
    config = json.load(fp)
BUCKET = config["BUCKET"]

# read input file
def read_file_from_s3(Key: str):
    s3 = boto3.resource("s3")
    obj = s3.Object(BUCKET, Key)
    return obj.get()["Body"].read()


def write_file_to_s3(file_name, writer: PyPDF2.PdfFileWriter) -> Dict:
    s3 = boto3.client("s3")
    with BytesIO() as bytes_stream:
        writer.write(bytes_stream)
        bytes_stream.seek(0)

        # will perform a multipart upload in multiple threads if necessary.
        s3.upload_fileobj(bytes_stream, Bucket=BUCKET, Key=file_name)

    head = s3.head_object(Bucket=BUCKET, Key=file_name)
    success = head["ContentLength"]

    return success


def delete_file_from_s3(file_name: str) -> Dict:
    s3 = boto3.client("s3")
    s3_response = s3.delete_object(Bucket=BUCKET, Key=file_name)
    return s3_response
