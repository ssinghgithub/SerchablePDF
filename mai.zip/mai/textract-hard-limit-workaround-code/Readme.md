# Workaroud for Textract page and size hard limits
Textract is a machine learning (ML) service that automatically extracts text, handwriting, and data from scanned documents. It goes beyond simple optical character recognition (OCR) to identify, understand, and extract data from forms and tables. 

## Limits

Textract has hard and soft limits, as in limits that can’t be modified

Our focus
* 3000 pages per pdf
* 500MB size per pdf

## Architecture
![Architecture Overview](./image.png)

### Implementation

Three main components (run serially)
1. Split
2. Detect Text
3. Merge textract job results

* If PDF has number of pages  > page_limit
```
start
    iterate over each page of the PDF file, 
        when number of pages equals page_limit, the writer writes the pages to a buffer. 
        if buffer size is under size_limit, 
            write buffer to S3, 
            start document detection
            merge results from textract into one json blob
        else 
            return page_limit / 2 as the new page_limit
    repeat above steps for the last partition
    return merged response
end
```

* If PDF has file size  > size_limit
```
start
    call split_merge with page_limit = num_pages/2
        iterate over each page of the PDF file, 
            when number of pages equals page_limit, the writer writes the pages to a buffer. 
                if buffer size is under size_limit, 
                    write buffer to S3, 
                    start document detection
                    merge results from textract into one json blob
                else 
                    return page_limit / 2 as the new page_limit
        repeat above steps for the last partition
    return merged response
end
```
#### Merge function
```
start
    if response is from first split 
       return response 
    else
        for each page
            use page_list to update Blocks['Page']
            add newly detected blocks to existing Blocks
            update DocumentMetadata['Pages'] to current page_number+1
    return merged response
end
```

### Example
1. 9500 pages under 500MB PDF
    * Files will be split into 4 separate files
    * 3000 pages(3 files), 500 pages(1 file)
    * Run each partition through textract
    * Merge the responses into 1 file

### Referances
1. Textract best practices - https://docs.aws.amazon.com/pdfs/textract/latest/dg/textract-dg.pdf#textract-best-practices
2. Document parsing pipeline - https://aws.amazon.com/blogs/machine-learning/build-a-traceable-custom-multi-format-document-parsing-pipeline-with-amazon-textract/
3. PyPDF2 - https://pypdf2.readthedocs.io/en/latest/index.html

#### Code examples
* https://github.com/aws-samples/amazon-textract-code-samples
* https://github.com/aws-samples/amazon-textract-multipage-tables-processing/blob/main/Merge_Table_Notebook.ipynb
* https://github.com/aws-samples/amazon-textract-response-parser/tree/master/src-python


