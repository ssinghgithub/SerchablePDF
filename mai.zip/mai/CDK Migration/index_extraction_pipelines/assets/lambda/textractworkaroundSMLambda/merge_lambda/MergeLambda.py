import json
import time
import os
import boto3
import pandas as pd
from io import StringIO, BytesIO

from botocore.client import Config

config = Config(retries = dict(max_attempts = 5))


client = boto3.client("textract", region_name="us-east-1", config = config)
s3_resource = boto3.resource('s3')
s3_client = boto3.client('s3')

def write_file_to_s3(bucket, file_name, textractOutput):
    s3object = s3_resource.Object(bucket, file_name)
    s3object.put(
        Body=(bytes(json.dumps(textractOutput).encode('UTF-8')))
    )


def get_job_results(client, job_id, max_results):
    job_results_response = client.get_document_text_detection(JobId=job_id, MaxResults=max_results)
    nextToken = job_results_response["NextToken"] if "NextToken" in job_results_response else None

    while nextToken:
        response = client.get_document_text_detection(JobId=job_id, NextToken=nextToken, MaxResults=1000)
        job_results_response["Blocks"].extend(response["Blocks"])
        nextToken = response["NextToken"] if "NextToken" in response else None

    return job_results_response


def convert_json_to_df(json_data,file_name):
    page_lines = {}
    for item in json_data['Blocks']:
        if item["BlockType"] == "LINE":
            if item["Page"] in page_lines.keys():
                        page_lines[item["Page"]].append(item["Text"])
            else:
                page_lines[item["Page"]] = []
    
    df = pd.DataFrame(page_lines.items())
    df.columns = ["PageNo", "Text"]
    df['FileName'] = file_name.split('/')[-1]
    df['FileName'] = file_name
    df = df[['FileName', 'PageNo', 'Text']]
   
    return df
    

def lambda_handler(event, context):
    object_name = event["Records"]["object"].split('.')[0]
    textract_job = event["Records"]["textractJob"]
    merged_output_bucket = event["Records"]["s3Bucket"]
    merge_complete = event["merge_complete"] # initially false
    merged_response = event["merged_response"] #empty list initially
    total_splits_count = int(event["total_splits_count"])
    merged_splits_count = int(event["merged_splits_count"])

    # fetch job ids in a list
    job_ids = [item["jobId"] for item in textract_job]
    # merged_data_file = f"{os.environ['MERGED_LOC']}{object_name.split('/')[-1].split('.')[0]}.json"
    merged_data_file = f"{os.environ['MERGED_RES_LOC']}{object_name.split('/')[-1].split('.')[0]}.csv"

    
    
    combined_response = {}
    
    if merged_splits_count != total_splits_count:
        if len(merged_response)==0:
            print("Fetching result for first split")
            combined_response = get_job_results(client, job_ids[0], 1000)
            
            # read combined_response(json) in a dataframe
            original_file_name = object_name.split('/')[-1]
            combined_response_df = convert_json_to_df(combined_response,original_file_name)
            
            # convert df to csv and ulpoad it to s3
            csv_buffer = StringIO()
            combined_response_df.to_csv(csv_buffer)
            s3_resource.Object(merged_output_bucket, merged_data_file).put(Body=csv_buffer.getvalue())
            
            # Move first split to merged_response from event["Records"]["textractJob"]
            merged_response.append(event["Records"]["textractJob"][0])
            # remove first job (processed above) from the textract job list
            event["Records"]["textractJob"].pop(0)

            # increment merged_splits_count
            merged_splits_count+=1
            event["merged_splits_count"]=merged_splits_count
            
            print(f"First Split textract output is uploaded to s3://{merged_output_bucket}/{merged_data_file}")

        else:
            print("Fetching result for remaining splits")
            
            # read response (csv) from previous splits stored in s3
            obj = s3_client.get_object(Bucket=merged_output_bucket, Key=merged_data_file)
           
            # read contente as dataframe
            s3_combined_response_df =pd.read_csv(obj['Body']) # 'Body' is a key word
           
            # fetch last page num from previous splits
            last_page_num = max(s3_combined_response_df['PageNo'])
           
            # Fetch the response for this split and update page number accordingly
            response = get_job_results(client, job_ids[0], 1000)
            # Update the page nums in this response block
            for i, block in enumerate(response['Blocks']):
                response['Blocks'][i]['Page'] = int(response['Blocks'][i]['Page']) \
                                                + last_page_num
            
             # read response(json) in a dataframe
            original_file_name = object_name.split('/')[-1]
            response_df = convert_json_to_df(response,original_file_name)
           
           
            # Append response_df to combined_response_df
            combined_response_df = s3_combined_response_df.append(response_df)
            
            # convert combined_response_df to csv and ulpoad it to s3
            csv_buffer = StringIO()
            combined_response_df.to_csv(csv_buffer)
            s3_resource.Object(merged_output_bucket, merged_data_file).put(Body=csv_buffer.getvalue())
            
         
            # write_file_to_s3(merged_output_bucket, merged_data_file, combined_response)
            print(f"Remaining Splits textract output is being merged and uploaded to s3://{merged_output_bucket}/{merged_data_file}")
            
            
            # Move first split to merged_response from event["Records"]["textractJob"]
            merged_response.append(event["Records"]["textractJob"][0])
            event["Records"]["textractJob"].pop(0)

            # increment merged_splits_count
            merged_splits_count += 1
            event["merged_splits_count"] = merged_splits_count
   

    event["merge_complete"] ='true' if total_splits_count == merged_splits_count else 'false'
    
    print("merge_complete flag:",event["merge_complete"])
  
    print("First Page: ",min(combined_response_df['PageNo']))
    print("Last Page: ", max(combined_response_df['PageNo']))
    
    return event