import json
import boto3
import time
import logging

textract_client = boto3.client("textract", region_name="us-east-1")


def fetch_job_status(textract_client, job_id):
    # time.sleep(5)
    response = textract_client.get_document_text_detection(JobId=job_id)
    status = response["JobStatus"]
    return status


def lambda_handler(event, context):
    print("Event inside check_job_status_lambda:", event)
    object_name = event["Records"]["object"]
    textract_job = event["Records"]["textractJob"]
    input_bucket = event["Records"]["s3Bucket"]
    job_details = []
    job_status = ""
    total_jobs = len(textract_job)
    # completed_jobs = 0
    succeeded_jobs = 0
    failed_jobs = 0
    
    # Fetch job status of each splitted Textract jobs
    for item in event["Records"]["textractJob"]:
        item["jobStatus"] = fetch_job_status(textract_client, item["jobId"])
        temp = {
            "file_name": item['file_name'],
            "page_numbers": item['page_numbers'],
            "jobId": item["jobId"],
            "status": item["jobStatus"]
        }
        job_details.append(temp)
        
    # count number of Textract jobs SUCEEDED        
    if any(job["jobStatus"] in ["SUCCEEDED", "FAILED" ] for job in event["Records"]["textractJob"]):
      textract_job_status = [job["jobStatus"] for job in event["Records"]["textractJob"]]
      succeeded_jobs = textract_job_status.count("SUCCEEDED")
      failed_jobs = textract_job_status.count("FAILED")
      
    # Overall Job status for all Textract splitted Jobs
    if total_jobs == succeeded_jobs:
        job_status = "SUCCEEDED" 
    elif failed_jobs>0:
        job_status = "FAILED"
    else:
        job_status = "IN_PROGRESS"

    return {
        'JobStatus': job_status,
        'merge_complete': "false",
        'merged_response': [],
        'total_splits_count': len(job_details),
        'merged_splits_count': 0,
        'Records': {
            'object': object_name,
            'textractJob': job_details,
            's3Bucket': input_bucket
        }
    }
