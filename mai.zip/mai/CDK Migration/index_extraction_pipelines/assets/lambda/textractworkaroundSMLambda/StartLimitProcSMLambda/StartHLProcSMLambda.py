import json
import boto3
import os

sqs_client = boto3.client('sqs')
sf_client = boto3.client('stepfunctions')


def lambda_handler(event, context):
    print(event)

    response = {}

    # messageBody = json.loads(event['Records'][0]['body'])
    bucketName = event['Records'][0]['messageAttributes']['bucket']['stringValue']
    objectName = event['Records'][0]['messageAttributes']['object']['stringValue']
    documentId = event['Records'][0]['messageId']
    receipt_handle = event['Records'][0]['receiptHandle']
    # limit_type = messageBody['limit_type']
    # textract_file_size_limit = messageBody['textract_file_size_limit']
    # textract_page_size_limit = messageBody['textract_page_size_limit']

    response['bucketName'] = bucketName
    response['objectName'] = objectName
    response['documentId'] = documentId
    # response['limit_type'] = limit_type
    # response['textract_file_size_limit'] = textract_file_size_limit
    # response['textract_page_size_limit'] = textract_page_size_limit

    sf_client.start_execution(
        stateMachineArn=os.environ['STATE_MACHINE_ARN'],
        name=documentId,
        input=json.dumps(response)
    )

    print("response:", response)

    sqs_client.delete_message(
        QueueUrl=os.environ['LIMIT_QUEUE_URL'],
        ReceiptHandle=receipt_handle
    )
