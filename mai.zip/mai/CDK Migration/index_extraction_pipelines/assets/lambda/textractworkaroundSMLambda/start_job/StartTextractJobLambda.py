import json
import boto3
from botocore.client import Config

config = Config(retries = dict(max_attempts = 5))

textract_client = boto3.client('textract',config = config)

def start_textract_job(s3_bucket_name, object_name):
    response = textract_client.start_document_text_detection(
        DocumentLocation={"S3Object": {"Bucket": s3_bucket_name, "Name": object_name}}
    )

    return response["JobId"]


def lambda_handler(event, context):
    print(event["Records"]["object"])

    object_name = event["Records"]["object"]
    splits = event["Records"]["split"]
    input_bucket = event["Records"]["outputBucketName"]
    job_list = []

    for item in splits:
        # print("input_bucket:",input_bucket)
        # print("object_name: ",  item['file_name'])
        jobId = start_textract_job(input_bucket, item['file_name'])
        
        # fetch Job status
        response = textract_client.get_document_text_detection(JobId=jobId)
        status = response["JobStatus"]
        
        temp = {
            "file_name": item['file_name'],
            "page_numbers": item['page_numbers'],
            "jobId": jobId,
            "jobStatus": status
        }
        job_list.append(temp)

    return {
        'JobStatus':"IN_PROGRESS",
        'Records': {
            'object': object_name,
            'textractJob': job_list,
            's3Bucket': input_bucket
        }
    }