import os
import json
import boto3
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


state_machine_arn = os.environ['STATE_MACHINE_ARN']
client = boto3.client('stepfunctions')


def lambda_handler(event, context):
    print(event)
    
    try:
        for record in event['Records']:
            response = client.start_execution(
                stateMachineArn=state_machine_arn,
                input=json.dumps(record['s3'])
        )
        
    except Exception as e:
            print("Error starting state machine execut: {}".format(e))
        
    return print(response)