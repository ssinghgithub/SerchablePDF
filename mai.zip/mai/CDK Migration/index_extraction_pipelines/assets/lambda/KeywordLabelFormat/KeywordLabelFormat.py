import json
import boto3
import os
import logging
import pandas as pd
import numpy as np

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    
    
    s3_client = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    
    
    bucket = os.environ['bucketName']
    key = event['latest_label_file']
    
    response = s3_client.list_objects_v2(Bucket=bucket, Prefix=key)
    contents = response['Contents']        
    latest_label_file = max(contents, key=lambda x: x['LastModified'])
    latest_label_file = latest_label_file['Key']
    s3_client.download_file(bucket,latest_label_file,'/tmp/BatchLabel.csv' )
    # s3_client.download_file(bucket,key,'/tmp/BatchLabel.xlsx' )
    

    s3_location = 's3://'+bucket+'/'+key
    print(s3_location)

    try: 

        # key_file = pd.read_excel(s3_location)

        # key_file = pd.read_excel("/tmp/BatchLabel.xlsx")
        key_file = pd.read_csv("/tmp/BatchLabel.csv")

        label_from_all = key_file['CRFieldName']
        valid_label_df = key_file.dropna(subset = ['User entered Pages'])
        
        df = valid_label_df

        modified_df =  pd.DataFrame()

        for i in range(len(df)):
            col = 'User entered Pages'
            filename = df.iloc[i]['CRFileName'].split("_")[-2] + "_" + df.iloc[i]['CRFileName'].split("_")[-1]
            filename_cut = filename.split('_')[-2][-6:]
            # print(filename)
            ds =  df.iloc[i][col]
            temp_list = []
            if str(ds).startswith('-'):
                ds = str(ds)[1:]
            if str(ds).endswith('-') :
                ds = str(ds)[:-1]

            try:
                if not pd.isna(df.iloc[i][col]):
                    try:
                        ds = int(ds)
                        # Remove labels with page 0
                        if ds == 0:
                            continue
                        else:
                            temp_list.append(ds)
                    except:
                        if (ds.split(',').__len__() > 1):
                            for j in range(len(ds.split(','))):
                                if '-' in ds.split(',')[j].strip():
                                    min_no = int(ds.split(',')[j].split('-')[0])
                                    max_no = int(ds.split(',')[j].split('-')[1])
                                    temp_list.extend(list(range(min_no, max_no + 1)))
                                elif '-' not in ds.split(',')[j].strip():
                                    if ds.split(',')[j].strip().split('-') == ['']:
                                        pass
                                    else:
                                        min_no = int(ds.split(',')[j].strip().split('-')[0])
                                        temp_list.extend([min_no])
                        else:
                            try:
                                for j in range(len(ds.split(','))):
                                    min_no = int(ds.split(',')[j].split('-')[0])
                                    max_no = int(ds.split(',')[j].split('-')[1])
                                    temp_list.extend(list(range(min_no,max_no + 1)))

                                if len(ds.split(',')[j].split('-')) == 1:
                                    temp_list.append(int(ds))

                            except Exception as e:
                                print(e)

                modified_df = pd.concat([modified_df, pd.DataFrame.from_dict ({'page':temp_list,'class': df.iloc[i]['CRFieldName'] , 'filename' : filename, 'filename_cut' : filename_cut})], ignore_index = True)
            except Exception as e:
                print(e)
                
        # Convert Page to Int
        modified_df['page'] = modified_df['page'].astype(int)

        modified_df.to_csv("/tmp/batch3_label_revised.csv", index=False)

        s3_resource.meta.client.upload_file('/tmp/batch3_label_revised.csv',Bucket=bucket,Key = 'cdkdeployment-ss/training/reformatted_label/batch3_label_revised.csv')

        
    except Exception as e:
            print("Error while processing event: {}".format(e))
        
 