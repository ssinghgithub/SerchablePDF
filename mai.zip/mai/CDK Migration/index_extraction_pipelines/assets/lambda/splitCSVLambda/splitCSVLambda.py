import json
import boto3
import os
import logging
import pandas as pd
import numpy as np
import io

import tarfile
s3 = boto3.client('s3')
s3_resource = boto3.resource('s3')
def lambda_handler(event, context):
    print("Event:", event)
    ref_file_loc = os.environ['INPUT_REF']
    inputBucket = event['Records'][0]["s3"]["bucket"]["name"]
    inputKey = event['Records'][0]["s3"]["object"]["key"]
        
    print(inputKey)

    obj = s3.get_object(Bucket=inputBucket,Key=inputKey)
    body = obj['Body'].read()    
   

    with tarfile.open(fileobj=io.BytesIO(body), mode="r:gz") as file:
        file_content_byte = file.extractfile("predictions.jsonl").read().decode('utf-8')

    jsonlines = [(json.loads(jline)) for jline in file_content_byte.splitlines()]
    reference_file_name = jsonlines[0]['File']

    s3.download_file(inputBucket,ref_file_loc+reference_file_name,'/tmp/reference.csv')
    
    print("File downlaoded to temp loc.")
    df = pd.read_csv("/tmp/reference.csv")
    result = pd.DataFrame(jsonlines)
    result['Filenames'] = df['FileName']
    # result = result.drop_duplicates()

    print(result['Filenames'].unique())
    print(len(result['Filenames'].unique()))

    temp_list = []

    for file in result['Filenames'].unique():
        temp = result[result['Filenames']==file]
        temp = temp.reset_index(drop=True)
        temp.reset_index(inplace=True)
        temp_list.append(temp)

    for frame in temp_list:

        frame.to_json("/tmp/predictions.jsonl",orient='records',lines=True)

        with tarfile.open("/tmp/"+frame['Filenames'].values[0]+".tar.gz", "w:gz") as tar:
            tar.add("/tmp/predictions.jsonl")
        if '1003700000000809321_11399313' not in frame['Filenames'].values[0]:
            s3_resource.meta.client.upload_file("/tmp/"+frame['Filenames'].values[0]+".tar.gz",inputBucket,os.environ['OUTPUT_KEY']+frame['Filenames'].values[0]+".tar.gz")
