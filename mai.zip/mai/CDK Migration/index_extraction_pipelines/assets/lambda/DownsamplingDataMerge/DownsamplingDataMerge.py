import json
import boto3
import os
import logging
import pandas as pd
import numpy as np
from io import BytesIO

logger = logging.getLogger()
logger.setLevel(logging.INFO)



def lambda_handler(event, context):

    keywords_usage_flag = os.environ['KEYWORD_USAGE_FLAG']

    s3_client = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    
    bucket = event['Records'][0]['s3']['bucket']['name']
    
    key = event['Records'][0]['s3']['object']['key']

    s3_location = 's3://'+bucket+'/'+key
    print(s3_location)
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']
    
    s3_client.download_file(bucket,key,'/tmp/Textract_large_output.csv' )


    textract_df = pd.read_csv("/tmp/Textract_large_output.csv")
    textract_df.rename(columns={'FileName' : 'filename', 'Text' : 'content', 'PageNo':'page'}, inplace=True)
    textract_df['filename'] = textract_df['filename'].str.split('_').str[-2] + '_' + textract_df['filename'].str.split('_').str[-1]
    label_key = os.environ['LABEL_PREFIX']
    keywords_prefix = os.environ['KEYWORDS_PREFIX']
    s3_client.download_file(bucket,keywords_prefix,'/tmp/keywords_to_training.csv')
    s3_client.download_file(bucket, label_key,'/tmp/batch3_label_revised.csv' )

    # label_file = os.environ['LABEL_REVISED']
    label_df = pd.read_csv('/tmp/batch3_label_revised.csv')

    # Load keyword file
    keywords_df = pd.read_csv('/tmp/keywords_to_training.csv')
    

    common_files = set(textract_df.filename).intersection(label_df.filename)

    textract_df = textract_df[textract_df.filename.isin(common_files)]

    textract_df.drop_duplicates(inplace=True)

    textract_df.dropna(subset=['content'], inplace=True)

    merged_file = pd.merge(textract_df, label_df, how = "left", on = ["filename", "page"])

    merged_file['class'] = merged_file['class'].fillna('others')

    merged_file = merged_file[['content', 'class']].drop_duplicates().groupby('content')['class'].apply('|'.join).reset_index()

    merged_file = merged_file[['class', 'content']]
    # Check the distribution of each class, which will be used later to choose the number of records needs to be filtered out 
    temp = pd.merge(textract_df, label_df, how = "left", on = ["filename", "page"])

    #Down sampling
    class_distribution = (temp['class'].value_counts()).to_dict()
    lowest_distribution = sorted(class_distribution.items(), key=lambda item:item[1])[0]
    print(lowest_distribution)
    max_value = lowest_distribution[1]*10
    
    for k,v in class_distribution.items():
        
        if v > max_value:
            class_distribution[k] = v-max_value-1
            
    print(class_distribution)
    

    merged_df = temp.copy()
    ## Drop others records
    for k,v in class_distribution.items():
        frac_num = v
        merged_df = merged_df.drop(merged_df[merged_df['class']==k].sample(frac_num).index)
        
    # frac_num = 489000
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='others'].sample(frac_num).index)
    # ## Drop flowsheets records

    # frac_num = 87983
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='flowsheets'].sample(frac_num).index)
    # ## Drop progress_notes records

    # frac_num = 54385
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='progress_notes'].sample(frac_num).index)
    # ## Drop mar records

    # frac_num = 37570
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='mar'].sample(frac_num).index)
    # ## Drop labs records

    # frac_num = 35124
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='labs'].sample(frac_num).index)
    # ## Drop consult records

    # frac_num = 9592
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='consult'].sample(frac_num).index)
    # ## Drop radiology records

    # frac_num = 6888
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='radiology'].sample(frac_num).index)
    # ## Drop history_physical records

    # frac_num = 7083
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='history_physical'].sample(frac_num).index)
    # ## Drop emergency_department records

    # frac_num = 6153
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='emergency_department'].sample(frac_num).index)
    # ## Drop discharge_summary records

    # frac_num = 4632
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='discharge_summary'].sample(frac_num).index)
    # ## Drop admission_order records

    # frac_num = 685
    # merged_df = merged_df.drop(merged_df[merged_df['class']=='admission_order'].sample(frac_num).index)
    # # Load keyword file
    # # keywords_df = pd.read_csv('keywords_to_training_v2.csv')
    
    # Merge keyword records to training file
    # merged_df_downsample = pd.concat([merged_df, keywords_df], axis=0, ignore_index=True)
    
    # Save prepared training data locally
    merged_df['label_file'] = key
    comprehend_training_input = merged_df[['class','content']]
    if keywords_usage_flag == "TRUE":
        comprehend_training_input = pd.concat([comprehend_training_input,keywords_df], axis=0, ignore_index=True)
        
    comprehend_training_input = comprehend_training_input.dropna()
    comprehend_training_input.to_csv('/tmp/comprehend_training_data.csv', index=False, header=False)
    merged_df.to_csv('/tmp/training_data.csv', index=False, header=False)
    s3_resource.meta.client.upload_file('/tmp/comprehend_training_data.csv',Bucket=bucket,Key = 'cdkdeployment-ss/training/comprehend_training_input/comprehend_training_data.csv')
    # s3_resource.meta.client.upload_file('/tmp/training_data.csv',Bucket=bucket,Key = 'cdkdeployment-ss/training/comprehend_training_input/training_data.csv')
