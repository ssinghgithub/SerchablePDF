import json
import boto3
import os
import logging
import pandas as pd
import numpy as np
import io
from helper import *
from datetime import datetime
import re
import string

chars = re.escape(string.punctuation)
time_value = re.sub('['+chars+', " "]', '_',str(datetime.now()))
# time_value = str(datetime.now())
logger = logging.getLogger()
logger.setLevel(logging.INFO)

input_queue_url = os.environ['QUEUE_URL']

def lambda_handler(event, context):
    
    try:
        s3_client = boto3.client('s3')
        s3_resource = boto3.resource('s3')
        sqs = boto3.client('sqs')
        
        large_csv = []
        merged_csv =[]
        msg_count = 0
        for message in get_messages_from_queue(queue_url=input_queue_url):
            # process message body
            msg_count +=1
            body = json.loads(message['Body'])
            large_csv.append(body)
        
        print(msg_count)
        print(f"Number of messages received: {len(large_csv)}")
        print(large_csv[0])
    # Process Messages 
        for count, messageBody in enumerate(large_csv):
            # print(f'{count} - {msg}')
            # messageBody = json.loads(msg['Records'][count]['body'])
            if 'Records' in messageBody:
                bucketName = messageBody['Records'][0]['s3']['bucket']['name']
                objectName = messageBody['Records'][0]['s3']['object']['key']
                obj = s3_resource.Object(bucketName,objectName)
                body = obj.get()['Body'].read()
                data = pd.read_csv(io.BytesIO(body), encoding='utf8')
                merged_csv.append(data)
        
        merged_csv = pd.concat(merged_csv)
        
        # print(merged_csv.head())
        merged_csv.to_csv('/tmp/merged_csv_comprehend_input.csv',index=False)
        s3_resource.meta.client.upload_file('/tmp/merged_csv_comprehend_input.csv',Bucket=os.environ['BUCKET'],Key=os.environ['OUTPUT_REF_PREFIX']+"/merged_CSV_comprehend_input_{}.csv".format(time_value))

        merged_csv = merged_csv[['Text']]
        merged_csv.to_csv('/tmp/merged_csv_comprehend_input.csv',index=False,header=False)
        s3_resource.meta.client.upload_file('/tmp/merged_csv_comprehend_input.csv',Bucket=os.environ['BUCKET'],Key=os.environ['OUTPUT_PREFIX']+"/merged_CSV_comprehend_input_{}.csv".format(time_value))

        

    except Exception as e:
        print("error : ",e)


 