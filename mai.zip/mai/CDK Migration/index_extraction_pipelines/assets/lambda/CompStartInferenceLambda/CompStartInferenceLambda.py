import json
import boto3
import os
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)
import uuid
import datetime

def start_job(s3InputUri, s3OutputUri, KMSKeyId, data_access_role_arn, document_classifier_arn,filename):
    REGION = 'us-east-1'
    comprehend_client = boto3.client('comprehend', region_name = REGION)
    
    
    try:
        # Start Document Classfiication using the trained model
        start_response = comprehend_client.start_document_classification_job(
            # JobName=str(uuid.uuid4()),
            JobName = filename,
            InputDataConfig={
                'S3Uri': s3InputUri,
                'InputFormat': 'ONE_DOC_PER_LINE'
            },
            OutputDataConfig = {
            "S3Uri": s3OutputUri,
            "KmsKeyId": KMSKeyId},
            
            DataAccessRoleArn =  data_access_role_arn,
            VolumeKmsKeyId =  KMSKeyId,
            
            DocumentClassifierArn= document_classifier_arn
        )
        
        print("Start response: %s\n", start_response)
        
        
        job_id = start_response['JobId']
        
    
    except Exception as e:
            print("Error while starting inference job: {}".format(e))

    return {
        "job_id": job_id, 
        "classifierArn": document_classifier_arn
    }
    



def lambda_handler(event, context):

    try:

        print("event: {}".format(event))
    
        input_bucket = event['bucket']['name']
        input_key = event['object']['key']
        filename = input_key.split('/')[-1][:-4]
        s3InputUri = "s3://"+input_bucket+"/"+input_key
        
        
        KMSKeyId = os.environ['KMS_KEY']
        s3OutputUri = os.environ['INFERENCE_RESULTS']
        data_access_role_arn = os.environ['DATA_ACCESS_ROLE_ARN']
        document_classifier_arn = os.environ['DOC_CLASS_ARN']
    
    except Exception as e:
            print("Error while handling event: {}".format(e))
        

    # return start_job(s3InputUri, s3OutputUri, KMSKeyId, data_access_role_arn, document_classifier_arn)
    return start_job(s3InputUri, s3OutputUri, KMSKeyId, data_access_role_arn, document_classifier_arn,filename)



