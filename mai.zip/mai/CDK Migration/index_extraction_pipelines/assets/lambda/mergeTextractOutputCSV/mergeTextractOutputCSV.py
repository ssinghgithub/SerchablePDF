import json
import boto3
import os
import logging
import pandas as pd
import numpy as np
import io


logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    
    try:
        s3_client = boto3.client('s3')
        s3_resource = boto3.resource('s3')
        
        
        bucket_name = os.environ['bucketName']
        textract_csv_prefix = os.environ['INPUT_PREFIX']
        bucket = s3_resource.Bucket(bucket_name)
    
        large_csv = []
    
        for objects in bucket.objects.filter(Prefix=textract_csv_prefix):
            if  objects.key.endswith('.csv'):
                print(objects.key)
                body = objects.get()['Body'].read()
                data = pd.read_csv(io.BytesIO(body), encoding='utf8')
                large_csv.append(data)
    
        large_csv = pd.concat(large_csv)
        
        print(large_csv.head())
        large_csv.to_csv('/tmp/large_textract_output.csv',index=False)
        s3_resource.meta.client.upload_file('/tmp/large_textract_output.csv',Bucket=bucket_name,Key=os.environ['OUTPUT_PREFIX']+"large_textract_output.csv")

    except Exception as e:
        print("error : ",e)


 