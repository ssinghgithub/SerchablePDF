import json
import boto3
import os
import PyPDF2
import io
import logging
from helperFuncs import *

from botocore.client import Config

config = Config(retries = dict(max_attempts = 5))

textract_client = boto3.client('textract',config = config)

s3_client = boto3.client('s3')

s3_resource = boto3.resource('s3')


def lambda_handler(event, context):
    
    # Read environment variables
    try:
        snsTopic = os.environ['SNS_TOPIC_ARN']
        snsRole = os.environ['SNS_ROLE_ARN']
        KMSKey = os.environ['KMS_KEY']
        output_location = os.environ['TEXTRACT_OUTPUT_LOC']
        bucket_name = os.environ['BUCKET']
        input_pdf_prefix = os.environ['INPUT_PREFIX']
        textract_jobs_log = os.environ['TEXTRACT_JOBS_LOG']
        limit_queue_url = os.environ['LIMIT_QUEUE_URL']
        
        textract_submit_list = {}

        bucket = s3_resource.Bucket(bucket_name)

        textract_limit_exceed = []

        for obj in bucket.objects.filter(Prefix=input_pdf_prefix):
            if  obj.key.endswith('.pdf'):
                objectname = 's3://'+bucket_name+'/'+obj.key
                print(objectname)

                filename = obj.key.split('/')[-1][:-4]
                limit_exceed_flag, limit_type = check_limits(bucket_name, obj.key)
                
                if limit_exceed_flag:
                    print(limit_type)
                    response = write_message_to_queue(bucket_name, obj.key, limit_type, limit_queue_url)
                    # print(response)
                    textract_limit_exceed.append(f's3://{bucket_name}/{obj.key}')
                    textract_submit_list[filename] = ""

                else:
                    response = startJob(bucket_name,obj.key,snsTopic,snsRole, output_location, bucket_name, KMSKey)
                    textract_submit_list[filename] = response

        print(textract_submit_list)

        s3_client.put_object(Body=json.dumps(textract_submit_list),Bucket=bucket_name,Key = textract_jobs_log)

        print("These files are sent for workaround with > 3000 pages", textract_limit_exceed)
        
      
        return {
            'statusCode': 200,
            'body': json.dumps('Textract job submitted successfully')
        }

    except Exception as e:
        print(e)
        return e


