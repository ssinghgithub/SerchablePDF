import json
import boto3
import time
import logging
import os
import pandas as pd
from io import StringIO

s3_resource = boto3.resource('s3')
s3_client = boto3.client('s3')
lambda_client = boto3.client('lambda')

customer_name = os.environ['CUSTOMER_NAME']
bucket_name = os.environ['BUCKET_NAME']
merged_output_loc = os.environ['PREFIX']
textract_jobs_log = os.environ['TEXTRACT_JOBS_LOG']
latest_label_file = os.environ['RAW_LABEL']

def lambda_handler(event, context):

    file_name = event['merged_json_location']

    content = s3_resource.Object(bucket_name, file_name)
    file_content = content.get()['Body'].read().decode('utf-8')
    data = json.loads(file_content)

    page_lines = {}
    for item in data['Blocks']:
        if item["BlockType"] == "LINE":
            if item["Page"] in page_lines.keys():
                        page_lines[item["Page"]].append(item["Text"])
            else:
                page_lines[item["Page"]] = []
    
    df = pd.DataFrame(page_lines.items())
    df.columns = ["PageNo", "Text"]
    df['FileName'] = file_name.split('/')[-1]
    df = df[['FileName', 'PageNo', 'Text']]

    csv_buffer = StringIO()

    df.to_csv(csv_buffer)

    s3_resource.Object(bucket_name,merged_output_loc+'/'+file_name+'.csv').put(Body=csv_buffer.getvalue())

    if len(set(file_content.values())) == 1:
            print(file_content)
            if 'SUCCEEDED' in set(file_content.values()):
                lambda_client.invoke(FunctionName=customer_name+'_keyword_label_formatting',
                                    InvocationType = 'Event',
                                    Payload= json.dumps({'latest_label_file':latest_label_file})
                )
                
                print("Successfully completed all textract jobs - notify")
                
                s3_client.delete_object(Bucket=bucket_name, Key =textract_jobs_log)
                return {"statusCode": 200, "body": json.dumps("File uploaded successfully!")}





