import json
import boto3
import os
import logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def get_job_status(job_id, document_classifier_arn):
    REGION = 'us-east-1'
    comprehend_client = boto3.client('comprehend', region_name = REGION)
    
    try:
        # Check the status of the job
        describe_response = comprehend_client.describe_document_classification_job(JobId=job_id)
        print("Describe response: %s\n", describe_response)
        
        status = describe_response['DocumentClassificationJobProperties']['JobStatus']
        print('Job status is:', status)
        
        # List all classification jobs in account
        #list_response = comprehend_client.list_document_classification_jobs()
        #print("List response: %s\n", list_response)
        
    except Exception as e:
            print("Error while getitng document classification job status : {}".format(e))

    return {
        'job_id': job_id,
        'classifierArn': document_classifier_arn,
        'Status':status
    }

def lambda_handler(event, context):
   
    try: 
        print("event: {}".format(event))
        job_id = event['Payload']['job_id']
        document_classifier_arn = event['Payload']['classifierArn']
        print("Document Classifier ARN is: ", document_classifier_arn)
        print("Job ID is: ", job_id)
        
    except Exception as e:
            print("Error while processing event: {}".format(e))
        
    return get_job_status(job_id, document_classifier_arn)
        
        
