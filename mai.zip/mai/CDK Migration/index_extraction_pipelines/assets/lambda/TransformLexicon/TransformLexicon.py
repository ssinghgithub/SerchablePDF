import json
import boto3
import tarfile
import os 
import io
from io import BytesIO
import re
import gzip
import boto3
from urllib.parse import unquote_plus


def lambda_handler(event, context):
    
    s3 = boto3.client('s3')
    
    print(event)
    
    #Read in environment variables
    
    outputBucket = os.environ['OUTPUT_BUCKET']
    outputKey = os.environ['OUTPUT_KEY']
    score = os.environ['SCORE']

    for record in event['Records']:
    
        inputBucket = record["s3"]["bucket"]["name"]
        inputKey = record["s3"]["object"]["key"]
        
        print(inputKey)
    
        obj = s3.get_object(Bucket=inputBucket,Key=inputKey)
        body = obj['Body'].read()
    
        predictions_list=[]
    
        #Extract predictions.jsonl and read from S3
        
        with tarfile.open(fileobj=BytesIO(body), mode="r:gz") as file:
            tar_file_content = file.getmembers()
            file_content_byte = file.extractfile(tar_file_content[0]).read().decode('utf-8')
            
        lines = file_content_byte.splitlines()
    
        # Only keep predictions where Score is above threshold
        print(lines[:1])
        for line in lines: 
            jsonl = json.loads(line)
            output_line = {} 
            for k, v in enumerate(jsonl['Labels']):
                    if v['Score'] > float(score) :
                        page = int(jsonl["index"]) + 1
                        output_line['page'] = page
                        output_line['class'] = v['Name']
                        output_line['FileName'] = jsonl["Filenames"]
                        #break
                        try:
                            output_line.pop('File') #.pop()
                        except :
                            pass
                            #print(f"failed for {f}")
                        predictions_list.append(output_line.copy())
        
        print(predictions_list)
    
    
    
        #Convert to Lexicon Format
        
        seen_list =  []
        output_file = []
    
        for f in predictions_list:
            if f['FileName'] in seen_list:
                
                output_class = f['class']
                output_dict['FileName'] = f['FileName']
                
                if f['class'] in output_dict['Results']:# and f['class'] != 'others':
                    output_dict['Results'][output_class]['classification_pages'] = output_dict['Results'][output_class]['classification_pages'] + ',' + str(f['page'])
                    
                else:
                    
                    if f['class'] != 'others' :
                        output_dict['Results'].update({output_class: {'classification_pages' : str(f['page'])}})
                
                #output_dict['Results'] = {repl.get(k, k): output_dict['Results'][k] for k in output_dict['Results']}
                #output_dict['Results'] = output_chk
                #print(output_dict)
    
                s3.put_object(Bucket=outputBucket, Key=outputKey+f['FileName'] + "-output.json", Body=(json.dumps(output_dict).encode('UTF-8')))
                
    
                    
                #break
            else:
                #break
                seen_list.append(f['FileName'])
                output_dict = {
                    'FileName' :'' ,'Results' : {}
                }








