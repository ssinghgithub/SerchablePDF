import json
import boto3
import os
import logging
import pandas as pd
import numpy as np
import io
from multiprocessing import Process

import tarfile
s3 = boto3.client('s3')
s3_resource = boto3.resource('s3')
def lambda_handler(event, context):
    # ref_file_loc = os.environ['INPUT_REF']
    # inputBucket = event['Records'][0]["s3"]["bucket"]["name"]
    # inputKey = event['Records'][0]["s3"]["object"]["key"]
        
    # print(inputKey)

    obj = s3.get_object(Bucket='nlp-dev1',Key="cdkdeployment-ss/comprehendOutputFolder/500927421718-CLN-5d82fa327da120402cbc21f2ae7a4b9f/output/output.tar.gz")
    body = obj['Body'].read()    
   

    with tarfile.open(fileobj=io.BytesIO(body), mode="r:gz") as file:
        file_content_byte = file.extractfile("predictions.jsonl").read().decode('utf-8')

    jsonlines = [(json.loads(jline)) for jline in file_content_byte.splitlines()]

    s3.download_file("nlp-dev1","cdkdeployment-ss/comprehendMergedInputReference/merged_CSV_comprehend_input.csv",'/tmp/reference.csv')

    df = pd.read_csv("/tmp/reference.csv")
    result = pd.DataFrame(jsonlines)
    result['Filenames'] = df['FileName']
    # result = result.drop_duplicates()
    count = 0
    def func(x,result):
        global count
        temp = result[result['Filenames']==x]
        temp = temp.reset_index(drop=True)
        temp.reset_index(inplace=True)
        temp.to_json("/tmp/{}-predictions1.jsonl".format(x),orient='records',lines=True)
        with tarfile.open("/tmp/"+x+".tar.gz", "w:gz") as tar:
            tar.add("/tmp/{}-predictions1.jsonl".format(x))
        
        if '1003700000000809321_11399313' not in temp['Filenames'].values[0]:
            s3_resource.meta.client.upload_file("/tmp/"+x+".tar.gz","nlp-dev1","cdkdeployment-ss/multi/"+x+".tar.gz")

        # print(temp.head())
  
        # print(count)
    vals = result['Filenames'].unique()  
    processes = []
    for file in vals:
        
        process = Process(target = func, args =(file,result))
        processes.append(process)
        
    for process in processes:
        process.start()
        
    for process in processes:
        process.join()

    # for i in args:
    #   result = p.apply_async(func,(i,result))
    #   print(result.head())