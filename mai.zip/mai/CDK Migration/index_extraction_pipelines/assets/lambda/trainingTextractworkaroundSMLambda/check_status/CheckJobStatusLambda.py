import json
import boto3
import time
import logging
import os

textract_client = boto3.client("textract", region_name="us-east-1")
s3_resource = boto3.resource('s3')
s3_client = boto3.client('s3')
lambda_client = boto3.client('lambda')

invoking_lambda = os.environ['INVOKING_LAMBDA']
label_file_prefix = os.environ['RAW_LABEL']
bucketName = os.environ['BUCKET_NAME']

response = s3_client.list_objects_v2(Bucket=bucketName, Prefix=label_file_prefix)
contents = response['Contents']        
latest_label_file = max(contents, key=lambda x: x['LastModified'])
latest_label_file = latest_label_file['Key']


def fetch_job_status(textract_client, job_id):
    # time.sleep(5)
    response = textract_client.get_document_text_detection(JobId=job_id)
    status = response["JobStatus"]
    return status


def lambda_handler(event, context):
    print("Event inside check_job_status_lambda:", event)
    object_name = event["Records"]["object"]
    textract_job = event["Records"]["textractJob"]
    input_bucket = event["Records"]["s3Bucket"]
    job_details = []
    job_status = ""
    total_jobs = len(textract_job)
    # completed_jobs = 0
    succeeded_jobs = 0
    failed_jobs = 0
    textract_jobs_log = os.environ['TEXTRACT_JOBS_LOG']
    json_file = s3_resource.Object(input_bucket,textract_jobs_log)
    file_content = json.loads(json_file.get()['Body'].read().decode('utf-8'))

    
    # Fetch job status of each splitted Textract jobs
    for item in event["Records"]["textractJob"]:
        item["jobStatus"] = fetch_job_status(textract_client, item["jobId"])
        temp = {
            "file_name": item['file_name'],
            "page_numbers": item['page_numbers'],
            "jobId": item["jobId"],
            "status": item["jobStatus"]
        }
        job_details.append(temp)
    
    filename = object_name.split('.')[0]
    filename = filename.split('/')[-1]
    # count number of Textract jobs SUCEEDED        
    if any(job["jobStatus"] in ["SUCCEEDED", "FAILED" ] for job in event["Records"]["textractJob"]):
      textract_job_status = [job["jobStatus"] for job in event["Records"]["textractJob"]]
      succeeded_jobs = textract_job_status.count("SUCCEEDED")
      failed_jobs = textract_job_status.count("FAILED")
      
    # Overall Job status for all Textract splitted Jobs
     #Updating JSON LOG FILE
    # json_file = s3_resource.Object(input_bucket,textract_jobs_log)
    # file_content = json.loads(json_file.get()['Body'].read().decode('utf-8'))
    # filename = object_name.split('_page_')[0]
    # filename = filename.split('/')[-1]

    if total_jobs == succeeded_jobs:
        job_status = "SUCCEEDED" 
        original_object_name = object_name.split('.')[0].split('/')[-1]
        file_content[original_object_name] = job_status
        s3_client.put_object(Body=json.dumps(file_content),Bucket=input_bucket,Key = textract_jobs_log)

    elif failed_jobs>0:
        job_status = "FAILED"
        del file_content[original_object_name]

        s3_client.put_object(Body=json.dumps(file_content),Bucket=input_bucket,Key = textract_jobs_log)

        if len(set(file_content.values())) == 1:
                print(file_content)
                if 'SUCCEEDED' in set(file_content.values()):
                    lambda_client.invoke(FunctionName=invoking_lambda,
                                        InvocationType = 'Event',
                                        Payload= json.dumps({'latest_label_file':latest_label_file})
                    )
                    
                    print("Successfully completed all textract jobs - notify")
                    
                    s3_client.delete_object(Bucket=input_bucket, Key =textract_jobs_log)
                    return {"statusCode": 200, "body": json.dumps("File uploaded successfully!")}

    else:
        job_status = "IN_PROGRESS"


    return {
        'JobStatus': job_status,
        'merge_complete': "false",
        'merged_response': [],
        'total_splits_count': len(job_details),
        'merged_splits_count': 0,
        'Records': {
            'object': object_name,
            'textractJob': job_details,
            's3Bucket': input_bucket
        }
    }