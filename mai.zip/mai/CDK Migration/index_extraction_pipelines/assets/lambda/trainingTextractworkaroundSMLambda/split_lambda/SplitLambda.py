import json
import boto3
import PyPDF2
import io
import math
import os


def read_file_from_s3(bucket, object_name):
    s3 = boto3.resource("s3")
    print(bucket)
    obj = s3.Object(bucket, object_name)
    return io.BytesIO(obj.get()["Body"].read())


def write_file_to_s3(bucket, file_name, writer):
    s3 = boto3.client("s3")
    with io.BytesIO() as bytes_stream:
        writer.write(bytes_stream)
        bytes_stream.seek(0)

        # will perform a multipart upload in multiple threads if necessary.
        s3.upload_fileobj(bytes_stream, Bucket=bucket, Key=file_name)

    head = s3.head_object(Bucket=bucket, Key=file_name)
    success = head["ContentLength"]

    return success


def delete_files_from_s3(bucket, file_names):
    s3 = boto3.resource("s3")
    for key in file_names:
        print(key)
        s3.Object(bucket, key).delete()


def save_file_splits(bucket, file_name, page_number, writer) -> bool:
    prefix = f"{file_name.split('/')[-1].split('.')[0]}"
    page_file_name = f"{os.environ['TMP_SPLIT_PREFIX']}{prefix}_page_{page_number + 1}.pdf"
    
    print(f"Splitted file saved to : s3://{bucket}/{page_file_name}")
    s3_response = write_file_to_s3(bucket, page_file_name, writer)

    return page_file_name


def split_file(bucket_name, file_name, reader, page_limit, size_limit):
    page_list = []
    writer = PyPDF2.PdfWriter()
    is_write_complete = False
    file_split_map = []
    last_page_number = 0

    # iterate over each page
    for page_number in range(len(reader.pages)):
        page_list.append(page_number + 1)
        writer.add_page(reader.pages[page_number])

        # save split files to s3 bucket
        if len(writer.pages) == page_limit:
            buffer = io.BytesIO()
            writer.write(buffer)

            # check if split exceeds size limit
            if buffer.getbuffer().nbytes > size_limit:
                print(
                    f"File split at split_size={page_limit} exceeded Textract's size limitation"
                )

                if page_limit == 1:
                    raise ValueError(
                        "Document with a single page cannot be split further!"
                    )
                return (math.ceil(page_limit / 2), {})

            tmp_file_name = save_file_splits(
                bucket_name, file_name, page_number, writer
            )
            temp = {"file_name": tmp_file_name, "page_numbers": page_list}
            file_split_map.append(temp)
            is_write_complete = True

        if is_write_complete:
            # clear the contents of the writer, to add pages from next split
            writer = PyPDF2.PdfWriter()
            page_list = []
            is_write_complete = False
        last_page_number = page_number

    # write the last remaining pages
    if len(writer.pages) > 0:
        buffer = io.BytesIO()
        writer.write(buffer)

        # check if split exceeds size limit
        if buffer.getbuffer().nbytes > size_limit:
            print(
                f"File split at split_size={page_limit} exceeded Textract's size limitation"
            )

            if page_limit == 1:
                raise ValueError("Document with a single page cannot be split further!")
            return (math.ceil(page_limit / 2), {})

        tmp_file_name = save_file_splits(
            bucket_name, file_name, last_page_number, writer
        )
        temp = {"file_name": tmp_file_name, "page_numbers": page_list}
        file_split_map.append(temp)

        is_write_complete = True

    return page_limit, file_split_map


def lambda_handler(event, context):
    print(event)
   
    bucket_name = event["bucketName"]
    object_name = event["objectName"]
    size_limit = int(os.environ['TEXTRACT_FILE_SIZE_LIMIT'])
    page_limit = int(os.environ['TEXTRACT_PAGE_LIMIT'])


    reader = PyPDF2.PdfReader(read_file_from_s3(bucket_name, object_name))
    
    if len(reader.pages) > page_limit:
        print("Page size exceeds textract hard limit. Starting workaround")
        while True:
            page_limit, file_split_map = split_file(
                bucket_name,
                object_name,
                reader,
                page_limit,
                size_limit,
            )
            if len(file_split_map) > 0:
                break

    else:
        page_limit = math.ceil(len(reader.pages) / 2)
        print("Document size exceeds textract hard limit. Starting workaround")
        while True:
            page_limit, file_split_map = split_file(
                bucket_name,
                object_name,
                reader,
                page_limit,
                size_limit,
            )
            if len(file_split_map) > 0:
                break

    return {

        "Records":
            {
                "object": object_name,
                "split": file_split_map,
                "outputBucketName": bucket_name
            }
    }
