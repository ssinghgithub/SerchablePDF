import json
import boto3
import os

from botocore.client import Config

config = Config(retries = dict(max_attempts = 5))

textract_client = boto3.client('textract',config = config)
s3_client = boto3.client('s3')

def start_textract_job(s3_bucket_name, object_name):
    response = textract_client.start_document_text_detection(
        DocumentLocation={"S3Object": {"Bucket": s3_bucket_name, "Name": object_name}}
    )

    return response["JobId"]


def lambda_handler(event, context):
    print(event["Records"]["object"])

    object_name = event["Records"]["object"]
    splits = event["Records"]["split"]
    input_bucket = event["Records"]["outputBucketName"]
    job_list = []
    textract_jobs_log = os.environ['TEXTRACT_JOBS_LOG']


    for item in splits:
        # print("input_bucket:",input_bucket)
        # print("object_name: ",  item['file_name'])
        jobId = start_textract_job(input_bucket, item['file_name'])
        # json_file = s3_resource.Object(input_bucket,textract_jobs_log)
        # file_content = json.loads(json_file.get()['Body'].read().decode('utf-8'))
        # filename = item['file_name'].split('_page_')[0]
        # filename = filename.split('/')[-1]
        
        # job_log_value = file_content[filename]

        # job_log_value.append(jobId)
        
        # fetch Job status
        response = textract_client.get_document_text_detection(JobId=jobId)
        status = response["JobStatus"]
        
        temp = {
            "file_name": item['file_name'],
            "page_numbers": item['page_numbers'],
            "jobId": jobId,
            "jobStatus": status
        }
        job_list.append(temp)

    # s3_client.put_object(Body=json.dumps(file_content),Bucket=input_bucket,Key = textract_jobs_log)
    return {
        'JobStatus':"IN_PROGRESS",
        'Records': {
            'object': object_name,
            'textractJob': job_list,
            's3Bucket': input_bucket
        }
    }