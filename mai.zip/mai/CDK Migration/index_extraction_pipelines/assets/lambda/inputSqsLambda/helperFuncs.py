
import json
import boto3
import os
import PyPDF2
import io
from botocore.client import Config

config = Config(retries = dict(max_attempts = 5))

textract_client = boto3.client('textract',config = config)
s3_resource = boto3.resource("s3")
sqs_client = boto3.client('sqs')

TEXTRACT_FILE_SIZE_LIMIT = os.environ['TEXTRACT_FILE_SIZE_LIMIT'] #524288000
TEXTRACT_PAGE_SIZE_LIMIT = os.environ['TEXTRACT_PAGE_LIMIT'] #3000

def is_file_size_over_limit(bucket, object):
    textract_size_limit = TEXTRACT_FILE_SIZE_LIMIT
    s3_obj = s3_resource.Object(bucket, object)
    file = io.BytesIO(s3_obj.get()["Body"].read())

    if file.getbuffer().nbytes > int(textract_size_limit):
        return True
    return False


def is_page_size_over_limit(bucketName, objectName):
    textract_page_limit = TEXTRACT_PAGE_SIZE_LIMIT
    s3_obj = s3_resource.Object(bucketName, objectName)
    file = io.BytesIO(s3_obj.get()["Body"].read())

    # S3 trigger payload has size, can skip Pypdf2 read
    reader = PyPDF2.PdfReader(file)

    if len(reader.pages) > int(textract_page_limit):
        return True
    return False


def write_message_to_queue(bucket, object, limit_type,limit_queue_url):
    
    response = sqs_client.send_message(
        QueueUrl=limit_queue_url,
        DelaySeconds=10,
        MessageAttributes={
            'bucket': {
                'DataType': 'String',
                'StringValue': bucket
            },
            'object': {
                'DataType': 'String',
                'StringValue': object
            }
        },
        MessageBody=(
            limit_type
        )
    )
    return response


def check_limits(bucketName, objectName):
    limit_type = ""
    limit_exceed_flag = False

    is_size_over = is_file_size_over_limit(bucketName, objectName)
    is_page_size_over = is_page_size_over_limit(bucketName, objectName)

    if is_size_over and is_page_size_over:
        limit_type = "File size and number of pages exceed Textract Hard limit"
        limit_exceed_flag = True

    elif is_size_over:
        limit_type = "File size more than Textract limits"
        limit_exceed_flag = True

    elif is_page_size_over:
        limit_type = "File has more pages than allowed by Textract"
        limit_exceed_flag = True

    else:
        limit_type = "File size and total number of pages is within textract hard limits"

    return limit_exceed_flag, limit_type

def get_messages_from_queue(queue_url):
    """Generates messages from an SQS queue.

    Note: this continues to generate messages until the queue is empty.
    Every message on the queue will be deleted.

    :param queue_url: URL of the SQS queue to read.

    """
    
    # while True:
    resp = sqs_client.receive_message(
        QueueUrl=queue_url, AttributeNames=["All"], MaxNumberOfMessages=1
    )
    
    # print(f"Number of messages received: {len(resp)}")
    
    try:
        yield from resp["Messages"]
    except KeyError:
        return

    entries = [
        {"Id": msg["MessageId"], "ReceiptHandle": msg["ReceiptHandle"]}
        for msg in resp["Messages"]
    ]

    resp = sqs_client.delete_message_batch(QueueUrl=queue_url, Entries=entries)

    if len(resp["Successful"]) != len(entries):
        raise RuntimeError(
            f"Failed to delete messages: entries={entries!r} resp={resp!r}"
        )

def startJob(bucketName, objectName, snsTopic, snsRole, jobstore, outputBucket, KMSKey):

    print("Starting job with  bucketName: {}, objectName: {}".format( bucketName, objectName))

    response = textract_client.start_document_text_detection(
            # ClientRequestToken  = documentId,
            DocumentLocation={
                'S3Object': {
                    'Bucket': bucketName,
                    'Name': objectName
                } 
            },
            NotificationChannel= {
              "RoleArn": snsRole,
              "SNSTopicArn": snsTopic
          },
          OutputConfig ={
            "S3Bucket": outputBucket,
            "S3Prefix": jobstore
          },
          KMSKeyId= KMSKey
          )
               
    print("Response:", response)
    
    return response["JobId"]
    

