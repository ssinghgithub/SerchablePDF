import json
import boto3
import os
import PyPDF2
import io
import logging

from helperFuncs import *


# logger config
# logger = logging.getLogger()
# logging.basicConfig(level=logging.INFO, 
#             format ='%(asctime)s: %(levelname)s %(message)s')


def lambda_handler(event, context):
    print("event:", event)
    
    # set limit exceed flag to False
    limit_exceed_flag = False
    
    # Read environment variables
    input_queue_url = os.environ['ASYNC_QUEUE_URL']
    limit_queue_url = os.environ['LIMIT_QUEUE_URL']
    snsTopic = os.environ['SNS_TOPIC_ARN']
    snsRole = os.environ['SNS_ROLE_ARN']
    KMSKey = os.environ['KMS_KEY']
    jobstore = os.environ['TEXTRACT_OUTPUT_LOC']
    outputBucket = os.environ['OUTPUT_BUCKET']
    inferenceBatchSize =int(os.environ['INFERENCE_BATCH_SIZE'])
    
    # Define variables
    message_bodies = []
    textract_jobs = []
    textract_limit_exceed = []
    message_received = 0

    # Read message from queue
    while message_received < inferenceBatchSize:
        for message in get_messages_from_queue(queue_url=input_queue_url):
            # process message body
            body = json.loads(message['Body'])
            message_bodies.append(body)
        message_received+=1
        
    print(f"Number of messages received: {len(message_bodies)}")
    
   # Process Messages 
    for count, messageBody in enumerate(message_bodies):
        if 'Records' in messageBody:
            bucketName = messageBody['Records'][0]['s3']['bucket']['name']
            objectName = messageBody['Records'][0]['s3']['object']['key']
            # print('bucketName: ', bucketName)
            # print('objectName: ', objectName)
            
            # Check for Textract limits exceed
            limit_exceed_flag, limit_type = check_limits(bucketName, objectName)

            if limit_exceed_flag:
                print(limit_type)
                response = write_message_to_queue(bucketName, objectName, limit_type, limit_queue_url)
                print(response)
                textract_limit_exceed.append(f's3://{bucketName}/{objectName}')
                
            else:

                try:
                    job_id = startJob(bucketName, objectName, snsTopic, snsRole, jobstore, outputBucket, KMSKey)
                    textract_jobs.append(job_id)
                
                except Exception as e:
                    print("Unable to kickoff Textract Job.")
                    print(e)
        
    print(f'{len(textract_jobs)} Textract job(s) started!!') 
    print(f'{len(textract_limit_exceed)} files routed for Textract workaround!!') 
