#!/usr/bin/env python3
import sys

# caution: path[0] is reserved for script path (or '' in REPL)
sys.path.insert(1, '../src/')

from inspect import stack
import aws_cdk as cdk

from aws_cdk import Aspects
from cdk_nag import HIPAASecurityChecks

from stacks.simplified_inference import *
from stacks.simplified_train import *
from stacks.inference_workaround import *
from stacks.training_workaround import *
# from src.pipeline.train_pipeline_stack import TrainingPipelineStack
from config import  EnvSettings, Name, PipelineResource

app = cdk.App()
if PipelineResource.INFERENCE_FLAG:
    InferencePipelineWorkAroundStack(app, PipelineResource.CUSTOMER_NAME +'-workaround-' + Name.INFERENCE_PIPELINE_STACK,
                        env=cdk.Environment(account=EnvSettings.ACCOUNT_ID, region=EnvSettings.ACCOUNT_REGION),
                        description='The Infrastructure workaround for Inference Pipeline'
                        )
if PipelineResource.TRAINING_FLAG: 
    TrainingPipelineWorkAroundStack(app, PipelineResource.CUSTOMER_NAME + '-workaround-' + Name.TRAINING_PIPELINE_STACK,
                        env=cdk.Environment(account=EnvSettings.ACCOUNT_ID, region=EnvSettings.ACCOUNT_REGION),
                        description='The Infrastructure workaround for Training Pipeline'
                        )

## Add CDK-Nag Checks
Aspects.of(app).add(HIPAASecurityChecks(log_ignores=True, verbose=False))

app.synth()
