from aws_cdk import (
    Stack,
    aws_s3 as s3,
    aws_sqs as queue,
    aws_s3_notifications,
    aws_kms,
    aws_cloudformation as cfn
)
import aws_cdk as cdk
from constructs import Construct
from config import IDs, EnvSettings, Name, ARNs, ResourceNames


class InputBucket(cdk.Stack):

    def __init__(self, scope, name):
        # super().__init__(scope, id)

        s3.Bucket(self, bucket_name=name,
                           removal_policy=cdk.RemovalPolicy.DESTROY
                           )

