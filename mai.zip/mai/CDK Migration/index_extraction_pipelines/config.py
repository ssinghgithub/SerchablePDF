'''
Copyright (c) 2023 Amazon.com, Inc. or its affiliates. All Rights Reserved.

This source code is subject to the terms found in the AWS Enterprise Customer Agreement.
'''

'''
NOTE: If deploying to production, set IS_PROD to True.
 - If this is set to True, all properties from the 'ProdAccountProps' class will be used
 - If this is set to False, all the properties from the 'DevAccountProps' class will be used
'''
IS_PROD = False

class PipelineResource:
    '''
     Configuration parameters used for setting up the training/Inference pipeline
    '''
    BUCKET_NAME = 'nlp-dev1'
    CLASSIFICATION_MODEL = 'arn:aws:comprehend:us-east-1:500927421718:document-classifier/batch3-downsample-additional-update-active-keywords/version/1'
    CUSTOMER_NAME = 'dev-humana'
    KMS_KEY = '1987b1c6-ad66-4027-9dce-6d85fa4255c6'
    KMS_KEY_ARN = 'arn:aws:kms:us-east-1:500927421718:key/1987b1c6-ad66-4027-9dce-6d85fa4255c6'
    #-----------------Inference Variables-----------------
    INFERENCE_FLAG = True    
    COMPREHEND_DATA_ACCESS_ROLE_ARN = 'arn:aws:iam::500927421718:role/AmazonComprehendServiceROLE-aws_NLP_DEV_S3Datastore_servicewrite'
    COMPREHEND_INFERENCE_NOTIFICATION_EMAIL = "manojkrishna.mohan@exlservice.com"    
    TEXTRACT_PAGE_LIMIT = 3000
    TEXTRACT_FILE_SIZE_LIMIT= 524288000 # 100288000
    INFERENCE_BATCH_SIZE = 50
    #-----------------Training Variables-----------------
    TRAINING_FLAG = False
    TEXTRACT_JOBS_JSON = CUSTOMER_NAME + '-textract-job-log.json'
    TRAINING_DATA_INPUT_LOC = "cdkdeployment-ss/training/inputPDF"
    TRAINING_RAW_LABEL = "cdkdeployment-ss/training/raw_label/"
    KEYWORD_USAGE_FLAG = "TRUE"
    TRAINING_KEYWORDS = "cdkdeployment-ss/training/keywords/keywords_to_training.csv"
    COMPREHEND_TRAINING_NOTIFICATION_EMAIL = "manojkrishna.mohan@exlservice.com"

class DevAccountProps:
    # General params
    ACCOUNT_ID = "500927421718"  # "ACCOUNT_ID"
    ACCOUNT_REGION = "us-east-1"
    

class ProdAccountProps:
    # General params
    ACCOUNT_ID = "500927421718"  # "ACCOUNT_ID"
    ACCOUNT_REGION = "us-east-1"


class EnvSettings:
    '''
        Environment settings
    '''
    # General params
    ACCOUNT_ID = ProdAccountProps.ACCOUNT_ID if IS_PROD else DevAccountProps.ACCOUNT_ID
    ACCOUNT_REGION = ProdAccountProps.ACCOUNT_REGION if IS_PROD else DevAccountProps.ACCOUNT_REGION


class Name:
    '''
        Naming conventions for Training/Inference pipeline
    '''
    PREFIX = "index-extraction"

    TRAINING_PIPELINE_PREFIX = f'{PREFIX}-training-pipeline-cdk'
    INFERENCE_PIPELINE_PREFIX = f'{PREFIX}-inference-pipeline-cdk'

    TRAINING_PIPELINE_STACK = f'{TRAINING_PIPELINE_PREFIX}-stack-ss'
    INFERENCE_PIPELINE_STACK = f'{INFERENCE_PIPELINE_PREFIX}-stack-ss'


