import aws_cdk as cdk
import aws_cdk.aws_s3 as _s3
import aws_cdk.aws_sqs as _sqs
import aws_cdk.aws_iam as _iam
import aws_cdk.aws_lambda as _lambda
import aws_cdk.aws_s3_notifications as _s3n
import aws_cdk.aws_sns as _sns
import aws_cdk.aws_sns_subscriptions as _snssubscr
import aws_cdk.aws_stepfunctions as _sfn
import aws_cdk.aws_stepfunctions_tasks as _tasks
import aws_cdk.aws_sns_subscriptions as subscriptions


from aws_cdk import Duration
import aws_cdk.aws_events as _events
import aws_cdk.aws_events_targets as _targets
from aws_cdk.aws_lambda_event_sources import (S3EventSource, SqsEventSource, SnsEventSource, DynamoEventSource)
from aws_cdk import aws_events, aws_events_targets
from aws_cdk.aws_kms import Key

from cdk_nag import NagSuppressions

from config import PipelineResource



class InferencePipelineWorkAroundStack(cdk.Stack):

    def __init__(self, scope, construct_id, **kwargs):
        super().__init__(scope, construct_id, **kwargs)

        #----------------------Resource Names--------------------------
        customer_bucket_name=PipelineResource.BUCKET_NAME
        document_classification_model=PipelineResource.CLASSIFICATION_MODEL
        customer_name=PipelineResource.CUSTOMER_NAME
        kms_key_id=PipelineResource.KMS_KEY
        kms_key_arn=PipelineResource.KMS_KEY_ARN
        comprehend_data_access_role=PipelineResource.COMPREHEND_DATA_ACCESS_ROLE_ARN
        training_mode=PipelineResource.TRAINING_FLAG
        textract_page_limit=str(PipelineResource.TEXTRACT_PAGE_LIMIT)
        textract_file_size_limit=str(PipelineResource.TEXTRACT_FILE_SIZE_LIMIT)
        inference_batch_size=str(PipelineResource.INFERENCE_BATCH_SIZE)
        comprehend_inference_notification_email = PipelineResource.COMPREHEND_INFERENCE_NOTIFICATION_EMAIL

        #-----------------------CDK-Nag Stack Suppressions-------------------
        NagSuppressions.add_stack_suppressions(self, 
            [
                {"id":"HIPAA.Security-LambdaConcurrency", "reason": "Expected high levels of concurrency"},
                {"id":"HIPAA.Security-IAMNoInlinePolicy", "reason": "IAM policies are unique to their respective service role"},
                {"id":"HIPAA.Security-LambdaDLQ", "reason": "Enabling DLQ for all lambda functions outside of scope"},
                {"id":"HIPAA.Security-LambdaInsideVPC", "reason": "Expected high levels of concurrency may lead to IP address exhaustion"}
            ]
        )

        # The code that defines your stack goes here

        #------------------ KMS Key that is already defined -----------------------

        defined_kms_key = Key.from_key_arn(self, id=kms_key_id, key_arn=kms_key_arn)

        '''******************************SNS Topics****************************** '''
        jobCompletionTopic=_sns.Topic(self, 'jobCompletion', master_key=defined_kms_key)

        '''******************************IAM Roles****************************** '''

        textractServiceRole=_iam.Role(self, customer_name + '_TextractServiceRole', assumed_by=_iam.ServicePrincipal('textract'
                                                                                                      '.amazonaws.com'))
        textractServiceRole.add_to_policy(_iam.PolicyStatement(effect=_iam.Effect.ALLOW,
                                                               actions=["sns:Publish"],
                                                               resources=[jobCompletionTopic.topic_arn]))
        
        defined_kms_key.grant_encrypt_decrypt(textractServiceRole)

        '''******************************S3 Bucket****************************** '''
        # Create raw and textract output S3 buckets
        # input bucket
        # raw_bucket=_s3.Bucket(self, 'raw_bucket',
        #                         bucket_name=EnvSettings.INPUT_BUCKET_NAME,
        #                         auto_delete_objects=True,
        #                         removal_policy=cdk.RemovalPolicy.DESTROY,
        #                         lifecycle_rules=[_s3.LifecycleRule(
        #                             transitions=[_s3.Transition(
        #                                 storage_class=_s3.StorageClass.GLACIER,
        #                                 transition_after=cdk.Duration.days(7))]
        #                         )])

        raw_bucket=_s3.Bucket.from_bucket_name(self,"Bucket",customer_bucket_name)


        '''******************************SQS****************************** '''
        # DLQ
        dlq=_sqs.Queue(self, customer_name + '_DLQ', visibility_timeout=cdk.Duration.seconds(90),
                         retention_period=cdk.Duration.seconds(1209600))

        # Queue for async jobs
        inputDocQueue=_sqs.Queue(self, customer_name + '_InputDocs',
                                   queue_name= customer_name + '_raw_input_pdf_queue',
                                   visibility_timeout=cdk.Duration.seconds(900),
                                   retention_period=cdk.Duration.seconds(1209600),
                                   dead_letter_queue=_sqs.DeadLetterQueue(max_receive_count=50, queue=dlq)
                                   )
        
        # Add notification events to the input bucket
        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.SqsDestination(inputDocQueue),
                                          _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/inputFolder/", suffix=".pdf", )
                                          )



        # Queue for async Textract jobs results
        jobResultsQueue=_sqs.Queue(self, customer_name + '_JobResults',
                                     queue_name= customer_name + '_textractjob_results_queue',
                                     visibility_timeout=cdk.Duration.seconds(1200),
                                     retention_period=cdk.Duration.seconds(1209600),
                                     dead_letter_queue=_sqs.DeadLetterQueue(max_receive_count=50, queue=dlq)
                                     )
        # Trigger between SNS -> SQS once Textract job is completed
        jobCompletionTopic.add_subscription(_snssubscr.SqsSubscription(jobResultsQueue))

        # Textract Limit SQS
        textractLimitQueue=_sqs.Queue(self, customer_name + '_TextractLimit',
                                   queue_name=customer_name + '_textract_limit_queue',
                                   visibility_timeout=cdk.Duration.seconds(90),
                                   retention_period=cdk.Duration.seconds(1209600),
                                   dead_letter_queue=_sqs.DeadLetterQueue(max_receive_count=50, queue=dlq)
                                   )


        # pypdf2 layer
        pypdf2Layer=_lambda.LayerVersion(self,'PyPDF2Layer',
                                           code=_lambda.Code.from_asset('assets/lambda/PyPDF2.zip'),
                                           compatible_runtimes=[_lambda.Runtime.PYTHON_3_7],
                                           license='Apache-2.0',
                                           description='PyPDF2 layer')
        
        
        #-------------------------------------------Use Pandas Layer provided by AWS----------------------------
        pandasLayer=_lambda.LayerVersion.from_layer_version_arn(self,"PandasLayer",layer_version_arn="arn:aws:lambda:us-east-1:336392948345:layer:AWSSDKPandas-Python37:5")

     
        #-------------------------State Machine for Large PDF --------------------------------------

        # Lambda Handlers Definitions

        SplitLambda=_lambda.Function(self, customer_name + '_SplitLambda',
                                       function_name=customer_name + '_split_file_lambda',
                                       description="Function to split the files in smaller chunks",
                                       runtime=_lambda.Runtime.PYTHON_3_7,
                                       handler='SplitLambda.lambda_handler',
                                       layers=[pypdf2Layer],
                                       code=_lambda.Code.from_asset('assets/lambda/textractworkaroundSMLambda/split_lambda/'),
                                       timeout=cdk.Duration.seconds(900),
                                       memory_size=10240,
                                       ephemeral_storage_size=cdk.Size.gibibytes(10),
                                       retry_attempts=0,
                                       environment={
                                            "TMP_SPLIT_PREFIX": 'cdkdeployment-ss/workaround/tmp_split/',
                                            "TEXTRACT_PAGE_LIMIT": textract_page_limit,
                                            "TEXTRACT_FILE_SIZE_LIMIT": textract_file_size_limit
                                       }
                                       )
        raw_bucket.grant_read_write(SplitLambda)

        #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(SplitLambda)

        StartTextractJobLambda=_lambda.Function(self, customer_name + '_StartTextractJobLambda',
                                                  function_name=customer_name + '_start_textract_job_lambda',
                                                  description="Function to kick-off textract Job for smaller chunks",
                                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                                  handler='StartTextractJobLambda.lambda_handler',
                                                  code=_lambda.Code.from_asset('assets/lambda/textractworkaroundSMLambda/start_job/'),
                                                  timeout=cdk.Duration.seconds(300),
                                                  memory_size=10240,
                                                  ephemeral_storage_size=cdk.Size.gibibytes(10),
                                                  retry_attempts=0
                                                  )
        raw_bucket.grant_read_write(StartTextractJobLambda)

        StartTextractJobLambda.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                       resources=[textractServiceRole.role_arn]))
        StartTextractJobLambda.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                                "textract:GetDocumentTextDetection"],
                                                                       resources=["*"]))
        
        #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(StartTextractJobLambda)
        
        CheckJobStatusLambda=_lambda.Function(self, customer_name + '_CheckJobStatusLambda',
                                                function_name=customer_name + '_check_job_status_lambda',
                                                description="Function to check the Textract job status",
                                                runtime=_lambda.Runtime.PYTHON_3_7,
                                                handler='CheckJobStatusLambda.lambda_handler',
                                                code=_lambda.Code.from_asset('assets/lambda/textractworkaroundSMLambda/check_status/'),
                                                timeout=cdk.Duration.seconds(900),
                                                memory_size=10240,
                                                ephemeral_storage_size=cdk.Size.gibibytes(10),
                                                retry_attempts=0
                                                )
        CheckJobStatusLambda.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                     resources=[textractServiceRole.role_arn]))
        CheckJobStatusLambda.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                                "textract:GetDocumentTextDetection"],
                                                                     resources=["*"]))


        MergeLambda=_lambda.Function(self, customer_name + '_MergeLambda',
                                       function_name=customer_name + '_merge_lambda',
                                       description="Function to Merge the textract results",
                                       runtime=_lambda.Runtime.PYTHON_3_7,
                                       handler='MergeLambda.lambda_handler',
                                       code=_lambda.Code.from_asset('assets/lambda/textractworkaroundSMLambda/merge_lambda/'),
                                       timeout=cdk.Duration.seconds(900),
                                       memory_size=10240,
                                       ephemeral_storage_size=cdk.Size.gibibytes(10),
                                       retry_attempts=0,
                                       layers=[pandasLayer],
                                       environment={'MERGED_LOC': 'cdkdeployment-ss/workaround/merged/',
                                                    'MERGED_RES_LOC': 'cdkdeployment-ss/comprehendInputFolder/'
                                                    }
                                       )

        raw_bucket.grant_read_write(MergeLambda)
        MergeLambda.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                            resources=[textractServiceRole.role_arn]))
        MergeLambda.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                        "textract:GetDocumentTextDetection"],
                                                            resources=["*"]))
        # MergeLambda.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*"],
        #                                                        resources=["*"]))
        
        #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(MergeLambda)



        # Step functions Definition

        split_job=_tasks.LambdaInvoke(
            self, "Split Job",
            lambda_function=SplitLambda,
            output_path="$.Payload",
        )
        start_textract_job=_tasks.LambdaInvoke(
            self, "Start Textract Job",
            lambda_function=StartTextractJobLambda,
            output_path="$.Payload",
        )

        wait_job=_sfn.Wait(
            self, "Wait 1 Minute",
            time=_sfn.WaitTime.duration(
                cdk.Duration.seconds(60))
        )

        status_job=_tasks.LambdaInvoke(
            self, "Get Textract Job Status",
            lambda_function=CheckJobStatusLambda,
            output_path="$.Payload",
        )

        fail_job=_sfn.Fail(
            self, "Fail",
            cause='AWS Batch Job Failed',
            error='DescribeJob returned FAILED'
        )

        # succeed_job=_sfn.Succeed(
        #     self, "Succeeded",
        #     comment='AWS Batch Job succeeded'
        # )

        merge_textract_output=_tasks.LambdaInvoke(
            self, "Merge Textract Json Output",
            lambda_function=MergeLambda,
            output_path="$.Payload",
        )


        # Create Chain

        definition=split_job.next(start_textract_job) \
            .next(wait_job) \
            .next(status_job) \
            .next(_sfn.Choice(self, 'All Job Complete?')
                  .when(_sfn.Condition.string_equals('$.JobStatus', 'FAILED'), fail_job)
                  .when(_sfn.Condition.string_equals('$.JobStatus', 'SUCCEEDED'), merge_textract_output.  
                        next(_sfn.Choice(self, 'Merge Complete?')
                             .when(_sfn.Condition.string_equals('$.merge_complete', 'true'), _sfn.Pass(self,"Pass"))
                             .otherwise(merge_textract_output)
                             )
                             )
                  .otherwise(wait_job))

        # Create state machine
        workaround_step_func=_sfn.StateMachine(
            self, customer_name + "_StateMachine",
            definition=definition,
        )
        
        #---------------------------------------------------------------------------------------------
        
        # Process Input Lambda - Process input queue
        inputEventProcessor=_lambda.Function(self, customer_name + '_workaroundinputEventProcessor',
                                              function_name=customer_name +'_input_sqs_msg_processor',
                                              description='Function to process messages from input queue',
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='inputSqsLambda.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/inputSqsLambda'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                              ephemeral_storage_size= cdk.Size.gibibytes(10),
                                              layers=[pypdf2Layer],
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              environment={
                                                            "ASYNC_QUEUE_URL": inputDocQueue.queue_url,
                                                            "KMS_KEY" : kms_key_id,
                                                            "TEXTRACT_OUTPUT_LOC" : "cdkdeployment-ss/textractOutputFolder",
                                                            "SNS_TOPIC_ARN": jobCompletionTopic.topic_arn,
                                                            "SNS_ROLE_ARN": textractServiceRole.role_arn,
                                                            "LIMIT_QUEUE_URL": textractLimitQueue.queue_url,                                                            
                                                            "OUTPUT_BUCKET" : raw_bucket.bucket_name,
                                                            "TEXTRACT_PAGE_LIMIT": textract_page_limit,
                                                            "TEXTRACT_FILE_SIZE_LIMIT": textract_file_size_limit,
                                                            "INFERENCE_BATCH_SIZE": inference_batch_size
                                                            }
                                              )

        #------------------------------------------------------------5mins EVENT BRIDGE RULE------------------------------------------------------------

        # rule=_events.Rule(
        #     self,
        #     "Trigger Lambda to check every 5 minutes",
        #     schedule=_events.Schedule.rate(Duration.minutes(5))
        # ) 

        # rule.add_target(_targets.LambdaFunction(inputEventProcessor))

        # Permissions
        raw_bucket.grant_read_write(inputEventProcessor)
        inputDocQueue.grant_consume_messages(inputEventProcessor)
        inputEventProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                               resources=[textractServiceRole.role_arn]))
        inputEventProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                                "textract:GetDocumentTextDetection"],
                                                               resources=["*"]))
        # inputEventProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*"],
        #                                                        resources=["*"]))
        defined_kms_key.grant_encrypt_decrypt(inputEventProcessor)
        # inputEventProcessor.add_event_source(SqsEventSource(queue=inputDocQueue))

        textractLimitQueue.grant_send_messages(inputEventProcessor)


        #----------------------Over Limit Textract processor------------------------------------
        StartLimitProcSMLambda=_lambda.Function(self, customer_name + '_StartLimitProcSMLambda',
                                              function_name=customer_name + '_start_limit_processor',
                                              description='Function to process messages from HL queue',
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='StartHLProcSMLambda.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/textractworkaroundSMLambda/StartLimitProcSMLambda/'),
                                              timeout=cdk.Duration.seconds(60),
                                              retry_attempts=0,
                                              layers=[pandasLayer],
                                              reserved_concurrent_executions=5,
                                              environment={
                                                  'LIMIT_QUEUE_URL': textractLimitQueue.queue_url,
                                                  "STATE_MACHINE_ARN": workaround_step_func.state_machine_arn
                                              }
                                              )

        # Permissions
        raw_bucket.grant_read_write(StartLimitProcSMLambda)
        textractLimitQueue.grant_consume_messages(StartLimitProcSMLambda)
        StartLimitProcSMLambda.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                   resources=[textractServiceRole.role_arn]))
        StartLimitProcSMLambda.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                                "textract:GetDocumentTextDetection"],
                                                                   resources=["*"]))
        StartLimitProcSMLambda.add_event_source(SqsEventSource(queue=textractLimitQueue))
        workaround_step_func.grant_start_execution(StartLimitProcSMLambda)
        defined_kms_key.grant_encrypt_decrypt(StartLimitProcSMLambda)



        #-------------------------------------------Lambda function to process Textract output result----------------------------
        jobResultProcessor=_lambda.Function(self, customer_name + '_JobResultProcessor',
                                              function_name=customer_name+'_textract_job_result_processor',
                                              description="Function to run process Textract Output",
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='ResultProcLambda.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/ResultProcLambda'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                            #   ephemeral_storage_size=10240,
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              layers=[pandasLayer],
                                              environment={'bucketName': raw_bucket.bucket_name,
                                                           'PREFIX': 'cdkdeployment-ss/comprehendInputFolder',
                                                           'qUrl': jobResultsQueue.queue_url
                                                           }
                                              )

        # Permission
        raw_bucket.grant_read_write(jobResultProcessor)


        jobResultsQueue.grant_consume_messages(jobResultProcessor)
        jobResultProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                   resources=[textractServiceRole.role_arn]))
        jobResultProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                                "textract:GetDocumentTextDetection"],
                                                                   resources=["*"]))

        # jobResultProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*"],
        #                                                        resources=["*"]))

        #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(jobResultProcessor)

        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED,
                                                 _s3n.LambdaDestination(jobResultProcessor),
                                                 _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/workaround/merged/", suffix=".json"))




        '''Note: batchSize: Determines how many records are buffered before invoking your lambda function.
        if using batchwindow- then apply recommended visibility timeout
        https://docs.aws.amazon.com/lambda/latest/dg/with-sqs.html#events-sqs-queueconfig'''

        jobResultProcessor.add_event_source(SqsEventSource(queue=jobResultsQueue))


        #------------------------------------------------------Comprehend Step Functions for Inference workflow----------------------------------------------

        # comprehend_dataaccess_role=_iam.Role(self,"ComprehendDataRole",
        #     assumed_by=_iam.ServicePrincipal("comprehend.amazonaws.com"),
        #     description="Comprehend Data Access Role"
        # )
        # dataaccesspolicy=_iam.ManagedPolicy.from_aws_managed_policy_name('service-role/ComprehendDataAccessRolePolicy')
        # s3_access_policy=_iam.ManagedPolicy.from_aws_managed_policy_name('AmazonS3FullAccess')

        # comprehend_dataaccess_role.add_managed_policy(dataaccesspolicy)
        # comprehend_dataaccess_role.add_managed_policy(s3_access_policy)

        start_comp_inference=_lambda.Function(self, customer_name+"_CompStartInferenceLambda",
                                  function_name=customer_name+"_start_comprehend_inference_lambda",
                                  code=_lambda.Code.from_asset('assets/lambda/CompStartInferenceLambda'),
                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                  handler="CompStartInferenceLambda.lambda_handler",
                                  timeout=Duration.seconds(25),
                                  environment={
                                    'KMS_KEY' : kms_key_arn,
                                    'INFERENCE_RESULTS' : 's3://{}/cdkdeployment-ss/comprehendOutputFolder'.format(customer_bucket_name),
                                    'DOC_CLASS_ARN' : document_classification_model,
                                    'DATA_ACCESS_ROLE_ARN' : comprehend_data_access_role,
                                    'REGION' : 'us-east-1 '
                                  })
        start_comp_inference.add_to_role_policy(_iam.PolicyStatement(actions=["comprehend:StartDocumentClassificationJob",
                                                                              "comprehend:DescribeDocumentClassificationJob"],resources=["*"]))

        #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(start_comp_inference)

        raw_bucket.grant_read_write(start_comp_inference)
        
        start_comp_inference.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                               resources=[comprehend_data_access_role]))
                                                               
        get_inference_status=_lambda.Function(self, customer_name+"_CompGetInferStatusLambda",
                                  function_name=customer_name+"_get_comprehend_inference_lambda",
                                  code=_lambda.Code.from_asset('assets/lambda/CompGetInferStatusLambda'),
                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                  handler="CompGetInferStatusLambda.lambda_handler",
                                  timeout=Duration.seconds(25))
        get_inference_status.add_to_role_policy(_iam.PolicyStatement(actions=["comprehend:StartDocumentClassificationJob",
                                                                              "comprehend:DescribeDocumentClassificationJob"],resources=["*"]))

        #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(get_inference_status)

        raw_bucket.grant_read_write(get_inference_status)
        
        get_inference_status.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                               resources=[comprehend_data_access_role]))

        

        submit_comp_job=_tasks.LambdaInvoke(self, "Submit Comprehend Job",
            lambda_function=start_comp_inference,
            # Lambda's result is in the attribute `Payload`
            result_path="$.Payload"
        )

        wait_x=_sfn.Wait(self, "Wait 5 Minutes Comprehend",
            time=_sfn.WaitTime.duration(Duration.seconds(300))
        )

        get_comp_job_status=_tasks.LambdaInvoke(self, "Get Job Status",
            lambda_function=get_inference_status,
            # Pass just the field named "guid" into the Lambda, put the
            # Lambda's result in a field called "status" in the response
            input_path="$.Payload",
            result_path="$.status"
        )
        
        inf_success_topic=_sns.Topic(self,customer_name+"-comprehend-inference-success-notification")
        inf_success_topic.add_subscription(subscriptions.EmailSubscription(comprehend_inference_notification_email))

        # CDK-Nag Resource Specific Suppression
        NagSuppressions.add_resource_suppressions(inf_success_topic, [
            {"id": "HIPAA.Security-SNSEncryptedKMS", "reason": "Static completion message containing no user data"}
        ])

        inf_success_notification=_tasks.SnsPublish(self, "Publish Inference Success Notification",
                                                 topic=inf_success_topic,
                                                 message=_sfn.TaskInput.from_text("The Inference job has been completed"))


        inf_failed_topic=_sns.Topic(self,customer_name+"-comprehend-inference-failed-notification")
        inf_failed_topic.add_subscription(subscriptions.EmailSubscription(comprehend_inference_notification_email))

        # CDK-Nag Resource Specific Suppression
        NagSuppressions.add_resource_suppressions(inf_failed_topic, [
            {"id": "HIPAA.Security-SNSEncryptedKMS", "reason": "Static completion message containing no user data"}
        ])

        inf_failure_notification=_tasks.SnsPublish(self, "Publish Inference Failure Notification",
                                                 topic=inf_failed_topic,
                                                 message=_sfn.TaskInput.from_text("The Inference Job has failed"))


        job_failed=_sfn.Fail(self, "Job Failed",
            cause="Comprehend Job Failed",
            error="DescribeJob returned FAILED"
        )


        job_success=_sfn.Succeed(self,"Comprehend Classification Successful")

        # definition=submit_comp_job.next(wait_x).next(get_comp_job_status).next(_sfn.Choice(self, "Job Complete?")\
        #                                                            .when(_sfn.Condition.string_equals("$.status.Payload.Status", "FAILED"), job_failed)\
        #                                                             .when(_sfn.Condition.string_equals("$.status.Payload.Status", "COMPLETED"), job_success).otherwise(wait_x))
        
        definition=submit_comp_job.next(wait_x).next(get_comp_job_status).next(_sfn.Choice(self, "Job Complete?")\
                                                                   .when(_sfn.Condition.string_equals("$.status.Payload.JobStatus", "FAILED"), inf_failure_notification.next(job_failed))\
                                                                    .when(_sfn.Condition.string_equals("$.status.Payload.JobStatus", "TRAINED"), inf_success_notification.next(job_success)).otherwise(wait_x))                                                                    
        
        comprehend_state_machine=_sfn.StateMachine(self, customer_name + "_ComprehendClassificationStepFunc",
            definition=definition,
        )
        
        #------------------------------------------------------------TRIGGER LAMBDA FOR THE ABOVE STEPFUNCTION------------------------------------------------------------

        comprehend_step_trigger=_lambda.Function(self, customer_name + "_TriggerComprehendStepFunc",
                                  function_name=customer_name + '_trigger_comprehend_step_function',
                                  code=_lambda.Code.from_asset('assets/lambda/comprehendTriggerLambda/'),
                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                  handler="comprehendTriggerLambda.lambda_handler",
                                  timeout=Duration.seconds(300),
                                  environment={
                                    "STATE_MACHINE_ARN" : comprehend_state_machine.state_machine_arn
                                  })

        comprehend_step_trigger.add_to_role_policy(_iam.PolicyStatement(actions=["states:StartExecution"],
                                                                   resources=[comprehend_state_machine.state_machine_arn]))


        #-------------Merge all CSVs to one large CSV for comprehend inference-----------------------
        # DLQ
        merge_dlq=_sqs.Queue(self, customer_name + '_MERGE_CSV_DLQ', visibility_timeout=cdk.Duration.seconds(90),
                         retention_period=cdk.Duration.seconds(1209600))

        #CSV merge queue
        MergeCSVQueue=_sqs.Queue(self, customer_name + '_MERGECSV',
                                     queue_name= customer_name + '_merge_csv_queue',
                                     visibility_timeout=cdk.Duration.seconds(1200),
                                     retention_period=cdk.Duration.seconds(1209600),
                                     dead_letter_queue=_sqs.DeadLetterQueue(max_receive_count=50, queue=merge_dlq)
                                     )
        
        #Function to merge CSV
        merge_comprehend_csv = _lambda.Function(self, customer_name + '_MergeComprehendCSV',
                                              function_name=customer_name+'_merge_comprehend_csv',
                                              description="Function to merge input CSVs to comprehend",
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='MergeComprehendCSV.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/MergeComprehendCSV'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                              ephemeral_storage_size=cdk.Size.gibibytes(10),
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              layers=[pandasLayer],
                                              environment={'BUCKET': raw_bucket.bucket_name,
                                                           'PREFIX': 'cdkdeployment-ss/comprehendInputFolder',
                                                           'QUEUE_URL': MergeCSVQueue.queue_url,
                                                           'OUTPUT_PREFIX' : 'cdkdeployment-ss/comprehendMergedInputFolder',
                                                           'OUTPUT_REF_PREFIX' : 'cdkdeployment-ss/comprehendMergedInputReference'
                                                           }
                                              )
        raw_bucket.grant_read_write(merge_comprehend_csv)
        MergeCSVQueue.grant_consume_messages(merge_comprehend_csv)
        # merge_comprehend_csv.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*"],resources=["*"]))

        #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(merge_comprehend_csv)

        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.SqsDestination(MergeCSVQueue), _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/comprehendInputFolder/", suffix=".csv", ))

        
        #-------------Event Notification from S3 merged comprehend i/p folder->Lambda-----------------------
        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(comprehend_step_trigger), _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/comprehendMergedInputFolder/", suffix=".csv", ))

        # rule=_events.Rule(
        #     self,
        #     "Trigger Lambda every 15mins to merge all csv files for preparing comprehend input",
        #     schedule=_events.Schedule.rate(Duration.minutes(15))
        # ) 

        # rule.add_target(_targets.LambdaFunction(merge_comprehend_csv))
        #-------------------------------------------------------Split merged CSVs---------------------------------------------------------

        split_csv_lambda=_lambda.Function(self, customer_name + "_splitCSVLambda",
                                function_name=customer_name + "_split_merged_csv",
                                code=_lambda.Code.from_asset('assets/lambda/splitCSVLambda'),
                                runtime=_lambda.Runtime.PYTHON_3_7,
                                handler="splitCSVLambda.lambda_handler",
                                layers=[pandasLayer],
                                timeout=Duration.minutes(15),
                                memory_size = 10240,
                                ephemeral_storage_size=cdk.Size.gibibytes(10),                                
                                environment= {
                                    "BUCKET" : customer_bucket_name,
                                    "OUTPUT_KEY" : "cdkdeployment-ss/splitCSVFiles/",
                                    "INPUT_REF" : "cdkdeployment-ss/comprehendMergedInputReference/"
                                })
       

        split_csv_lambda.add_to_role_policy(_iam.PolicyStatement(actions=["comprehend:StartDocumentClassificationJob",
                                                                              "comprehend:DescribeDocumentClassificationJob"],resources=["*"]))
        
        #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(split_csv_lambda)

        raw_bucket.grant_read_write(split_csv_lambda)

        #------------------------Add Event notification->lexicon_lambda-----------------------------

        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(split_csv_lambda), _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/comprehendOutputFolder/", suffix=".gz", ))

        

        #------------------------------------------------------------Lexicon Transformation-----------------------------------------------
        
        lexicon_transformation=_lambda.Function(self, customer_name + "_TransformLexicon",
                                function_name=customer_name + "_transform_lexicon_lambda_func",
                                description = 'Fetch Split CSVs and transform to Lexicon format',
                                code=_lambda.Code.from_asset('assets/lambda/TransformLexicon'),
                                runtime=_lambda.Runtime.PYTHON_3_7,
                                handler="TransformLexicon.lambda_handler",
                                timeout=Duration.minutes(15),
                                memory_size = 10240,
                                environment= {
                                    "OUTPUT_BUCKET" : customer_bucket_name,
                                    "OUTPUT_KEY" : "cdkdeployment-ss/lexiconOutput/",
                                    "SCORE" : "0.3"
                                })
       

        lexicon_transformation.add_to_role_policy(_iam.PolicyStatement(actions=["comprehend:StartDocumentClassificationJob",
                                                                              "comprehend:DescribeDocumentClassificationJob"],resources=["*"]))

        
        #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(lexicon_transformation)

        raw_bucket.grant_read_write(lexicon_transformation)

        #------------------------Add Event notification->lexicon_lambda-----------------------------

        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(lexicon_transformation), _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/splitCSVFiles/", suffix=".gz", ))

        
        
        # multiprocesstest=_lambda.Function(self, customer_name + "_MultiProcessTest",
        #                         function_name=customer_name + "_multi_process_test",
        #                         description = 'Testing multiprocess',
        #                         code=_lambda.Code.from_asset('assets/lambda/testMultiprocess'),
        #                         runtime=_lambda.Runtime.PYTHON_3_7,
        #                         handler="testMultiprocess.lambda_handler",
        #                         layers=[pandasLayer],
        #                         timeout=Duration.minutes(15),
        #                         memory_size = 10240,
        #                         ephemeral_storage_size=cdk.Size.gibibytes(10),
        #                         environment= {
        #                             "OUTPUT_BUCKET" : customer_bucket_name,
        #                             "OUTPUT_KEY" : "cdkdeployment-ss/lexiconOutput/",
        #                             "SCORE" : "0.3"
        #                         })
       

        # multiprocesstest.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*","s3:*"],resources=["*"]))



