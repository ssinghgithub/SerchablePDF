import aws_cdk as cdk
import aws_cdk.aws_s3 as _s3
import aws_cdk.aws_sqs as _sqs
import aws_cdk.aws_iam as _iam
import aws_cdk.aws_lambda as _lambda
import aws_cdk.aws_s3_notifications as _s3n
import aws_cdk.aws_sns as _sns
import aws_cdk.aws_sns_subscriptions as _snssubscr
import aws_cdk.aws_stepfunctions as _sfn
import aws_cdk.aws_stepfunctions_tasks as _tasks
import aws_cdk.aws_sns_subscriptions as subscriptions
from aws_cdk.aws_kms import Key


from aws_cdk import Duration
import aws_cdk.aws_events as _events
import aws_cdk.aws_events_targets as _targets
from aws_cdk.aws_lambda_event_sources import (S3EventSource, SqsEventSource, SnsEventSource, DynamoEventSource)
from aws_cdk import aws_events, aws_events_targets

from cdk_nag import NagSuppressions

from config import PipelineResource



class TrainingPipelineWorkAroundStack(cdk.Stack):

    def __init__(self, scope, construct_id, **kwargs):
        super().__init__(scope, construct_id, **kwargs)

        #----------------------Resource Names--------------------------
        customer_bucket_name=PipelineResource.BUCKET_NAME
        document_classification_model=PipelineResource.CLASSIFICATION_MODEL
        customer_name=PipelineResource.CUSTOMER_NAME
        kms_key_id=PipelineResource.KMS_KEY
        kms_key_arn=PipelineResource.KMS_KEY_ARN
        comprehend_data_access_role=PipelineResource.COMPREHEND_DATA_ACCESS_ROLE_ARN
        training_mode=PipelineResource.TRAINING_FLAG
        textract_jobs_json = "cdkdeployment-ss/training/"+PipelineResource.TEXTRACT_JOBS_JSON
        textract_page_limit=str(PipelineResource.TEXTRACT_PAGE_LIMIT)
        textract_file_size_limit=str(PipelineResource.TEXTRACT_FILE_SIZE_LIMIT)
        inference_batch_size=str(PipelineResource.INFERENCE_BATCH_SIZE)
        training_data_input_loc = PipelineResource.TRAINING_DATA_INPUT_LOC
        raw_label_prefix = PipelineResource.TRAINING_RAW_LABEL
        keywords_usage_flag = PipelineResource.KEYWORD_USAGE_FLAG
        keywords_prefix = PipelineResource.TRAINING_KEYWORDS
        comprehend_training_notification_email = PipelineResource.COMPREHEND_TRAINING_NOTIFICATION_EMAIL

        #-----------------------CDK-Nag Stack Suppressions-------------------
        NagSuppressions.add_stack_suppressions(self, 
            [
                {"id":"HIPAA.Security-LambdaConcurrency", "reason": "Expected high levels of concurrency"},
                {"id":"HIPAA.Security-IAMNoInlinePolicy", "reason": "IAM policies are unique to their respective service role"},
                {"id":"HIPAA.Security-LambdaDLQ", "reason": "Enabling DLQ for all lambda functions outside of scope"},
                {"id":"HIPAA.Security-LambdaInsideVPC", "reason": "Expected high levels of concurrency may lead to IP address exhaustion"}
            ]
        )


        # The code that defines your stack goes here

        #------------------ KMS Key that is already defined -----------------------

        defined_kms_key = Key.from_key_arn(self, id=kms_key_id, key_arn=kms_key_arn)

        '''******************************SNS Topics****************************** '''
        jobCompletionTopic=_sns.Topic(self, customer_name+'trainingjobCompletion', master_key=defined_kms_key)


        '''******************************IAM Roles****************************** '''

        textractServiceRole=_iam.Role(self, customer_name + '_TextractServiceRole', assumed_by=_iam.ServicePrincipal('textract'
                                                                                                      '.amazonaws.com'))
        textractServiceRole.add_to_policy(_iam.PolicyStatement(effect=_iam.Effect.ALLOW,
                                                               actions=["sns:Publish"],
                                                               resources=[jobCompletionTopic.topic_arn]))
        
        defined_kms_key.grant_encrypt_decrypt(textractServiceRole)

        '''******************************S3 Bucket****************************** '''
        # Create raw and textract output S3 buckets
        # input bucket
        # raw_bucket=_s3.Bucket(self, 'raw_bucket',
        #                         bucket_name=EnvSettings.INPUT_BUCKET_NAME,
        #                         auto_delete_objects=True,
        #                         removal_policy=cdk.RemovalPolicy.DESTROY,
        #                         lifecycle_rules=[_s3.LifecycleRule(
        #                             transitions=[_s3.Transition(
        #                                 storage_class=_s3.StorageClass.GLACIER,
        #                                 transition_after=cdk.Duration.days(7))]
        #                         )])

        raw_bucket=_s3.Bucket.from_bucket_name(self,"Bucket",customer_bucket_name)
        
        '''******************************SQS****************************** '''
        # DLQ
        dlq=_sqs.Queue(self, customer_name + '_trainingDLQ', visibility_timeout=cdk.Duration.seconds(90),
                         retention_period=cdk.Duration.seconds(1209600))

        # Queue for async jobs
        inputDocQueue=_sqs.Queue(self, customer_name + '_trainingInputDocs',
                                   queue_name= customer_name + '_training_raw_input_pdf_queue',
                                   visibility_timeout=cdk.Duration.seconds(900),
                                   retention_period=cdk.Duration.seconds(1209600),
                                   dead_letter_queue=_sqs.DeadLetterQueue(max_receive_count=50, queue=dlq)
                                   )
        
        # Add notification events to the input bucket
        # raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.SqsDestination(inputDocQueue),
        #                                   _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/training/inputFolder/", suffix=".pdf", )
        #                                   )



        # Queue for async Textract jobs results
        jobResultsQueue=_sqs.Queue(self, customer_name + '_trainingJobResults',
                                     queue_name= customer_name + '_training_textractjob_results_queue',
                                     visibility_timeout=cdk.Duration.seconds(1200),
                                     retention_period=cdk.Duration.seconds(1209600),
                                     dead_letter_queue=_sqs.DeadLetterQueue(max_receive_count=50, queue=dlq)
                                     )
        # Trigger between SNS -> SQS once Textract job is completed
        jobCompletionTopic.add_subscription(_snssubscr.SqsSubscription(jobResultsQueue))

        # Textract Limit SQS
        textractLimitQueue=_sqs.Queue(self, customer_name + '_trainingTextractLimit',
                                   queue_name=customer_name + '_training_textract_limit_queue',
                                   visibility_timeout=cdk.Duration.seconds(90),
                                   retention_period=cdk.Duration.seconds(1209600),
                                   dead_letter_queue=_sqs.DeadLetterQueue(max_receive_count=50, queue=dlq)
                                   )


        # pypdf2 layer
        pypdf2Layer=_lambda.LayerVersion(self,'PyPDF2Layer',
                                           code=_lambda.Code.from_asset('assets/lambda/PyPDF2.zip'),
                                           compatible_runtimes=[_lambda.Runtime.PYTHON_3_7],
                                           license='Apache-2.0',
                                           description='PyPDF2 layer')
        
        
        #-------------------------------------------Use Pandas Layer provided by AWS----------------------------
        pandasLayer=_lambda.LayerVersion.from_layer_version_arn(self,"PandasLayer",layer_version_arn="arn:aws:lambda:us-east-1:336392948345:layer:AWSSDKPandas-Python37:5")

     
        #-------------------------State Machine for Large PDF --------------------------------------

        # Lambda Handlers Definitions

        SplitLambda=_lambda.Function(self, customer_name + '_trainingSplitLambda',
                                       function_name=customer_name + '_training_split_file_lambda',
                                       description="Function to split the files in smaller chunks",
                                       runtime=_lambda.Runtime.PYTHON_3_7,
                                       handler='SplitLambda.lambda_handler',
                                       layers=[pypdf2Layer],
                                       code=_lambda.Code.from_asset('assets/lambda/trainingTextractworkaroundSMLambda/split_lambda/'),
                                       timeout=cdk.Duration.seconds(900),
                                       memory_size=10240,
                                       ephemeral_storage_size=cdk.Size.gibibytes(10),
                                       retry_attempts=0,
                                       environment={
                                            "TMP_SPLIT_PREFIX": 'cdkdeployment-ss/training/workaround/tmp_split/',
                                            "TEXTRACT_PAGE_LIMIT": textract_page_limit,
                                            "TEXTRACT_FILE_SIZE_LIMIT": textract_file_size_limit                                       
                                            }
                                       )
        raw_bucket.grant_read_write(SplitLambda)
     
        defined_kms_key.grant_encrypt_decrypt(SplitLambda)

        StartTextractJobLambda=_lambda.Function(self, customer_name + '_trainingStartTextractJobLambda',
                                                  function_name=customer_name + '_training_start_textract_job_lambda',
                                                  description="Function to kick-off textract Job for smaller chunks",
                                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                                  handler='StartTextractJobLambda.lambda_handler',
                                                  code=_lambda.Code.from_asset('assets/lambda/trainingTextractworkaroundSMLambda/start_job/'),
                                                  timeout=cdk.Duration.seconds(300),
                                                  memory_size=10240,
                                                  ephemeral_storage_size=cdk.Size.gibibytes(10),
                                                  retry_attempts=0,
                                                  environment={
                                                        "TEXTRACT_JOBS_LOG" : textract_jobs_json
                                                    }
                                                  )
        raw_bucket.grant_read_write(StartTextractJobLambda)

        StartTextractJobLambda.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                       resources=[textractServiceRole.role_arn]))
        StartTextractJobLambda.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                                "textract:GetDocumentTextDetection"],
                                                                       resources=["*"]))
        
        defined_kms_key.grant_encrypt_decrypt(StartTextractJobLambda)

        CheckJobStatusLambda=_lambda.Function(self, customer_name + '_trainingCheckJobStatusLambda',
                                                function_name=customer_name + '_training_check_job_status_lambda',
                                                description="Function to check the Textract job status",
                                                runtime=_lambda.Runtime.PYTHON_3_7,
                                                handler='CheckJobStatusLambda.lambda_handler',
                                                code=_lambda.Code.from_asset('assets/lambda/trainingTextractworkaroundSMLambda/check_status/'),
                                                timeout=cdk.Duration.seconds(900),
                                                memory_size=10240,
                                                ephemeral_storage_size=cdk.Size.gibibytes(10),
                                                retry_attempts=0,
                                                environment={
                                                        'TEXTRACT_JOBS_LOG' : textract_jobs_json,
                                                        'MERGED_RES_LOC': 'cdkdeployment-ss/training/training_textract_separate_merged/',
                                                        'CUSTOMER_NAME' : customer_name,
                                                        'RAW_LABEL' : raw_label_prefix,
                                                        'INVOKING_LAMBDA' : customer_name+'_training_label_formatting',
                                                        'BUCKET_NAME' : raw_bucket.bucket_name
                                                    }
                                                )
                                                
        CheckJobStatusLambda.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                     resources=[textractServiceRole.role_arn]))
        CheckJobStatusLambda.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                                "textract:GetDocumentTextDetection"],
                                                                     resources=["*"]))
        

        raw_bucket.grant_read_write(CheckJobStatusLambda)

        defined_kms_key.grant_encrypt_decrypt(CheckJobStatusLambda)

        MergeLambda=_lambda.Function(self, customer_name + '_trainingMergeLambda',
                                       function_name=customer_name + '_training_merge_lambda',
                                       description="Function to Merge the textract results",
                                       runtime=_lambda.Runtime.PYTHON_3_7,
                                       handler='MergeLambda.lambda_handler',
                                       code=_lambda.Code.from_asset('assets/lambda/trainingTextractworkaroundSMLambda/merge_lambda/'),
                                       timeout=cdk.Duration.seconds(900),
                                       memory_size=10240,
                                       ephemeral_storage_size=cdk.Size.gibibytes(10),
                                       retry_attempts=0,
                                       layers=[pandasLayer],
                                       environment={'MERGED_LOC': 'cdkdeployment-ss/training/workaround/merged/',
                                                    'TEXTRACT_JOBS_LOG' : textract_jobs_json,
                                                    'MERGED_RES_LOC': 'cdkdeployment-ss/training/training_textract_separate_merged/',
                                                    'CUSTOMER_NAME' : customer_name,
                                                    'RAW_LABEL' : raw_label_prefix,
                                                    'INVOKING_LAMBDA' : customer_name+'_training_label_formatting'
                                                    }
                                       )

        raw_bucket.grant_read_write(MergeLambda)
        
        defined_kms_key.grant_encrypt_decrypt(MergeLambda)

        MergeLambda.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                            resources=[textractServiceRole.role_arn]))
        MergeLambda.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                    "textract:GetDocumentTextDetection"],
                                                            resources=["*"]))
        
        
        
        # trainConvertToCSV=_lambda.Function(self, customer_name + 'TrainingConvertToCSV',
        #                                       function_name=customer_name+'_training_convert_json_csv',
        #                                       description="Function to run process Textract Output",
        #                                       runtime=_lambda.Runtime.PYTHON_3_7,
        #                                       handler='trainConvertJsontoCSV.lambda_handler',
        #                                       code=_lambda.Code.from_asset('assets/lambda/trainConvertJsontoCSV'),
        #                                       timeout=cdk.Duration.seconds(900),
        #                                       memory_size=10240,
        #                                     #   ephemeral_storage_size=10240,
        #                                       retry_attempts=0,
        #                                       reserved_concurrent_executions=5,
        #                                       layers=[pandasLayer],
        #                                       environment={'bucketName': raw_bucket.bucket_name,
        #                                                    'PREFIX': 'cdkdeployment-ss/training/training_textract_separate_merged',
        #                                                    'TEXTRACT_JOBS_LOG' : textract_jobs_json,
        #                                                    'CUSTOMER_NAME' : customer_name,
        #                                                    'RAW_LABEL' : 'cdkdeployment-ss/training/raw_label'
        #                                                    }
        #                                       )

        # Permission
        # raw_bucket.grant_read_write(trainConvertToCSV)


        # trainConvertToCSV.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*"],
        #                                                        resources=["*"]))
        # trainConvertToCSV.add_to_role_policy(_iam.PolicyStatement(actions=["lambda:*"],
        #                                                        resources=["*"]))
        # Step functions Definition

        split_job=_tasks.LambdaInvoke(
            self, "Split Job",
            lambda_function=SplitLambda,
            output_path="$.Payload",
        )
        start_textract_job=_tasks.LambdaInvoke(
            self, "Start Textract Job",
            lambda_function=StartTextractJobLambda,
            output_path="$.Payload",
        )

        wait_job=_sfn.Wait(
            self, "Wait 1 Minute",
            time=_sfn.WaitTime.duration(
                cdk.Duration.seconds(60))
        )

        status_job=_tasks.LambdaInvoke(
            self, "Get Textract Job Status",
            lambda_function=CheckJobStatusLambda,
            output_path="$.Payload",
        )

        fail_job=_sfn.Fail(
            self, "Fail",
            cause='AWS Batch Job Failed',
            error='DescribeJob returned FAILED'
        )

        # succeed_job=_sfn.Succeed(
        #     self, "Succeeded",
        #     comment='AWS Batch Job succeeded'
        # )

        merge_textract_output=_tasks.LambdaInvoke(
            self, "Merge Textract Json Output",
            lambda_function=MergeLambda,
            output_path="$.Payload",
        )

        # convert_json_to_csv = _tasks.LambdaInvoke(
        #     self, "Convert Json to CSV",
        #     lambda_function=trainConvertToCSV,
        # )

        # Create Chain

        definition=split_job.next(start_textract_job) \
            .next(wait_job) \
            .next(status_job) \
            .next(_sfn.Choice(self, 'All Job Complete?')
                  .when(_sfn.Condition.string_equals('$.JobStatus', 'FAILED'), fail_job)
                  .when(_sfn.Condition.string_equals('$.JobStatus', 'SUCCEEDED'), merge_textract_output.  
                        next(_sfn.Choice(self, 'Merge Complete?')
                             .when(_sfn.Condition.string_equals('$.merge_complete', 'true'),_sfn.Pass(self,"Pass"))
                             .otherwise(merge_textract_output)
                             )
                             )
                  .otherwise(wait_job))

        # Create state machine
        workaround_step_func=_sfn.StateMachine(
            self, customer_name + "_trainingStateMachine",
            definition=definition,
        )
        
        #---------------------------------------------------------------------------------------------
        
        # Process Input Lambda - Process input queue
        inputEventProcessor=_lambda.Function(self, customer_name + '_trainingworkaroundinputEventProcessor',
                                              function_name=customer_name +'_training_input_sqs_msg_processor',
                                              description='Function to process messages from input queue',
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='TrainTextractSubmitLambda.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/TrainTextractSubmitLambda'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                              ephemeral_storage_size= cdk.Size.gibibytes(10),
                                              layers=[pypdf2Layer],
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              environment={
                                                            "ASYNC_QUEUE_URL": inputDocQueue.queue_url,
                                                            "KMS_KEY" : kms_key_id,
                                                            "TEXTRACT_OUTPUT_LOC" : "cdkdeployment-ss/training/textractOutputFolder",
                                                            "SNS_TOPIC_ARN": jobCompletionTopic.topic_arn,
                                                            "SNS_ROLE_ARN": textractServiceRole.role_arn,
                                                            "LIMIT_QUEUE_URL": textractLimitQueue.queue_url,                                                            
                                                            "OUTPUT_BUCKET" : raw_bucket.bucket_name,
                                                            "TEXTRACT_PAGE_LIMIT": textract_page_limit,
                                                            "TEXTRACT_FILE_SIZE_LIMIT": textract_file_size_limit,
                                                            "INFERENCE_BATCH_SIZE": inference_batch_size,
                                                            "INPUT_PREFIX" : training_data_input_loc,
                                                            "TEXTRACT_JOBS_LOG" : textract_jobs_json,
                                                            "BUCKET" : raw_bucket.bucket_name,
                                                            }
                                              )
        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(inputEventProcessor),
                                          _s3.NotificationKeyFilter(prefix=raw_label_prefix, suffix=".csv", )
                                          )
        #------------------------------------------------------------5mins EVENT BRIDGE RULE------------------------------------------------------------

       
        # Permissions
        raw_bucket.grant_read_write(inputEventProcessor)

        defined_kms_key.grant_encrypt_decrypt(inputEventProcessor)

        inputEventProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                               resources=[textractServiceRole.role_arn]))
        inputEventProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                            "textract:GetDocumentTextDetection"],
                                                               resources=["*"]))
        

        textractLimitQueue.grant_send_messages(inputEventProcessor)


        #----------------------Over Limit Textract processor------------------------------------
        StartLimitProcSMLambda=_lambda.Function(self, customer_name + '_trainingStartLimitProcSMLambda',
                                              function_name=customer_name + '_training_start_limit_processor',
                                              description='Function to process messages from HL queue',
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='StartHLProcSMLambda.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/trainingTextractworkaroundSMLambda/StartLimitProcSMLambda/'),
                                              timeout=cdk.Duration.seconds(60),
                                              retry_attempts=0,
                                              layers=[pandasLayer],
                                              reserved_concurrent_executions=5,
                                              environment={
                                                  'LIMIT_QUEUE_URL': textractLimitQueue.queue_url,
                                                  "STATE_MACHINE_ARN": workaround_step_func.state_machine_arn
                                              }
                                              )

        # Permissions
        raw_bucket.grant_read_write(StartLimitProcSMLambda)
        textractLimitQueue.grant_consume_messages(StartLimitProcSMLambda)
        StartLimitProcSMLambda.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                   resources=[textractServiceRole.role_arn]))
        StartLimitProcSMLambda.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                                "textract:GetDocumentTextDetection"],
                                                                   resources=["*"]))
        StartLimitProcSMLambda.add_event_source(SqsEventSource(queue=textractLimitQueue))
        workaround_step_func.grant_start_execution(StartLimitProcSMLambda)

        defined_kms_key.grant_encrypt_decrypt(StartLimitProcSMLambda)


        #-------------------------------------------Lambda function to process Textract output result----------------------------
        jobResultProcessor=_lambda.Function(self, customer_name + 'TrainingJobResultProcessor',
                                              function_name=customer_name+'_training_textract_result_processor',
                                              description="Function to run process Textract Output",
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='TrainingResultProcLambda.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/TrainingResultProcLambda'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                            #   ephemeral_storage_size=10240,
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              layers=[pandasLayer],
                                              environment={'bucketName': raw_bucket.bucket_name,
                                                           'PREFIX': 'cdkdeployment-ss/training/training_textract_separate_merged',
                                                           'qUrl': jobResultsQueue.queue_url,
                                                           'TEXTRACT_JOBS_LOG' : textract_jobs_json,
                                                           'CUSTOMER_NAME' : customer_name,
                                                           'RAW_LABEL' : raw_label_prefix,
                                                           'INVOKING_LAMBDA' : customer_name+'_training_label_formatting'
                                                           }
                                              )

        # Permission
        raw_bucket.grant_read_write(jobResultProcessor)

        defined_kms_key.grant_encrypt_decrypt(jobResultProcessor)

        jobResultsQueue.grant_consume_messages(jobResultProcessor)
        jobResultProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                   resources=[textractServiceRole.role_arn]))
        jobResultProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["textract:StartDocumentTextDetection",
                                                                            "textract:GetDocumentTextDetection"],
                                                                   resources=["*"]))


        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(jobResultProcessor),
                                                 _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/training/workaround/merged/", suffix=".json"))



        jobResultProcessor.add_event_source(SqsEventSource(queue=jobResultsQueue))

        # more lambdas:
        # - Keywords and label - only cleaning user labels
        # - merge downsample

        #-------------------------------------------Keywords and label----------------------------
      
        labelFormatter = _lambda.Function(self, 'trainingLabelFormat',
                                              function_name=customer_name+'_training_label_formatting',
                                              description="Function to clean the uploaded RAW Labels",
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='KeywordLabelFormat.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/KeywordLabelFormat'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                            #   ephemeral_storage_size=10240,
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              layers=[pandasLayer],
                                              environment={'bucketName': raw_bucket.bucket_name,
                                                           'PREFIX': raw_label_prefix,
                                                           }
                                              )
        
        defined_kms_key.grant_encrypt_decrypt(labelFormatter)

        jobResultProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["lambda:InvokeFunction"],
                                                               resources=[labelFormatter.function_arn]))
        
        CheckJobStatusLambda.add_to_role_policy(_iam.PolicyStatement(actions=["lambda:InvokeFunction"],
                                                               resources=[labelFormatter.function_arn]))
        MergeLambda.add_to_role_policy(_iam.PolicyStatement(actions=["lambda:InvokeFunction"],
                                                               resources=[labelFormatter.function_arn]))
        
        
        raw_bucket.grant_read_write(labelFormatter)


        #-------------------------------------------Merge all Textract CSVs to one large CSV----------------------------


        mergeTextractOutputCSV = _lambda.Function(self, 'mergeTextractOutputCSV',
                                              function_name=customer_name+'_training_merge_textract_output_csv',
                                              description="Function to merge all textract output CSV",
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='mergeTextractOutputCSV.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/mergeTextractOutputCSV'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                              ephemeral_storage_size=cdk.Size.mebibytes(10240),
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              layers=[pandasLayer],
                                              environment={'bucketName': raw_bucket.bucket_name,
                                                           'OUTPUT_PREFIX': 'cdkdeployment-ss/training/training_textract_large_merged_output/',
                                                           'INPUT_PREFIX' : 'cdkdeployment-ss/training/training_textract_separate_merged/'
                                                           }
                                              )
        defined_kms_key.grant_encrypt_decrypt(mergeTextractOutputCSV)

        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(mergeTextractOutputCSV),
                                          _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/training/reformatted_label/", suffix=".csv", )
                                          )

        
        raw_bucket.grant_read_write(mergeTextractOutputCSV)


        #-------------------------------------------Downsample and form a CSV for comprehend training ----------------------------

        downsamplingMergeData = _lambda.Function(self, 'DownsamplingDataMerge',
                                              function_name=customer_name+'_training_downsample_data_merge',
                                              description="Function to perform downsampling and generate training data for comprehend",
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='DownsamplingDataMerge.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/DownsamplingDataMerge'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                              ephemeral_storage_size=cdk.Size.mebibytes(10240),
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              layers=[pandasLayer],
                                              environment={'LABEL_PREFIX' : 'cdkdeployment-ss/training/reformatted_label/batch3_label_revised.csv',
                                                           'TEXTRACT_MERGED_PREFIX' : 'cdkdeployment-ss/training/training_textract_large_merged_output/',
                                                           'COMPREHEND_TRAINING_INPUT': 'cdkdeployment-ss/training/comprehend_training_input/',
                                                           'KEYWORDS_PREFIX' : keywords_prefix,
                                                           'KEYWORD_USAGE_FLAG' : keywords_usage_flag
                                                           }
                                              )
        
        raw_bucket.grant_read_write(downsamplingMergeData)
        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(downsamplingMergeData),
                                    _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/training/training_textract_large_merged_output/", suffix=".csv", )
                                    )

        defined_kms_key.grant_encrypt_decrypt(downsamplingMergeData)
        


        #------------------------------------------------------Comprehend Step Functions for Training workflow----------------------------------------------

        # comprehend_dataaccess_role=_iam.Role(self,"ComprehendDataRole",
        #     assumed_by=_iam.ServicePrincipal("comprehend.amazonaws.com"),
        #     description="Comprehend Data Access Role"
        # )
        # dataaccesspolicy=_iam.ManagedPolicy.from_aws_managed_policy_name('service-role/ComprehendDataAccessRolePolicy')
        # s3_access_policy=_iam.ManagedPolicy.from_aws_managed_policy_name('AmazonS3FullAccess')

        # comprehend_dataaccess_role.add_managed_policy(dataaccesspolicy)
        # comprehend_dataaccess_role.add_managed_policy(s3_access_policy)

        start_comp_inference=_lambda.Function(self, customer_name+"CompTrainModel",
                                  function_name=customer_name+"_start_comprehend_model_training",
                                  code=_lambda.Code.from_asset('assets/lambda/CompTrainModel'),
                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                  handler="CompTrainModel.lambda_handler",
                                  timeout=Duration.seconds(25),
                                  environment={
                                    'KMS_KEY' : kms_key_arn,
                                    'TRAINING_DATA_BUCKET' : customer_bucket_name,
                                    'TRAINING_DATA_KEY' : 's3://{}/cdkdeployment-ss/training/comprehend_training_input'.format(customer_bucket_name),
                                    'CLASSIFIER_NAME' : "Downsample",
                                    'DATA_ACCESS_ROLE' : comprehend_data_access_role,
                                    'REGION' : 'us-east-1 '
                                  })
        start_comp_inference.add_to_role_policy(_iam.PolicyStatement(actions=["comprehend:CreateDocumentClassifier",
                                                                              "comprehend:DescribeDocumentClassifier"],resources=["*"]))

         #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(start_comp_inference)

        raw_bucket.grant_read_write(start_comp_inference)

        start_comp_inference.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                               resources=[comprehend_data_access_role]))
                                                               
        get_inference_status=_lambda.Function(self, customer_name+"CompTrainingStatus",
                                  function_name=customer_name+"_get_comprehend_training_status",
                                  code=_lambda.Code.from_asset('assets/lambda/CompTrainingStatus'),
                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                  handler="CompTrainingStatus.lambda_handler",
                                  timeout=Duration.seconds(25),
                                  environment={
                                    'REGION' : 'us-east-1'
                                  })
        get_inference_status.add_to_role_policy(_iam.PolicyStatement(actions=["comprehend:CreateDocumentClassifier",
                                                                              "comprehend:DescribeDocumentClassifier"],resources=["*"]))

        #Grant KMS Key permissions
        defined_kms_key.grant_encrypt_decrypt(get_inference_status)

        raw_bucket.grant_read_write(get_inference_status)

        get_inference_status.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                               resources=[comprehend_data_access_role]))

        

        submit_comp_job=_tasks.LambdaInvoke(self, "Submit Comprehend Job",
            lambda_function=start_comp_inference,
            # Lambda's result is in the attribute `Payload`
            result_path="$.Payload"
        )

        wait_x=_sfn.Wait(self, "Wait 10 Minutes Comprehend",
            time=_sfn.WaitTime.duration(Duration.seconds(600))
        )

        get_comp_job_status=_tasks.LambdaInvoke(self, "Get Job Status",
            lambda_function=get_inference_status,
            # Pass just the field named "guid" into the Lambda, put the
            # Lambda's result in a field called "status" in the response
            input_path="$.Payload",
            result_path="$.status"
        )
        
        train_success_topic=_sns.Topic(self,customer_name+"-comprehend-training-success-notification")
        train_success_topic.add_subscription(subscriptions.EmailSubscription(comprehend_training_notification_email))

        # CDK-Nag Resource Specific Suppression
        NagSuppressions.add_resource_suppressions(train_success_topic, [
            {"id": "HIPAA.Security-SNSEncryptedKMS", "reason": "Static completion message containing no user data."}
        ])

        train_success_notification=_tasks.SnsPublish(self, "Publish Training Success Notification",
                                                 topic=train_success_topic,
                                                 message=_sfn.TaskInput.from_text("The Training job has been completed"))


        train_failed_topic=_sns.Topic(self,customer_name+"-comprehend-training-failed-notification")
        train_failed_topic.add_subscription(subscriptions.EmailSubscription(comprehend_training_notification_email))

        # CDK-Nag Resource Specific Suppression
        NagSuppressions.add_resource_suppressions(train_failed_topic, [
            {"id": "HIPAA.Security-SNSEncryptedKMS", "reason": "Static completion message containing no user data."}
        ])

        train_failure_notification=_tasks.SnsPublish(self, "Publish Training Failure Notification",
                                                 topic=train_failed_topic,
                                                 message=_sfn.TaskInput.from_text("The Training Job has failed"))


        job_failed=_sfn.Fail(self, "Job Failed",
            cause="Comprehend Job Failed",
            error="DescribeJob returned FAILED"
        )


        job_success=_sfn.Succeed(self,"Comprehend Classification Successful")

        # definition=submit_comp_job.next(wait_x).next(get_comp_job_status).next(_sfn.Choice(self, "Job Complete?")\
        #                                                            .when(_sfn.Condition.string_equals("$.status.Payload.JobStatus", "FAILED"), job_failed)\
        #                                                             .when(_sfn.Condition.string_equals("$.status.Payload.JobStatus", "COMPLETED"), job_success).otherwise(wait_x))
        
        definition=submit_comp_job.next(wait_x).next(get_comp_job_status).next(_sfn.Choice(self, "Job Complete?")\
                                                                   .when(_sfn.Condition.string_equals("$.status.Payload.JobStatus", "IN_ERROR"), train_failure_notification.next(job_failed))\
                                                                    .when(_sfn.Condition.string_equals("$.status.Payload.JobStatus", "TRAINED"), train_success_notification.next(job_success)).otherwise(wait_x))                                                                    
        
        comprehend_state_machine=_sfn.StateMachine(self, customer_name + "_ComprehendTrainingStepFunc",
            definition=definition,
        )

        
        
        #------------------------------------------------------------TRIGGER LAMBDA FOR THE ABOVE STEPFUNCTION------------------------------------------------------------

        comprehend_step_trigger=_lambda.Function(self, customer_name + "_trainingTriggerComprehendStepFunc",
                                  function_name=customer_name + '_trigger_comprehend_training',
                                  code=_lambda.Code.from_asset('assets/lambda/comprehendTriggerLambda/'),
                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                  handler="comprehendTriggerLambda.lambda_handler",
                                  timeout=Duration.seconds(300),
                                  environment={
                                    "STATE_MACHINE_ARN" : comprehend_state_machine.state_machine_arn
                                  })

        comprehend_step_trigger.add_to_role_policy(_iam.PolicyStatement(actions=["states:StartExecution"],
                                                                   resources=[comprehend_state_machine.state_machine_arn]))


        #-------------Event Notification from S3 comprehend i/p folder->Lambda-----------------------
        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(comprehend_step_trigger), _s3.NotificationKeyFilter(prefix="cdkdeployment-ss/training/comprehend_training_input/", suffix=".csv", ))