import aws_cdk as cdk
import aws_cdk.aws_s3 as _s3
import aws_cdk.aws_sqs as _sqs
import aws_cdk.aws_iam as _iam
import aws_cdk.aws_lambda as _lambda
import aws_cdk.aws_s3_notifications as _s3n
import aws_cdk.aws_sns as _sns
import aws_cdk.aws_sns_subscriptions as _snssubscr
import aws_cdk.aws_stepfunctions as _sfn
import aws_cdk.aws_stepfunctions_tasks as _tasks
import aws_cdk.aws_sns_subscriptions as subscriptions

from aws_cdk import Duration
from aws_cdk import Size
import aws_cdk.aws_events as _events
import aws_cdk.aws_events_targets as _targets
from aws_cdk.aws_lambda_event_sources import (S3EventSource, SqsEventSource, SnsEventSource, DynamoEventSource)
from aws_cdk import aws_events, aws_events_targets

from config import PipelineResource



class TrainingPipelineStack(cdk.Stack):

    def __init__(self, scope, construct_id, **kwargs):
        super().__init__(scope, construct_id, **kwargs)

        #----------------------Resource Names--------------------------
        customer_bucket_name = PipelineResource.BUCKET_NAME
        document_classification_model = PipelineResource.CLASSIFICATION_MODEL
        customer_name = PipelineResource.CUSTOMER_NAME
        kms_key_id = PipelineResource.KMS_KEY
        kms_key_arn = PipelineResource.KMS_KEY_ARN
        comprehend_data_access_role = PipelineResource.COMPREHEND_DATA_ACCESS_ROLE_ARN
        training_mode = PipelineResource.TRAINING_FLAG
        textract_jobs_json = "cdkdeployment/training/"+PipelineResource.TEXTRACT_JOBS_JSON
        



        # The code that defines your stack goes here
        '''******************************SNS Topics****************************** '''
        jobCompletionTopic = _sns.Topic(self, customer_name+'trainingjobCompletion')

        '''******************************IAM Roles****************************** '''

        textractServiceRole = _iam.Role(self, customer_name+'TextractServiceRole', assumed_by=_iam.ServicePrincipal('textract'
                                                                                                      '.amazonaws.com'))
        textractServiceRole.add_to_policy(_iam.PolicyStatement(effect=_iam.Effect.ALLOW,
                                                               actions=["sns:Publish"],
                                                               resources=[jobCompletionTopic.topic_arn]))

        '''******************************S3 Bucket****************************** '''
        # Create raw and textract output S3 buckets
        # input bucket
        # raw_bucket = _s3.Bucket(self, 'raw_bucket',
        #                         bucket_name=EnvSettings.INPUT_BUCKET_NAME,
        #                         auto_delete_objects=True,
        #                         removal_policy=cdk.RemovalPolicy.DESTROY,
        #                         lifecycle_rules=[_s3.LifecycleRule(
        #                             transitions=[_s3.Transition(
        #                                 storage_class=_s3.StorageClass.GLACIER,
        #                                 transition_after=cdk.Duration.days(7))]
        #                         )])

        raw_bucket = _s3.Bucket.from_bucket_name(self,"Bucket",customer_bucket_name)
        # # textract output bucket
        # textract_output_bucket = _s3.Bucket(self, 'textract_output_bucket',
        #                                     bucket_name=EnvSettings.TEXTRACT_OUTPUT_BUCKET_NAME,
        #                                     auto_delete_objects=True,
        #                                     removal_policy=cdk.RemovalPolicy.DESTROY)

        '''******************************SQS****************************** '''
        # # DLQ
        dlq = _sqs.Queue(self, customer_name+'trainingDLQ', visibility_timeout=cdk.Duration.seconds(90),
                         retention_period=cdk.Duration.seconds(1209600))

        # # Queue for async jobs
        # inputDocQueue = _sqs.Queue(self, 'trainingInputDocs',
        #                            queue_name= customer_name+'_training_raw_input_pdf_queue',
        #                            visibility_timeout=cdk.Duration.seconds(900),
        #                            retention_period=cdk.Duration.seconds(1209600),
        #                            dead_letter_queue=_sqs.DeadLetterQueue(max_receive_count=50, queue=dlq)
        #                            )
        # # Add notification events to the input bucket
        # raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.SqsDestination(inputDocQueue),
        #                                   _s3.NotificationKeyFilter(prefix="cdkdeployment/train_inputFolder/", suffix=".pdf", )
        #                                   )



        # Queue for async Textract jobs results
        jobResultsQueue = _sqs.Queue(self, 'JobResults',
                                     queue_name= customer_name+'_training_textract_job_output_queue',
                                     visibility_timeout=cdk.Duration.seconds(1200),
                                     retention_period=cdk.Duration.seconds(1209600),
                                     dead_letter_queue=_sqs.DeadLetterQueue(max_receive_count=50, queue=dlq)
                                     )
        # Trigger between SNS -> SQS once Textract job is completed
        jobCompletionTopic.add_subscription(_snssubscr.SqsSubscription(jobResultsQueue))


        # pypdf2 layer
        pypdf2Layer = _lambda.LayerVersion(self, customer_name+'PyPDF2Layer',
                                           code=_lambda.Code.from_asset('assets/lambda/PyPDF2.zip'),
                                           compatible_runtimes=[_lambda.Runtime.PYTHON_3_7],
                                           license='Apache-2.0',
                                           description='PyPDF2 layer')
     
        
        # Process Input Lambda - Process input queue
        inputEventProcessor = _lambda.Function(self, 'TrainTextractSubmitLambda',
                                              function_name=customer_name+'_train_submit_textract',
                                              description='Function to process input PDF files for Training',
                                              runtime=_lambda.Runtime.PYTHON_3_7,
                                              handler='TrainTextractSubmitLambda.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/TrainTextractSubmitLambda'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                              layers=[pypdf2Layer],
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              environment={
                                                            "KMS_KEY" : kms_key_id,
                                                            "TEXTRACT_OUTPUT_LOC" : "cdkdeployment/training/training_textractOutputFolder",
                                                            "SNS_TOPIC_ARN": jobCompletionTopic.topic_arn,
                                                            "SNS_ROLE_ARN": textractServiceRole.role_arn,
                                                            "BUCKET" : raw_bucket.bucket_name,
                                                            "INPUT_PREFIX" : "cdkdeployment/training/inputPDF",
                                                            "TEXTRACT_JOBS_LOG" : textract_jobs_json
                                                            }
                                              )
        # raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(inputEventProcessor),
        #                                   _s3.NotificationKeyFilter(prefix="cdkdeployment/training/raw_label/", suffix=".xlsx", )
        #                                   )
        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(inputEventProcessor),
                                          _s3.NotificationKeyFilter(prefix="cdkdeployment/training/raw_label/", suffix=".csv", )
                                          )


        #------------------------------------------------------------5mins EVENT BRIDGE RULE------------------------------------------------------------

        # rule = _events.Rule(
        #     self,
        #     "Trigger Lambda to check every 5 minutes",
        #     schedule = _events.Schedule.rate(Duration.minutes(5))
        # ) 

        # rule.add_target(_targets.LambdaFunction(inputEventProcessor))

        # Permissions
        raw_bucket.grant_read_write(inputEventProcessor)
        inputEventProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                               resources=[textractServiceRole.role_arn]))
        inputEventProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["textract:*"],
                                                               resources=["*"]))
        inputEventProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*"],
                                                               resources=["*"]))

        #-------------------------------------------Use Pandas Layer provided by AWS----------------------------
        pandasLayer = _lambda.LayerVersion.from_layer_version_arn(self,"PandasLayer",layer_version_arn = "arn:aws:lambda:us-east-1:336392948345:layer:AWSSDKPandas-Python39:5")
       

       
        #-------------------------------------------Lambda function to process Textract output result----------------------------

        jobResultProcessor = _lambda.Function(self, 'TrainingJobResultProcessor',
                                              function_name=customer_name+'_training_textract_result_processor',
                                              description="Function to run process Textract Output",
                                              runtime=_lambda.Runtime.PYTHON_3_9,
                                              handler='TrainingResultProcLambda.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/TrainingResultProcLambda'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                            #   ephemeral_storage_size=10240,
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              layers=[pandasLayer],
                                              environment={'bucketName': raw_bucket.bucket_name,
                                                           'PREFIX': 'cdkdeployment/training/training_textract_separate_merged',
                                                           'qUrl': jobResultsQueue.queue_url,
                                                           'TEXTRACT_JOBS_LOG' : textract_jobs_json,
                                                           'CUSTOMER_NAME' : customer_name,
                                                           'RAW_LABEL' : 'cdkdeployment/training/raw_label'
                                                           }
                                              )

        # Permission
        raw_bucket.grant_read_write(jobResultProcessor)


        jobResultsQueue.grant_consume_messages(jobResultProcessor)
        jobResultProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                                   resources=[textractServiceRole.role_arn]))
        jobResultProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["textract:*"],
                                                                   resources=["*"]))

        jobResultProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*"],
                                                               resources=["*"]))

        





        '''Note: batchSize: Determines how many records are buffered before invoking your lambda function.
        if using batchwindow- then apply recommended visibility timeout
        https://docs.aws.amazon.com/lambda/latest/dg/with-sqs.html#events-sqs-queueconfig'''

        jobResultProcessor.add_event_source(SqsEventSource(queue=jobResultsQueue))




        # more lambdas:
        # - Keywords and label - only cleaning user labels
        # - merge downsample

        #-------------------------------------------Keywords and label----------------------------
      
        keywordFormatter = _lambda.Function(self, 'KeywordLabelFormat',
                                              function_name=customer_name+'_keyword_label_formatting',
                                              description="Function to clean the uploaded RAW Labels",
                                              runtime=_lambda.Runtime.PYTHON_3_9,
                                              handler='KeywordLabelFormat.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/KeywordLabelFormat'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                            #   ephemeral_storage_size=10240,
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              layers=[pandasLayer],
                                              environment={'bucketName': raw_bucket.bucket_name,
                                                           'PREFIX': 'cdkdeployment/training/raw_label/',
                                                           }
                                              )
        keywordFormatter.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*"],
                                                               resources=["*"]))

        jobResultProcessor.add_to_role_policy(_iam.PolicyStatement(actions=["lambda:*"],
                                                               resources=[keywordFormatter.function_arn]))
        

        
        raw_bucket.grant_read_write(keywordFormatter)


        #-------------------------------------------Merge all Textract CSVs to one large CSV----------------------------


        mergeTextractOutputCSV = _lambda.Function(self, 'mergeTextractOutputCSV',
                                              function_name=customer_name+'_merge_textract_output_csv',
                                              description="Function to merge all textract output CSV",
                                              runtime=_lambda.Runtime.PYTHON_3_9,
                                              handler='mergeTextractOutputCSV.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/mergeTextractOutputCSV'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                              ephemeral_storage_size=Size.mebibytes(10240),
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              layers=[pandasLayer],
                                              environment={'bucketName': raw_bucket.bucket_name,
                                                           'OUTPUT_PREFIX': 'cdkdeployment/training/training_textract_large_merged_output/',
                                                           'INPUT_PREFIX' : 'cdkdeployment/training/training_textract_separate_merged/'
                                                           }
                                              )
        mergeTextractOutputCSV.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*"],
                                                               resources=["*"]))

        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(mergeTextractOutputCSV),
                                          _s3.NotificationKeyFilter(prefix="cdkdeployment/training/reformatted_label/", suffix=".csv", )
                                          )

        
        raw_bucket.grant_read_write(mergeTextractOutputCSV)


        #-------------------------------------------Downsample and form a CSV for comprehend training ----------------------------

        downsamplingMergeData = _lambda.Function(self, 'DownsamplingDataMerge',
                                              function_name=customer_name+'_downsample_data_merge',
                                              description="Function to perform downsampling and generate training data for comprehend",
                                              runtime=_lambda.Runtime.PYTHON_3_9,
                                              handler='DownsamplingDataMerge.lambda_handler',
                                              code=_lambda.Code.from_asset('assets/lambda/DownsamplingDataMerge'),
                                              timeout=cdk.Duration.seconds(900),
                                              memory_size=10240,
                                              ephemeral_storage_size=Size.mebibytes(10240),
                                              retry_attempts=0,
                                              reserved_concurrent_executions=5,
                                              layers=[pandasLayer],
                                              environment={'LABEL_PREFIX' : 'cdkdeployment/training/reformatted_label/batch3_label_revised.csv',
                                                           'TEXTRACT_MERGED_PREFIX' : 'cdkdeployment/training/training_textract_large_merged_output/',
                                                           'COMPREHEND_TRAINING_INPUT': 'cdkdeployment/training/comprehend_training_input/'
                                                           }
                                              )
        
        raw_bucket.grant_read_write(downsamplingMergeData)
        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(downsamplingMergeData),
                                    _s3.NotificationKeyFilter(prefix="cdkdeployment/training/training_textract_large_merged_output/", suffix=".csv", )
                                    )

        downsamplingMergeData.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*"],
                                                               resources=["*"]))


        #------------------------------------------Comprehend Step functions workfow for Training--------------------------------------------


        start_comp_training = _lambda.Function(self, "CompTrainModel",
                                  function_name=customer_name+'_start_comprehend_model_training', 
                                  code=_lambda.Code.from_asset('assets/lambda/CompTrainModel'),
                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                  handler="CompTrainModel.lambda_handler",
                                  timeout=Duration.seconds(25),
                                  environment = {
                                    'KMS_KEY' : kms_key_arn,
                                    'TRAINING_DATA_BUCKET' : customer_bucket_name,
                                    'TRAINING_DATA_KEY' : 's3://{}/cdkdeployment/training/comprehend_training_input'.format(customer_bucket_name),
                                    'CLASSIFIER_NAME' : "Downsample",
                                    'DATA_ACCESS_ROLE' : comprehend_data_access_role,
                                    'REGION' : 'us-east-1'
                                  })
        start_comp_training.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*","comprehend:*","s3:*"],resources=["*"]))
        start_comp_training.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                               resources=[comprehend_data_access_role]))
                                                               
        get_training_status = _lambda.Function(self, "CompTrainingStatus",
                                  function_name=customer_name+'_get_comprehend_training_status', 
                                  code=_lambda.Code.from_asset('assets/lambda/CompTrainingStatus'),
                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                  handler="CompTrainingStatus.lambda_handler",
                                  timeout=Duration.seconds(25),
                                  environment={
                                    'REGION' : 'us-east-1'
                                  })
        get_training_status.add_to_role_policy(_iam.PolicyStatement(actions=["kms:*","comprehend:*","s3:*"],resources=["*"]))
        get_training_status.add_to_role_policy(_iam.PolicyStatement(actions=["iam:PassRole"],
                                                               resources=[comprehend_data_access_role]))

        

        submit_comp_job = _tasks.LambdaInvoke(self, "Submit Comprehend Job",
            lambda_function=start_comp_training,
            # Lambda's result is in the attribute `Payload`
            result_path="$.Payload"
        )

        wait_x = _sfn.Wait(self, "Wait 10 Minutes ComprehendTraining",
            time=_sfn.WaitTime.duration(Duration.seconds(600))
        )

        get_comp_job_status = _tasks.LambdaInvoke(self, "Get Job Status",
            lambda_function=get_training_status,
            # Pass just the field named "guid" into the Lambda, put the
            # Lambda's result in a field called "status" in the response
            input_path="$.Payload",
            result_path="$.status"
        )

        # success_topic = _sns.Topic(self,customer_name+"-comprehend-training-success-notifn")
        # success_topic.add_subscription(subscriptions.EmailSubscription("manojkrishna.mohan@exlservice.com"))

        # success_notification = _tasks.SnsPublish(self, "Publish Success Notification",
        #                                          topic = success_topic,
        #                                          message = _sfn.TaskInput.from_text("The job is complete"))


        # failed_topic = _sns.Topic(self,customer_name+"-comprehend-training-failed-notifn")
        # failed_topic.add_subscription(subscriptions.EmailSubscription("manojkrishna.mohan@exlservice.com"))

        # failure_notification = _tasks.SnsPublish(self, "Publish Failure Notification",
        #                                          topic = failed_topic,
        #                                          message = _sfn.TaskInput.from_text("The comprehend Training Job has failed"))


        job_failed = _sfn.Fail(self, "Job Failed",
            cause="Comprehend Job Failed",
            error="DescribeJob returned FAILED"
        )


        job_success = _sfn.Succeed(self,"Comprehend Classification Successful")

        definition = submit_comp_job.next(wait_x).next(get_comp_job_status).next(_sfn.Choice(self, "Job Complete?")\
                                                                   .when(_sfn.Condition.string_equals("$.status.Payload.JobStatus", "IN_ERROR"), job_failed)\
                                                                    .when(_sfn.Condition.string_equals("$.status.Payload.JobStatus", "TRAINED"), job_success).otherwise(wait_x))

        # definition = submit_comp_job.next(wait_x).next(get_comp_job_status).next(_sfn.Choice(self, "Job Complete?")\
        #                                                            .when(_sfn.Condition.string_equals("$.status.Payload.JobStatus", "IN_ERROR"), failure_notification.next(job_failed))\
        #                                                             .when(_sfn.Condition.string_equals("$.status.Payload.JobStatus", "TRAINED"), success_notification.next(job_success)).otherwise(wait_x))                                                                    
        comprehend_state_machine = _sfn.StateMachine(self, customer_name+"_ComprehendTrainingStepFunc",
            definition=definition,
        )
        
        #------------------------------------------------------------TRIGGER LAMBDA FOR THE ABOVE STEPFUNCTION------------------------------------------------------------

        comprehend_step_trigger = _lambda.Function(self, customer_name+"TriggerComprehendStepFunc",
                                  function_name=customer_name+'_trigger_comprehend_training', 
                                  code=_lambda.Code.from_asset('assets/lambda/comprehendTriggerLambda/'),
                                  runtime=_lambda.Runtime.PYTHON_3_7,
                                  handler="comprehendTriggerLambda.lambda_handler",
                                  timeout=Duration.seconds(300),
                                  environment={
                                    "STATE_MACHINE_ARN" : comprehend_state_machine.state_machine_arn
                                  })

        comprehend_step_trigger.add_to_role_policy(_iam.PolicyStatement(actions=["states:*"],
                                                                   resources=[comprehend_state_machine.state_machine_arn]))

        #-------------Event Notification from S3 comprehend i/p folder->Lambda-----------------------
        raw_bucket.add_event_notification(_s3.EventType.OBJECT_CREATED, _s3n.LambdaDestination(comprehend_step_trigger), _s3.NotificationKeyFilter(prefix="cdkdeployment/training/comprehend_training_input/", suffix=".csv", ))