#!/bin/bash -eu

#########
# LEGAL #
#########

# Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

### DESCRIPTION ###

# This script custom comprehend classifier training pipeline in the designated environment

#############
### USAGE ###
#############
# 0. Call the script from the root of the repo: $ bash ./EXL_CLI.sh



############# DEPLOYMENT PARAMETERS #############
## AWS Deployment Region
AWS_REGION=${3:-us-east-2}
AWS="aws --output=text --region ${AWS_REGION}"
ACCOUNT_ID=$(${AWS} sts get-caller-identity --query 'Account')

## Echo Deployment Parameters
echo "[*] Verifying training pipeline parameters..."
echo "[X] Region: ${AWS_REGION}"
echo "[X] Account ID: ${ACCOUNT_ID}"

echo
echo "Press [Enter] to continue or Ctrl-C to abort."
read


############# DEFINE VARIABLES #############
## S3 
INPUT_BUCKET=${1:-exl-cli-test1}
OUTPUT_BUCKET=${1:-exl-cli-test2}

S3_PREFIX='test/'

## SQS
ASYNC_QUEUE_NAME='Async-Queue'
ASYNC_COMP_QUEUE_NAME='Async-Complete-Queue'

## SNS
SNS_TOPIC_NAME='AmazonTextract-JobComplete-TEST'

## DYNAMODB
DOCUMENTS_TABLE_NAME='textract-documentsTable-TEST'
OUTPUTS_TABLE_NAME='textract-outputsTable-TEST'

## LAMBDA FUNCTIONS
LAMBDA_SRC_BUCKET='lambda-functions-exl-test'
LAMBDA_SRC_LAYERS_KEY='src/Layers/'
LAMBDA_SRC_CODE_KEY='src/code/'

HELPER_FILE_NAME='HelperLayer'
TEXTRACTOR_FILE_NAME='Textractor'
PANDAS_FILE_NAME='pandas'

SEARCHABLEPDF_LAMBDA_NAME='SearchablePDFLambdaTEST'
BATCH_PROCESS_LAMBDA_NAME='BatchProcTEST'
TASK_PROCESS_LAMBDA_NAME='TaskProcTEST'
ASYNC_LAMBDA_NAME='AsyncLambdaTEST'
JOB_PROCESS_LAMBDA_NAME='JobProcLambdaTEST'
START_INF_WF_LAMBDA_NAME='StartInferenceWorkFlowTEST'
INF_LAMBDA_NAME='CompStartInferenceLambdaTEST'
INF_GETSTATUS_LAMBDA_NAME='CompGetInferStatusLambdaTEST'
LEXICON_LAMBDA_NAME='TransformLexiconTEST'
START_TRN_WF_LAMBDA_NAME='StartTrainingWorkFlowTEST'
TRAIN_LAMBDA_NAME='CompTrainModelTEST'
GETSTATUS_LAMBDA_NAME='CompTrainingStatusTEST'


## IAM
STEP_ONE_ROLE='arn of aws_iam_role_exl_health_drg_nlp_step_01_s3batch'
STEP_TWO_ROLE='arn of aws_iam_role_exl_health_drg_nlp_step_02_svctextract'
STEP_THREE_ROLE='arn of aws_iam_role_exl_health_drg_nlp_step_03_svccomprehend'
STEP_FOUR_ROLE='arn of aws_iam_role_exl_health_drg_nlp_step_04_svclexicon'
DATA_ACCESS_ROLE_ARN='arn of Comprehend service role that allows Comprehend to access the data'

## KMS
TEXTRACT_KMS_KEY_ID=''
DYNAMODB_KMS_KEY_ID=''
COMPREHEND_KMS_KEY_ID=''

## COMPREHEND
DOC_CLASS_ARN=''
TRAINING_DATA_KEY='' #s3 key path of the training data
CLASSIFIER_NAME='exl-custom-classifier'

## STEP FUNCTION
INF_STATE_MACHINE_NAME='ComprehendInferenceSM'
TRN_STATE_MACHINE_NAME='ComprehendCustomClassifierSM'

## EVENT BRIDGE
ASYNC_RULE_NAME='async-lambda-scheduler'



############# CREATE S3 bucket #############

_BUCKETS=$(for _BUCKET in $(${AWS} s3api list-buckets --query 'Buckets[].Name'); do echo $_BUCKET; done)

## Input Bucket 
if [ -z "$(grep "${INPUT_BUCKET}" <<< ${_BUCKETS} || true)" ]; then
  echo -n "[!] Create new input bucket '${INPUT_BUCKET}' ? [Y/n] "
  read ANS
  if [ -z "${ANS}" -o "${ANS:0:1}" = "Y" -o "${ANS:0:1}" = "y" ]; then
    #${AWS} s3api create-bucket --acl private --create-bucket-configuration LocationConstraint=${AWS_REGION} --bucket ${INPUT_BUCKET}
    ${AWS} s3api create-bucket --acl private --bucket ${INPUT_BUCKET}

    ## create 'training_data' objects (i.e. folders) inside the ${INPUT_BUCKET}
    #TRAIN_DIR=${TRAIN_DIR:-SaaS_workspace/aws_comprehend/inputs/}
    #${AWS} s3api put-object --bucket ${INPUT_BUCKET} --key ${TRAIN_DIR}/
    echo "${INPUT_BUCKET} created successfully!!"
  else
    echo "Exiting..."
#    exit 1
  fi
else
    echo "${INPUT_BUCKET} already exists!!"
#    exit 1
fi

## Output Bucket 
if [ -z "$(grep "${OUTPUT_BUCKET}" <<< ${_BUCKETS} || true)" ]; then
  echo -n "[!] Create new input bucket '${OUTPUT_BUCKET}' ? [Y/n] "
  read ANS
  if [ -z "${ANS}" -o "${ANS:0:1}" = "Y" -o "${ANS:0:1}" = "y" ]; then
    #${AWS} s3api create-bucket --acl private --create-bucket-configuration LocationConstraint=${AWS_REGION} --bucket ${INPUT_BUCKET}
    ${AWS} s3api create-bucket --acl private --bucket ${OUTPUT_BUCKET}

    ## create 'training_data' objects (i.e. folders) inside the ${INPUT_BUCKET}
    #TRAIN_DIR=${TRAIN_DIR:-SaaS_workspace/aws_comprehend/inputs/}
    #${AWS} s3api put-object --bucket ${INPUT_BUCKET} --key ${TRAIN_DIR}/
    echo "${OUTPUT_BUCKET} created successfully!!"
  else
    echo "Exiting..."
#    exit 1
  fi
else
    echo "${INPUT_BUCKET} already exists!!"
#    exit 1
fi

############# CREATE DynamoDB TABLES #############

### Create textract-outputsTable 
aws dynamodb create-table --table-name ${DOCUMENTS_TABLE_NAME} \
--attribute-definitions AttributeName=documentId,AttributeType=S \
--key-schema AttributeName=documentId,KeyType=HASH \
--provisioned-throughput ReadCapacityUnits=10,WriteCapacityUnits=10 \
--stream-specification  StreamEnabled=true,StreamViewType="NEW_AND_OLD_IMAGES" \
--sse-specification Enabled="true", SSEType="KMS", KMSMasterKeyId=${DYNAMODB_KMS_KEY_ID}


### Create textract-outputsTable 
aws dynamodb create-table --table-name ${OUTPUTS_TABLE_NAME}  \
--attribute-definitions AttributeName=documentId,AttributeType=S \
--key-schema AttributeName=documentId,KeyType=HASH  \
--provisioned-throughput ReadCapacityUnits=10,WriteCapacityUnits=10 \
--stream-specification  StreamEnabled=true,StreamViewType="NEW_AND_OLD_IMAGES" \
--sse-specification Enabled="true", SSEType="KMS", KMSMasterKeyId=${DYNAMODB_KMS_KEY_ID}



############### CREATE SQS QUEUES ###############

### Create Async-Queue
# aws sqs create-queue --queue-name ${ASYNC_QUEUE_NAME} \
# --attributes file://SQS/create-async-queue.json


# ### Create AsyncJobComplete-Queue
# aws sqs create-queue --queue-name ${ASYNC_COMP_QUEUE_NAME} \
# --attributes file://SQS/create-async-queue.json


# ### Create Async-DLQ
# aws sqs create-queue --queue-name "${ASYNC_QUEUE_NAME}-dlq" \
# --attributes file://SQS/create-async-dlq.json


# ### Create AsyncJobComplete-DLQ
# aws sqs create-queue --queue-name "${ASYNC_COMP_QUEUE_NAME}-dlq" \
# --attributes file://SQS/create-async-dlq.json



############### CREATE SNS TOPIC ###############

### Create textract-job-complete topic
 aws sns create-topic --name ${SNS_TOPIC_NAME} \
 --attributes file://SNS/create-topic.json


############# CREATE LAMBDA LAYERS #############
## Publish HelperLayer
aws lambda publish-layer-version --layer-name HelperLayer \
--description "Helper Layer" --license-info "MIT" \
--content S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_LAYERS_KEY}${HELPER_FILE_NAME}.zip" \
--compatible-runtimes python3.7


## Publish Textractor Layer
aws lambda publish-layer-version --layer-name Textractor \
--description "Textractor Layer" \
--license-info "MIT" \
--content S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_LAYERS_KEY}${TEXTRACTOR_FILE_NAME}.zip" \
--compatible-runtimes python3.7


## Publish Pandas Layer
aws lambda publish-layer-version --layer-name pandasLayer \
--description "Pandas Layer" \
--license-info "MIT" \
--content S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_LAYERS_KEY}${PANDAS_FILE_NAME}.zip" \
--compatible-runtimes python3.9



############# CREATE LAMBDA FUNCTIONS #############

## SearchablePDF Lambda


aws lambda create-function --function-name ${SEARCHABLEPDF_LAMBDA_NAME} \
--runtime java11 --role  ${STEP_ONE_ROLE}  \
--handler "SearchablePDFLambda::handleRequest" \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}searchable-pdf-1.0.zip" \
--timeout 840  --memory-size 3008 \
--description "Lambda function that converts scanned PDF, JPEG, and PNG files to searchable PDF files" 

## S3 Batch Process Lambda
aws lambda create-function --function-name ${BATCH_PROCESS_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_ONE_ROLE}  \
--handler ${BATCH_PROCESS_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}${BATCH_PROCESS_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "Lambda writes a task to process each document to dynamoDB" \
--environment Variables="{DOCUMENTS_TABLE=${DOCUMENTS_TABLE_NAME}, \
OUTPUT_TABLE=${OUTPUTS_TABLE_NAME}}"

## Task Process Lambda
aws lambda create-function --function-name ${TASK_PROCESS_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_TWO_ROLE}  \
--handler ${TASK_PROCESS_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}${TASK_PROCESS_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "Processes Documents from dynamoDB" \
--environment Variables="{ASYNC_QUEUE_URL=https://sqs.${AWS_REGION}.amazonaws.com/${ACCOUNT_ID}/${ASYNC_QUEUE_NAME}}"

## Async Lambda
aws lambda create-function --function-name ${ASYNC_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_TWO_ROLE}  \
--handler ${ASYNC_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}${ASYNC_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "Processes Documents from dynamoDB" \
--environment Variables="{ASYNC_QUEUE_URL=https://sqs.${AWS_REGION}.amazonaws.com/${ACCOUNT_ID}/${ASYNC_QUEUE_NAME}, \
JOB_STORAGE=textract-output/raw_output, \
KMS_KEY=${TEXTRACT_KMS_KEY_ID}, \
OUTPUT_BUCKET=${OUTPUT_BUCKET}, \
SNS_ROLE_ARN=${STEP_TWO_ROLE}, \
SNS_TOPIC_ARN=arn:aws:${AWS_REGION}:${ACCOUNT_ID}:${SNS_TOPIC_NAME}}"

## Job Process Lambda
aws lambda create-function --function-name ${JOB_PROCESS_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_TWO_ROLE}  \
--handler ${JOB_PROCESS_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}${JOB_PROCESS_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "Processes Documents from dynamoDB" \
--environment Variables="{ASYNC_COMP_QUEUE_URL=https://sqs.${AWS_REGION}.amazonaws.com/${ACCOUNT_ID}/${ASYNC_COMP_QUEUE_NAME}, \
COMPREHEND_PREFIX= comprehend_input/, \
TEXTRACT_PREFIX= textract-output/, \
bucketName= ${OUTPUT_BUCKET}}"


## StartInferenceWorkFlow Lambda

aws lambda create-function --function-name ${START_INF_WF_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_THREE_ROLE}  \
--handler ${START_INF_WF_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}${START_TRN_WF_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "Lambda Function to Start Comprehend Inference workflow (SM)" \
--environment Variables="{STATE_MACHINE_ARN=arn:aws:states:${AWS_REGION}:${ACCOUNT_ID}:stateMachine:${INF_STATE_MACHINE_NAME}}"

## CompStartInferenceLambda Lambda
aws lambda create-function --function-name ${INF_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_THREE_ROLE}  \
--handler ${INF_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}${INF_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "Lambda Function to trigger a Comprehend inference job" \
--environment Variables="{INFERENCE_RESULTS=s3://${OUTPUT_BUCKET}${S3_PREFIX}aws_comprehend/outputs/, \
KMS_KEY=${COMPREHEND_KMS_KEY_ID}, \
DOC_CLASS_ARN=${DOC_CLASS_ARN}, \
DATA_ACCESS_ROLE_ARN= ${DATA_ACCESS_ROLE_ARN}, REGION=${AWS_REGION}}"

## CompInferenceStatus Lambda
aws lambda create-function --function-name ${INF_GETSTATUS_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_THREE_ROLE}  \
--handler ${INF_GETSTATUS_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}${INF_GETSTATUS_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "Lambda Function to Get status of Comprehend inference job" \
--environment Variables="{REGION=${AWS_REGION}}"

## Transform to Lexicon Lambda
aws lambda create-function --function-name ${LEXICON_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_FOUR_ROLE}  \
--handler ${LEXICON_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}${LEXICON_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "" \
--environment Variables="{OUTPUT_BUCKET=${OUTPUT_BUCKET}, \
OUTPUT_KEY=lexicon-output/, \
SCORE=0.3}"

## StartTrainingWorkFlow Lambda
aws lambda create-function --function-name ${START_TRN_WF_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_THREE_ROLE}  \
--handler ${START_TRN_WF_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}${START_TRN_WF_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "Lambda Function to Start Custom Classifier training workflow (SM)" \
--environment Variables="{STATE_MACHINE_ARN=arn:aws:states:${AWS_REGION}:${ACCOUNT_ID}:stateMachine:${TRN_STATE_MACHINE_NAME}}"

## CompTrainModel Lambda
aws lambda create-function --function-name ${TRAIN_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_THREE_ROLE}  \
--handler ${TRAIN_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_CODE_KEY}${TRAIN_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "Lambda Function to trigger a Comprehend custom classifier" \
--environment Variables="{CLASSIFIER_NAME=${CLASSIFIER_NAME}, \
KMS_KEY=${COMPREHEND_KMS_KEY_ID}, \
TRAINING_DATA_BUCKET=${INPUT_BUCKET}, \
TRAINING_DATA_KEY=${TRAINING_DATA_KEY}, \
DATA_ACCESS_ROLE= ${DATA_ACCESS_ROLE_ARN}, REGION=${AWS_REGION}}"

## CompTrainingStatus Lambda
aws lambda create-function --function-name ${GETSTATUS_LAMBDA_NAME} \
--runtime python3.7 --role  ${STEP_THREE_ROLE}  \
--handler ${GETSTATUS_LAMBDA_NAME}.lambda_handler \
--code S3Bucket=${LAMBDA_SRC_BUCKET},S3Key="${LAMBDA_SRC_KEY}${GETSTATUS_LAMBDA_NAME}.zip" \
--timeout 840  --memory-size 3008 \
--description "Lambda Function to Get status of Comprehend Custom Classifier training job" \
--environment Variables="{REGION='us-east-1'}"


############# CREATE STATE MACHINE #############

## ComprehendInferenceSM 
aws stepfunctions create-state-machine --name ${INF_STATE_MACHINE_NAME} \
--definition "$(cat sm_definition/InferenceStateMachineDefinition.json)" \
--role-arn ${STEP_THREE_ROLE}

## ComprehendCustomClassifierSM Lambda
aws stepfunctions create-state-machine --name ${TRN_STATE_MACHINE_NAME} \
--definition "$(cat sm_definition/InferenceStateMachineDefinition.json)" \
--role-arn ${STEP_THREE_ROLE}



