#!/bin/bash -eu

#########
# LEGAL #
#########

# Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Permission is hereby granted, free of charge, to any person obtaining a copy of this
# software and associated documentation files (the "Software"), to deal in the Software
# without restriction, including without limitation the rights to use, copy, modify,
# merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
# permit persons to whom the Software is furnished to do so.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
# PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
# OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
# SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

### DESCRIPTION ###

# This script custom comprehend classifier training pipeline in the designated environment

#############
### USAGE ###
#############
# 0. Call the script from the root of the repo: $ bash ./EXL_CLI_Triggers.sh


############# DEPLOYMENT PARAMETERS #############
## AWS Deployment Region
AWS_REGION=${3:-us-west-1}
AWS="aws --output=text --region ${AWS_REGION}"
ACCOUNT_ID=$(${AWS} sts get-caller-identity --query 'Account')

## Echo Deployment Parameters
echo "[*] Verifying training pipeline parameters..."
echo "[X] Region: ${AWS_REGION}"
echo "[X] Account ID: ${ACCOUNT_ID}"

echo
echo "Press [Enter] to continue or Ctrl-C to abort."
read


############# DEFINE VARIABLES #############
##S3
OUTPUT_BUCKET=''
TRAINING_BUCKET=''

## LAMBDAS
ASYNC_LAMBDA_ARN=''
START_INF_WF_LAMBDA_NAME='StartInferenceWorkFlow'
START_TRN_WF_LAMBDA_NAME='StartTrainingWorkFlow'
LEXICON_LAMBDA_NAME='TransformLexicon'
TASK_PROCESS_LAMBDA_NAME='TaskProcLambda'
JOB_PROCESS_LAMBDA_NAME='JobProcLambda'

## SQS
ASYNC_COMP_QUEUE_ARN=''

## DYNAMODB (outputs table)
DYNAMO_DB_STREAM_ARN=''

## EVENT BRIDGE
ASYNC_RULE_NAME=''


############# CREATE TRIGGERS AND RULES #############

## EVENT BRIDGE RULE
aws events put-rule --name ${ASYNC_RULE_NAME} \
--schedule-expression "rate(5 minutes)"

aws events put-targets --rule DailyLambdaFunction \
--targets "Id"="1","Arn"=${ASYNC_LAMBDA_ARN}

## LAMBDA S3 TRIGGERS
aws lambda add-permission --action lambda:InvokeFunction \
--principal s3.amazonaws.com \
--statement-id InferenceLambdaTrigger \
--function-name ${START_INF_WF_LAMBDA_NAME} \
--source-arn "arn:aws:s3:::${OUTPUT_BUCKET}" \
--source-account ${ACCOUNT_ID}

aws lambda add-permission --action lambda:InvokeFunction \
--principal s3.amazonaws.com \
--statement-id TrainingLambdaTrigger \
--function-name ${START_TRN_WF_LAMBDA_NAME} \
--source-arn "arn:aws:s3:::${TRAINING_BUCKET}" \
--source-account ${ACCOUNT_ID}

aws lambda add-permission --action lambda:InvokeFunction \
--principal s3.amazonaws.com \
--statement-id LexiconTransformLambdaTrigger \
--function-name ${LEXICON_LAMBDA_NAME} \
--source-arn "arn:aws:s3:::${OUTPUT_BUCKET}" \
--source-account ${ACCOUNT_ID}

aws s3api put-bucket-notification-configuration --bucket ${OUTPUT_BUCKET} \
--notification-configuration file://outputbucketnotifications.json

aws s3api put-bucket-notification-configuration --bucket ${TRAINING_BUCKET} \
--notification-configuration file://trainingbucketnotifications.json

## LAMBDA DYNAMODB TRIGGERS
aws lambda create-event-source-mapping --function-name ${TASK_PROCESS_LAMBDA_NAME} \
--batch-size 500 \
--event-source-arn ${DYNAMO_DB_STREAM_ARN}

## LAMBDA SQS TRIGGERS
aws lambda create-event-source-mapping --function-name ${JOB_PROCESS_LAMBDA_NAME} \
--batch-size 10 \
--event-source-arn ${ASYNC_COMP_QUEUE_ARN}




