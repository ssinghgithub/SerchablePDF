import os
import json
import boto3
import time

sqs_client = boto3.client("sqs")
textract_client = boto3.client('textract')


def startJob(bucketName, objectName, documentId, snsTopic, snsRole):
    print("Starting job with documentId: {}, bucketName: {}, objectName: {}".format(documentId, bucketName, objectName))

    response = None

    response = textract_client.start_document_text_detection(
        ClientRequestToken=documentId,
        DocumentLocation={
            'S3Object': {
                'Bucket': bucketName,
                'Name': objectName
            }
        },
        NotificationChannel={
            "RoleArn": snsRole,
            "SNSTopicArn": snsTopic
        },
        JobTag=documentId)

    print("RESPONSE:", response)

    return response["JobId"]


def lambda_handler(event, context):
    print("Events Received:", event['Records'])
    # qUrl = os.environ['qUrl']
    print("Inside TextractHLProcLambda")

    # for count, msg in enumerate(event['Records']):
    #     messageBody = json.loads(event['Records'][count]['body'])
    #     bucketName = messageBody['Records'][0]['s3']['bucket']['name']
    #     objectName = messageBody['Records'][0]['s3']['object']['key']
    #     documentId = event['Records'][count]['messageId']
    #     print('bucketName: ', bucketName)
    #     print('objectName: ', objectName)
    #     print('documentId: ', documentId)
    #     print(f'starting Textract {count + 1} job...')
    #     jobId = startJob(bucketName, objectName, documentId, snsTopic, snsRole)
    #     print("==========================")

    return "Queue loaded"