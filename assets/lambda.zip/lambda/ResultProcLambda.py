import os
import json
import boto3
import pandas as pd
import time


def lambda_handler(event, context):
    sqs = boto3.client("sqs")
    bucketName = os.environ["bucketName"]
    PREFIX = os.environ["PREFIX"]
    # qUrl = os.environ["qUrl"]

    print("Event1:-", event)

    for count, msg in enumerate(event['Records']):
        messageBody = json.loads(msg['body'])['Message']
        job_id = json.loads(messageBody)['JobId']

        input_bucketName = json.loads(messageBody)['DocumentLocation']['S3Bucket']
        objectName = json.loads(messageBody)['DocumentLocation']['S3ObjectName']

        textract_output_bucketName = bucketName  # json.loads(messageBody)['DocumentLocation']['S3Bucket']

        input_file_loc = objectName
        file_name = input_file_loc[input_file_loc.rfind('/') + 1:]
        csv_key_name = f'{file_name[:file_name.find(".")]}.csv'

        page_lines = process_response(job_id)

        df = pd.DataFrame(page_lines.items())
        df.columns = ["PageNo", "Text"]
        df['FileName'] = file_name
        df = df[['FileName', 'PageNo', 'Text']]
        # merged_df = merged_df.append(df)

        # merged_df.to_csv(f"/tmp/{csv_key_name}", index=False)
        df.to_csv(f"/tmp/{csv_key_name}", index=False)
        upload_to_s3(f"/tmp/{csv_key_name}", textract_output_bucketName, f"{PREFIX}/{csv_key_name}")
        print("File uploaded successfully!")

    return {"statusCode": 200, "body": json.dumps("File uploaded successfully!")}


def upload_to_s3(filename, bucket, key):
    s3 = boto3.client("s3")
    s3.upload_file(Filename=filename, Bucket=bucket, Key=key)


def process_response(job_id):
    textract = boto3.client("textract")
    pages = []

    response = textract.get_document_text_detection(JobId=job_id)
    pages.append(response)

    nextToken = None
    if "NextToken" in response:
        nextToken = response["NextToken"]

    while nextToken:
        # time.sleep(5)
        response = textract.get_document_text_detection(
            JobId=job_id, NextToken=nextToken
        )
        pages.append(response)
        nextToken = None
        if "NextToken" in response:
            nextToken = response["NextToken"]
            print(nextToken)

    page_lines = {}
    for page in pages:
        for item in page["Blocks"]:
            if item["BlockType"] == "LINE":
                if item["Page"] in page_lines.keys():
                    page_lines[item["Page"]].append(item["Text"])
                else:
                    page_lines[item["Page"]] = []
    return page_lines

#     # csv_key_name = "processed_files.csv"
#     # merged_df = pd.DataFrame(columns=['FileName', 'PageNo', 'Text'])
#
#     print("Event1:-", event)
#     messages = getMessagesFromQueue(sqs, qUrl)
#
#     for message in messages:
#         body = json.loads(message['body'])
#         msg = json.loads(body['Message'])
#         job_id = msg['JobId']
#
#         input_file_loc = message['DocumentLocation']['S3ObjectName']
#         file_name = input_file_loc[input_file_loc.rfind('/') + 1:]
#         csv_key_name = f'{file_name[:file_name.find(".")]}.csv'
#
#         page_lines = process_response(job_id)
#
#         df = pd.DataFrame(page_lines.items())
#         df.columns = ["PageNo", "Text"]
#         df['FileName'] = file_name
#         df = df[['FileName', 'PageNo', 'Text']]
#         # merged_df = merged_df.append(df)
#
#         # merged_df.to_csv(f"/tmp/{csv_key_name}", index=False)
#         df.to_csv(f"/tmp/{csv_key_name}", index=False)
#         upload_to_s3(f"/tmp/{csv_key_name}", bucketName, f"{PREFIX}/{csv_key_name}")
#
#     return {"statusCode": 200, "body": json.dumps("File uploaded successfully!")}
#
#
# def getMessagesFromQueue(sqs, qUrl, ):
#     # Receive message from SQS queue
#     response = sqs.receive_message(
#         QueueUrl=qUrl,
#         MaxNumberOfMessages=1,
#         VisibilityTimeout=60  # 14400
#     )
#
#     print('SQS Response Recieved:')
#     print(response)
#
#     if 'Messages' in response:
#         return response['Messages']
#     else:
#         print("No messages in queue.")
#         return None
#
#
