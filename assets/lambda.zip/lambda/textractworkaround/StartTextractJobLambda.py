import json
import boto3


def start_textract_job(s3_bucket_name, object_name):
    client = boto3.client("textract", region_name="us-east-1")
    response = client.start_document_text_detection(
        DocumentLocation={"S3Object": {"Bucket": s3_bucket_name, "Name": object_name}}
    )

    return response["JobId"]


def lambda_handler(event, context):
    print(event["Records"]["object"])

    object_name = event["Records"]["object"]
    splits = event["Records"]["split"]
    input_bucket = event["Records"]["outputBucketName"]
    job_list = []

    for item in splits:
        jobId = start_textract_job(input_bucket, item['file_name'])
        temp = {
            "file_name": item['file_name'],
            "page_numbers": item['page_numbers'],
            "jobId": jobId
        }
        job_list.append(temp)

    return {
        'Records': {
            'object': object_name,
            'textractJob': job_list,
            'inputBucketName': input_bucket
        }
    }