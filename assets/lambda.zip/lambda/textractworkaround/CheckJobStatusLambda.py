import json
import boto3
import time
import logging

client = boto3.client("textract", region_name="us-east-1")


def is_job_complete(client, job_id):
    time.sleep(5)
    response = client.get_document_text_detection(JobId=job_id)
    status = response["JobStatus"]
    print("Job status: {}".format(status))

    while status == "IN_PROGRESS":
        time.sleep(5)
        response = client.get_document_text_detection(JobId=job_id)
        status = response["JobStatus"]
        print("Job status: {}".format(status))

    return status


def lambda_handler(event, context):
    print(event)
    object_name = event["Records"]["object"]
    textract_job = event["Records"]["textractJob"]
    input_bucket = event["Records"]["inputBucketName"]
    job_details = []
    job_status = ""
    total_jobs = len(textract_job)
    completed_jobs = 0

    for item in textract_job:
        single_job_status = is_job_complete(client, item["jobId"])
        if single_job_status == 'SUCCEEDED':
            completed_jobs += 1
        elif single_job_status == 'FAILED':
            job_status = single_job_status
            break
        temp = {
            "file_name": item['file_name'],
            "page_numbers": item['page_numbers'],
            "jobId": item["jobId"],
            "status": single_job_status
        }
        job_details.append(temp)

    if total_jobs == completed_jobs:
        job_status = "SUCCEEDED"

    return {
        'JobStatus': job_status,
        'Records': {
            'object': object_name,
            'textractJob': job_details,
            's3Bucket': input_bucket
        }
    }
