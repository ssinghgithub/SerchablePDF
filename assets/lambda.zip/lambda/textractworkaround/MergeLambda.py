import json
import time
import os
import boto3

client = boto3.client("textract", region_name="us-east-1")


def write_file_to_s3(bucket, file_name, textractOutput):
    s3 = boto3.resource('s3')
    s3object = s3.Object(bucket, file_name)

    s3object.put(
        Body=(bytes(json.dumps(textractOutput).encode('UTF-8')))
    )


def get_job_results(client, job_id):
    pages = []
    time.sleep(5)
    response = client.get_document_text_detection(JobId=job_id)
    pages.append(response)

    next_token = None
    if "NextToken" in response:
        next_token = response["NextToken"]

    while next_token:
        time.sleep(5)
        response = client.get_document_text_detection(
            JobId=job_id, NextToken=next_token
        )
        pages.append(response)

        next_token = None
        if "NextToken" in response:
            next_token = response["NextToken"]

    return pages


def lambda_handler(event, context):
    object_name = event["Records"]["object"].split('.')[0]
    textract_job = event["Records"]["textractJob"]
    input_bucket = event["Records"]["s3Bucket"]
    job_details = []
    merged_output_bucket = os.environ['merge_output_bucket']
    combined_response = {}
    for item in textract_job:
        job_status = item["status"]
        if job_status == "SUCCEEDED":
            response = get_job_results(client, item["jobId"])
            if len(combined_response) == 0:
                combined_response = response
            else:
                # update the page number in response
                for each in response[0]["Blocks"]:
                    index = int(each["Page"])
                    each["Page"] = item['page_numbers'][(index - 1)]
                combined_response[0]["Blocks"].extend(response[0]["Blocks"])
    # update the total number of pages
    combined_response[0]["DocumentMetadata"]["Pages"] = item['page_numbers'][-1]

    if len(combined_response) > 0:
        merged_data_file = object_name + ".json"
        write_file_to_s3(merged_output_bucket, merged_data_file, combined_response)

    return {
        'Records': {
            'object': merged_data_file,
            's3Bucket': merged_output_bucket,
        }
    }
