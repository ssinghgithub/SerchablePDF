def handler(event, context):
    print("Running Processing Lambda!!")
    return{
        'body':'Hello from Lambda',
        'statusCode':200
    }