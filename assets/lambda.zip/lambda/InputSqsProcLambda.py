import PyPDF2
import boto3
import io
import json
import os
import time

sqs_client = boto3.client("sqs")
textract_client = boto3.client('textract')
s3_client = boto3.resource("s3")

"""Function to process messages from input queue"""
def start_textract_job(bucket, object, documentId, sns_topic, sns_role):
    print("Starting job with bucketName: {}, objectName: {}".format(documentId, bucket, object))

    response = None

    response = textract_client.start_document_text_detection(
        ClientRequestToken=documentId,
        DocumentLocation={
            'S3Object': {
                'Bucket': bucket,
                'Name': object
            }
        },
        NotificationChannel={
            "RoleArn": sns_role,
            "SNSTopicArn": sns_topic
        },
        JobTag=documentId)

    print("RESPONSE:", response)

    return response["JobId"]


def is_file_size_over_limit(bucket, object):
    textract_size_limit = 524288000
    client = boto3.resource("s3")
    s3_obj = client.Object(bucket, object)
    file = io.BytesIO(s3_obj.get()["Body"].read())

    if file.getbuffer().nbytes > textract_size_limit:
        return True
    return False


def is_page_size_over_limit(bucketName, objectName):
    textract_page_limit = 3000
    s3_obj = s3_client.Object(bucketName, objectName)
    file = io.BytesIO(s3_obj.get()["Body"].read())

    # S3 trigger payload has size, can skip Pypdf2 read
    reader = PyPDF2.PdfReader(file)

    if len(reader.pages) > textract_page_limit:
        return True
    return False


def write_message_to_queue(bucket, object):

    qUrlOutput = os.environ['limit_qUrl']
    response = sqs_client.send_message(
        QueueUrl=qUrlOutput,
        DelaySeconds=10,
        MessageAttributes={
            'bucket': {
                'DataType': 'String',
                'StringValue': bucket
            },
            'object': {
                'DataType': 'String',
                'StringValue': object
            }
        },
        MessageBody=(
            'File exceeds textract hard limit'
        )
    )

    print(response['MessageId'])
    return response


def check_limits(bucketName, objectName):
    limit_type = ""
    limit_exceed_flag = False

    is_size_over = is_file_size_over_limit(bucketName, objectName)
    is_page_size_over = is_page_size_over_limit(bucketName, objectName)

    if is_size_over and is_page_size_over:
        limit_type = "File size and number of pages exceed Textract Hard limit"
        limit_exceed_flag = True

    elif is_size_over:
        limit_type = "File size more than Textract limits"
        limit_exceed_flag = True

    elif is_page_size_over:
        limit_type = "File has more pages than allowed by Textract"
        limit_exceed_flag = True

    else:
        limit_type = "File size and total number of pages is within textract hard limits"

    return limit_exceed_flag,limit_type

def lambda_handler(event, context):
    print("Events Received:", event)
    # qUrl = os.environ['qUrl']
    snsTopic = os.environ['SNS_TOPIC_ARN']
    snsRole = os.environ['SNS_ROLE_ARN']

    limit_exceed_flag = False

    for count, msg in enumerate(event['Records']):
        messageBody = json.loads(event['Records'][count]['body'])
        bucketName = messageBody['Records'][0]['s3']['bucket']['name']
        objectName = messageBody['Records'][0]['s3']['object']['key']
        documentId = event['Records'][count]['messageId']
        print('bucketName: ', bucketName)
        print('objectName: ', objectName)
        print('documentId: ', documentId)

        limit_exceed_flag, limit_type = check_limits(bucketName, objectName)

        if limit_exceed_flag:
            print(limit_type)
            response = write_message_to_queue(bucketName, objectName)
            print(response)
        else:
            # documentId = event['Records'][0]['messageId']
            print(f'starting Textract {count + 1} job...for {objectName}')
            jobId = start_textract_job(bucketName, objectName, documentId, os.environ['SNS_TOPIC_ARN'],
                               os.environ['SNS_ROLE_ARN'])
            print("==========================")
