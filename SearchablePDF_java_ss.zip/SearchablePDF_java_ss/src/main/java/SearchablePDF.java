public class SearchablePDF {
    public static void main(String args[]) {
        try {            
           //Generate searchable PDF from pdf in Amazon S3 bucket
           CreatePdfFromS3Pdf s3Pdf = new CreatePdfFromS3Pdf();
           s3Pdf.run("ki-textract-demo-docs", "SampleInput.pdf", "SampleOutput.pdf");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
